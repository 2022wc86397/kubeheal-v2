#!/usr/bin/env bash
# Collects everything needed to understand a failed or half-working install into one file you can share.
#   ./scripts/diagnose.sh            prints a report and saves it to /tmp/kubeheal-diagnose-<time>.txt
# Never changes anything in the cluster.
set -uo pipefail
export KUBECONFIG="${KUBECONFIG:-$HOME/.kube/config}"
[[ -r "$KUBECONFIG" ]] || export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
export PATH="$PATH:/usr/local/bin"
OUT="/tmp/kubeheal-diagnose-$(date +%Y%m%d-%H%M%S).txt"
exec > >(tee "$OUT") 2>&1

hdr(){ printf '\n===== %s =====\n' "$*"; }
hdr "host"; (. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-unknown}"); uname -srm; nproc | sed 's/$/ vCPU/'; free -m | sed -n '1,2p'
hdr "nodes"; kubectl get nodes -o wide 2>&1
hdr "pods (READY column matters: 0/1 Running means NOT ready)"; kubectl get pods -A -o wide 2>&1 | grep -E 'NAME|monitoring|kubeheal'

UNREADY=$(kubectl get pods -A --no-headers 2>/dev/null | grep -E 'monitoring|kubeheal' | awk '{split($3,a,"/"); if (a[1]!=a[2] || $4!="Running") print $1"/"$2}')
if [[ -z "$UNREADY" ]]; then hdr "all KubeHeal pods are ready"; else
  for p in $UNREADY; do
    ns=${p%%/*}; name=${p##*/}
    hdr "NOT READY: $p"
    kubectl -n "$ns" describe pod "$name" 2>&1 | sed -n '/^Containers:/,/^Volumes:/p;/^Events:/,$p' | head -70
    hdr "logs (last 40 lines): $p"; kubectl -n "$ns" logs "$name" --tail=40 2>&1
  done
fi

hdr "KubeHeal probes, exactly as the kubelet makes them (no credentials)"
kubectl -n kubeheal-system exec deploy/kubeheal -- python -c '
import urllib.request, urllib.error
for path in ("/api/health", "/api/ready"):
    try:    print(path, urllib.request.urlopen("http://localhost:8080" + path, timeout=4).status)
    except urllib.error.HTTPError as e: print(path, "HTTP", e.code, "<-- the readiness probe sees this")
    except Exception as e: print(path, "ERROR", e)' 2>&1
hdr "probe configuration"; kubectl -n kubeheal-system get deploy kubeheal -o jsonpath='{.spec.template.spec.containers[0].readinessProbe}{"\n"}{.spec.template.spec.containers[0].livenessProbe}{"\n"}' 2>&1
hdr "resource quota"; kubectl -n kubeheal-demo describe resourcequota 2>&1 | tail -12
hdr "recent events"; kubectl get events -A --sort-by=.lastTimestamp 2>&1 | grep -E 'monitoring|kubeheal|NAMESPACE' | tail -25
hdr "images present in k3s"; sudo /usr/local/bin/k3s ctr images ls -q 2>/dev/null | grep kubeheal || echo "(none found, or no sudo)"
echo; echo "Report saved to $OUT"
