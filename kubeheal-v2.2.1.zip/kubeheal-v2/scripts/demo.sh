#!/usr/bin/env bash
# Run KubeGuard on http://localhost:8080 against the built-in cluster simulator (no Kubernetes needed).
#
#   ./scripts/demo.sh                 start the dashboard and leave it running (Ctrl+C to stop)
#   ./scripts/demo.sh --walkthrough   also run a scripted demo: crash, CPU, memory and error faults,
#                                     printing each detection and recovery as it happens
#   PORT=9090 ./scripts/demo.sh       use another port
set -euo pipefail
PORT="${PORT:-8080}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WALK=0; KEEP=0
for a in "$@"; do case "$a" in --walkthrough) WALK=1;; --keep) KEEP=1;; *) echo "unknown option $a"; exit 2;; esac; done

cd "$ROOT/services/kubeheal"
if ! python3 -c "import flask, requests" 2>/dev/null; then
  [[ -d .venv ]] || python3 -m venv .venv
  . .venv/bin/activate
  pip install -q Flask==3.1.2 requests==2.32.5
fi
export KUBEHEAL_MODE=mock DB_PATH="${DB_PATH:-/tmp/kubeheal-demo.db}" DETECT_INTERVAL_SECONDS=2 VERIFY_POLL_SECONDS=1 MOCK_STARTUP_SECONDS=3
rm -f "$DB_PATH" "$DB_PATH"-wal "$DB_PATH"-shm

DEMO_PIDS=()
start_demo_apps() {
  for spec in frontend:8101 backend:8102 database:8103; do
    ( cd "$ROOT/services/demo-app" && APP_NAME="${spec%%:*}" python3 -c "from app import app; app.run(host='127.0.0.1', port=${spec##*:}, threaded=True)" \
      >"/tmp/kubeguard-demo-${spec%%:*}.log" 2>&1 ) &
    DEMO_PIDS+=($!)
  done
  export DEMO_URL_TEMPLATE="frontend=http://127.0.0.1:8101,backend=http://127.0.0.1:8102,database=http://127.0.0.1:8103"
}
start_demo_apps
trap 'kill "${DEMO_PIDS[@]}" 2>/dev/null || true' EXIT
launch() { python3 -c "from app.main import create_app; create_app().run(host='${HOST:-127.0.0.1}', port=$PORT, threaded=True)"; }

if (( ! WALK )); then
  echo "KubeGuard (simulator) -> http://localhost:$PORT   Open Experiments, or press Ctrl+K. Each app has its own UI: Applications > Open app. Ctrl+C to stop."
  launch; exit 0
fi

launch >/tmp/kubeguard-demo.log 2>&1 &
SERVER=$!
(( KEEP )) || trap 'kill $SERVER "${DEMO_PIDS[@]}" 2>/dev/null || true' EXIT
BASE="http://localhost:$PORT"
for _ in $(seq 1 40); do curl -sf "$BASE/api/health" >/dev/null && break; sleep 0.5; done
curl -sf "$BASE/api/health" >/dev/null || { echo "server did not start; see /tmp/kubeguard-demo.log"; exit 1; }

j(){ python3 -c "import sys,json;d=json.load(sys.stdin);print($1)"; }
post(){ curl -fsS -X POST -H 'Content-Type: application/json' -d "$2" "$BASE$1"; }
say(){ printf '\n\033[1;34m== %s\033[0m\n' "$*"; }
post /api/settings '{"sustain_seconds":8,"cooldown_seconds":5}' >/dev/null
echo "Dashboard: $BASE    (open it now; the walkthrough below drives it live)"

wait_for() {   # $1=type  $2=baseline id  -> prints incident id once it exists, then waits for it to finish
  local id=""; for _ in $(seq 1 60); do
    id=$(curl -s "$BASE/api/incidents" | j "next((str(i['id']) for i in d['incidents'] if i['id']>$2 and i['type']=='$1'),'')")
    [[ -n "$id" ]] && break; sleep 1; done
  [[ -z "$id" ]] && { echo "  not detected"; return 1; }
  echo "  detected as incident #$id"
  for _ in $(seq 1 90); do
    curl -s "$BASE/api/incidents/$id" | j "d['status']" | grep -qv ACTIVE && break; sleep 1; done
  curl -s "$BASE/api/incidents/$id" | j "'  -> %s via %s in %ss | before: cpu %s%% mem %s%% err %s%% | after: cpu %s%% mem %s%% err %s%%' % (d['status'], d['action'], d['recovery_seconds'], d['before']['cpu_pct'], d['before']['mem_pct'], d['before']['err_pct'], d['after']['cpu_pct'], d['after']['mem_pct'], d['after']['err_pct'])"
}
last(){ curl -s "$BASE/api/incidents" | j "max([i['id'] for i in d['incidents']] or [0])"; }

say "1/4 Crash a frontend pod"
post /api/experiments/crash '{"application":"frontend"}' | j "d['message']"
wait_for POD_FAILURE 0
say "2/4 CPU stress on backend (detected after 8 s sustained, then scaled out)"
B=$(last); post /api/experiments/cpu '{"application":"backend","seconds":60}' | j "d['message']"
wait_for CPU_OVERLOAD "$B"
say "3/4 Memory stress on database (rolling restart)"
B=$(last); post /api/experiments/memory '{"application":"database","seconds":60}' | j "d['message']"
wait_for MEMORY_PRESSURE "$B"
say "4/4 HTTP 500 errors on frontend (rolling restart)"
B=$(last); post /api/experiments/errors '{"application":"frontend","seconds":60}' | j "d['message']"
wait_for HIGH_ERROR_RATE "$B"
post /api/experiments/stop '{}' >/dev/null
say "Summary"
curl -s "$BASE/api/summary" | j "'incidents: %s, recovered: %s, success rate: %s%%, mean time to recovery: %ss' % (d['total'], d['recovered'], d['success_rate'], d['mttr_seconds'])"
if (( KEEP )); then echo; echo "Server left running on $BASE (pid $SERVER). Stop it with: kill $SERVER"; wait $SERVER; fi
