#!/usr/bin/env bash
# Single place to cut a release:  ./scripts/set-version.sh 2.3.0
# Rewrites VERSION, the app version, image tags in manifests/scripts, and the demo-app default.
# tests/test_manifests.py fails if any of these drift apart.
set -euo pipefail
NEW="${1:?usage: set-version.sh X.Y.Z}"
[[ "$NEW" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "version must look like 1.2.3"; exit 2; }
cd "$(dirname "$0")/.."
OLD="$(cat VERSION)"
echo "$NEW" > VERSION
sed -i -E "s#(kubeheal/(kubeheal|demo-app)):[0-9]+\.[0-9]+\.[0-9]+#\1:${NEW}#g" deploy/k8s/*.yaml uninstall.sh Makefile README.md
sed -i -E "s#^VERSION=\"[0-9.]+\"#VERSION=\"${NEW}\"#" install.sh
sed -i -E "s#^__version__ = \"[0-9.]+\"#__version__ = \"${NEW}\"#" services/kubeheal/app/__init__.py
sed -i -E "s#(APP_VERSION\", \")[0-9.]+(\")#\1${NEW}\2#" services/demo-app/app.py
echo "version ${OLD} -> ${NEW}"
