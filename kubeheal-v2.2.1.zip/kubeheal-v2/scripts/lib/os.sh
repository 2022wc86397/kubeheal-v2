#!/usr/bin/env bash
# OS detection shared by install.sh and the installer tests. Source this file; do not execute it.
# Sets: OS_ID OS_VERSION OS_FAMILY (debian|rhel) PKG (apt|dnf|yum) SELINUX_MODE
# Test hooks: OS_RELEASE_FILE=<file>, SELINUX_MODE=<Enforcing|Permissive|Disabled>

detect_os() {
  local f="${OS_RELEASE_FILE:-/etc/os-release}" like
  [[ -r "$f" ]] || { echo "cannot read $f" >&2; return 1; }
  # Parse in a subshell: os-release defines VERSION=..., which would clobber our own variables.
  # shellcheck source=/dev/null
  eval "$( . "$f"; printf 'OS_ID=%q OS_VERSION=%q like=%q' "${ID:-}" "${VERSION_ID:-}" "${ID_LIKE:-}" )"
  case "$OS_ID" in
    ubuntu|debian) OS_FAMILY=debian; PKG=apt ;;
    amzn)          OS_FAMILY=rhel;   if [[ "${OS_VERSION%%.*}" == 2 ]]; then PKG=yum; else PKG=dnf; fi ;;
    *)
      case " $like " in
        *" debian "*|*" ubuntu "*) OS_FAMILY=debian; PKG=apt ;;
        *) echo "unsupported OS '$OS_ID'. Supported: Amazon Linux 2023 / 2, Ubuntu, Debian." \
                "If docker and curl are already installed, re-run with SKIP_PACKAGES=1." >&2
           [[ "${SKIP_PACKAGES:-0}" == 1 ]] || return 2
           OS_FAMILY=other; PKG=none ;;
      esac ;;
  esac
  if [[ -n "${SELINUX_MODE:-}" ]]; then :; elif command -v getenforce >/dev/null 2>&1; then SELINUX_MODE="$(getenforce)"; else SELINUX_MODE=Disabled; fi
  export OS_ID OS_VERSION OS_FAMILY PKG SELINUX_MODE
}
