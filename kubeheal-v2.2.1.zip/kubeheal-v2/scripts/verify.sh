#!/usr/bin/env bash
# Checks the whole pipeline: pods (incl. READY), Prometheus targets and queries, then the KubeHeal API as the
# kubelet and as a logged-in user see it. Exit code 0 only if everything is healthy.
set -uo pipefail
export KUBECONFIG="${KUBECONFIG:-$HOME/.kube/config}"; [[ -r "$KUBECONFIG" ]] || export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
export PATH="$PATH:/usr/local/bin"
FAIL=0
ok(){ printf '\033[32mOK  \033[0m %s\n' "$*"; }; bad(){ printf '\033[31mBAD \033[0m %s\n' "$*"; FAIL=1; }

echo "== Pods"; kubectl get pods -A -o wide --no-headers | grep -E 'monitoring|kubeheal' || bad "no pods found"
echo; echo "== Readiness (Running is not enough: READY must be n/n)"
NOTREADY=$(kubectl get pods -A --no-headers | grep -E 'monitoring|kubeheal' | awk '{split($3,a,"/"); if (a[1]!=a[2] || $4!="Running") print $1"/"$2" "$3" "$4}')
[[ -z "$NOTREADY" ]] && ok "all pods ready" || { bad "pods not ready:"; echo "$NOTREADY" | sed 's/^/       /'; echo "       -> run scripts/diagnose.sh"; }

PROM="/api/v1/namespaces/monitoring/services/prometheus:9090/proxy"
echo; echo "== Prometheus scrape targets"
kubectl get --raw "$PROM/api/v1/targets" 2>/dev/null | python3 -c '
import sys, json
try: t = json.load(sys.stdin)["data"]["activeTargets"]
except Exception: print("BAD  Prometheus API not reachable"); sys.exit(1)
rc = 0
for job in sorted({x["labels"]["job"] for x in t}):
    allt = [x for x in t if x["labels"]["job"] == job]; up = [x for x in allt if x["health"] == "up"]
    good = bool(up) and len(up) == len(allt); rc |= 0 if good else 1
    print(("OK   " if good else "BAD  ") + f"{job}: {len(up)}/{len(allt)} targets up")
    for x in allt:
        if x["health"] != "up": print("       ", x["scrapeUrl"], "->", x.get("lastError", "")[:120])
sys.exit(rc)' || FAIL=1

q(){ kubectl get --raw "$PROM/api/v1/query?query=$(python3 -c 'import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))' "$1")" 2>/dev/null \
     | python3 -c 'import sys,json;r=json.load(sys.stdin)["data"]["result"];print(r[0]["value"][1] if r else "no data")' 2>/dev/null || echo "error"; }
echo; echo "== Key queries"
echo "node CPU %          : $(q '100 * sum(rate(container_cpu_usage_seconds_total{id="/"}[1m])) / sum(machine_cpu_cores)')"
echo "backend CPU cores   : $(q 'avg(sum by (pod) (rate(container_cpu_usage_seconds_total{namespace="kubeheal-demo",pod=~"backend-[a-z0-9]{8,10}-[a-z0-9]{5}",container!=""}[1m])))')"
echo "backend req/s       : $(q 'sum(rate(http_requests_total{namespace="kubeheal-demo",app="backend"}[1m]))')"

echo; echo "== KubeHeal API"
kubectl -n kubeheal-system exec deploy/kubeheal -- python -c '
import base64, json, os, sys, urllib.request, urllib.error
def get(path, auth=False):
    req = urllib.request.Request("http://localhost:8080" + path)
    if auth and os.environ.get("AUTH_PASSWORD"):
        req.add_header("Authorization", "Basic " + base64.b64encode(("admin:" + os.environ["AUTH_PASSWORD"]).encode()).decode())
    try: return urllib.request.urlopen(req, timeout=5).status, req
    except urllib.error.HTTPError as e: return e.code, req
rc = 0
for path in ("/api/health", "/api/ready"):                       # what the kubelet probes: no credentials
    code, _ = get(path); good = code == 200; rc |= 0 if good else 1
    print(("OK   " if good else "BAD  ") + f"{path} -> HTTP {code} (as kubelet)")
code, req = get("/api/overview", auth=True)
if code == 200:
    d = json.load(urllib.request.urlopen(req, timeout=5))
    print("OK   overview: cluster_connected=%s prometheus_ok=%s apps=%d pods=%d active_incidents=%d" % (d["cluster_connected"], d["prometheus_ok"], d["counts"]["applications"], d["counts"]["pods"], d["counts"]["active"]))
    for a in d["apps"]: print("       %-10s %s/%s ready  score %s%%  %s" % (a["name"], a["ready"], a["desired"], a["score"], a["status"]))
    if not d["cluster_connected"] or d["counts"]["applications"] == 0: rc = 1
else:
    print("BAD  /api/overview -> HTTP", code); rc = 1
sys.exit(rc)' 2>&1 || FAIL=1
echo; (( FAIL )) && { printf '\033[31mVERIFY FAILED\033[0m  (run scripts/diagnose.sh and share the report)\n'; exit 1; } || printf '\033[32mVERIFY PASSED\033[0m\n'
