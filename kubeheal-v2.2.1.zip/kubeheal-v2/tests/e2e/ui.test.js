/* End-to-end UI test in a real headless Chromium against a running KubeHeal (simulator or cluster).
 *   BASE=http://localhost:8080 node ui.test.js            (OUT=dir saves screenshots)
 * Needs the simulator's fast settings (see run-e2e.sh) because it waits for real detection + recovery.
 */
const puppeteer = require('puppeteer-core');
const BASE = process.env.BASE || 'http://localhost:8080';
const OUT = process.env.OUT || '';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = []; const problems = [];
const check = (name, ok, extra = '') => { results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`); };
const post = (p, b) => fetch(BASE + p, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(b || {})}).then(r => r.json());

async function until(fn, ms = 30000, step = 250) { const end = Date.now() + ms; while (Date.now() < end) { try { const v = await fn(); if (v) return v; } catch (_) {} await sleep(step); } return null; }

(async () => {
  let exe = process.env.CHROME_PATH;
  if (!exe) { const c = require('@sparticuz/chromium'); exe = await (c.default || c).executablePath(); var args = (c.default || c).args; }
  const browser = await puppeteer.launch({executablePath: exe, headless: 'shell', args: [...(args || []), '--no-sandbox']});
  const page = await browser.newPage();
  await page.setViewport({width: 1360, height: 900, deviceScaleFactor: 1.5});
  page.on('pageerror', e => problems.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') problems.push('console: ' + m.text()); });
  page.on('requestfailed', r => problems.push('request failed: ' + r.url()));
  const shot = async n => { if (OUT) await page.screenshot({path: `${OUT}/${n}.png`, fullPage: true}); };
  const go = async h => { await page.goto(`${BASE}/#/${h}`); await page.reload({waitUntil: 'networkidle0'}); await sleep(900); };
  const text = sel => page.$eval(sel, e => e.innerText).catch(() => '');

  // ---- fast detection for the test, clean slate for theme
  await post('/api/settings', {sustain_seconds: 5, cooldown_seconds: 5});
  await page.goto(BASE); await page.evaluate(() => localStorage.removeItem('kg-theme'));   // once: start in the default theme

  // ---- redesigned dashboard: hero + cluster map before any fault
  await go('dashboard');
  await until(() => page.$('.pod-t'), 8000);
  check('hero reports all systems operational', /All systems operational/.test(await text('#d-hero')), await text('#d-hero'));
  const apiPods = (await (await fetch(BASE + '/api/pods')).json()).pods.length;
  check('cluster map has one tile per pod', (await page.$$('.pod-t:not(.ghost)')).length === apiPods, `${(await page.$$('.pod-t')).length} vs ${apiPods}`);
  check('hero ring shows a health score', /\d+%/.test(await text('.hring')));
  await shot('00-dashboard-hero');

  // ---- command palette + keyboard shortcuts
  await page.keyboard.down('Control'); await page.keyboard.press('k'); await page.keyboard.up('Control');
  check('Ctrl+K opens the command palette', await page.$eval('#pal', e => e.classList.contains('on')));
  await page.keyboard.type('cpu backend'); await sleep(200);
  check('palette ranks the matching command first', /Run CPU stress on backend/.test(await text('#pal-list li[aria-selected="true"]')), await text('#pal-list'));
  await shot('00b-palette');
  await page.keyboard.press('Escape');
  check('Escape closes the palette', !(await page.$eval('#pal', e => e.classList.contains('on'))));
  await page.keyboard.down('Control'); await page.keyboard.press('k'); await page.keyboard.up('Control');
  await page.keyboard.type('go to incid'); await page.keyboard.press('Enter'); await sleep(500);
  check('palette navigates with Enter', page.url().endsWith('#/incidents'), page.url());
  await page.keyboard.press('g'); await page.keyboard.press('e'); await sleep(400);
  check('keyboard shortcut g then e opens Experiments', page.url().endsWith('#/experiments'), page.url());

  // ---- pause / resume live updates
  await go('dashboard');
  await page.click('[data-act="pause"]'); await sleep(300);
  check('pause shows Paused in the sidebar', /Paused/.test(await text('#live')));
  await page.click('[data-act="pause"]'); await sleep(300);
  check('resume shows Live again', /Live/.test(await text('#live')));

  // ---- experiments page + active chip
  await go('experiments');
  check('experiment cards render', (await page.$$('.exp')).length === 4);
  await page.select('#xapp', 'backend'); await page.select('#xsec', '120');
  await page.click('[data-k="cpu"]');
  check('CPU stress shows active chip', !!(await until(async () => (await text('#xactive')).includes('CPU stress on backend'), 8000)));

  // ---- live banner + nav badge while incident is active
  await go('dashboard');
  const live = await until(() => page.$('.live'), 40000, 150);
  check('live recovery banner appears', !!live);
  check('hero switches to "Recovering backend"', /Recovering backend/.test(await text('#d-hero')), await text('#d-hero'));
  check('sidebar badge shows active count', (await text('#nb')).trim() === '1');
  check('tab title shows active count', (await page.title()).startsWith('(1)'));
  await shot('01-dashboard-live');
  if (live) { await page.click('.live a'); await sleep(1200); }
  check('live incident detail with elapsed timer', /elapsed/.test(await text('#main')) && /Recovery Progress/.test(await text('#main')));
  await shot('02-incident-live');

  // ---- recovery completes; toast announced
  const toastSeen = await until(async () => /recovered/i.test(await text('#toast')), 45000, 200);
  check('toast announces recovery', !!toastSeen);
  const recovered = await until(async () => /Recovered/.test(await text('#main')), 30000);
  check('incident detail ends Recovered', !!recovered);
  await shot('03-incident-recovered');
  await post('/api/experiments/stop', {application: 'backend'});

  // ---- incidents list: swimlane, summary + CSV
  await go('incidents');
  await until(() => page.$('#lane svg a rect'), 8000);
  check('incident swimlane draws the incident bar', !!(await page.$('#lane svg a[href^="#/incidents/"] rect')));
  await until(async () => /Mean time/.test(await text('#strip')), 8000);
  const strip = await text('#strip');
  check('summary strip has MTTR + success rate', /Mean time to recovery/.test(strip) && /100%/.test(strip), strip);
  const csv = await page.$eval('a[download]', a => a.getAttribute('href'));
  check('CSV export link present', csv === '/api/incidents.csv');
  const csvText = await (await fetch(BASE + csv)).text();
  check('CSV contains the incident', /backend,CPU_OVERLOAD,High,RECOVERED/.test(csvText), csvText.slice(0, 200));
  await shot('04-incidents');

  // ---- metrics: markers, threshold, tooltip
  await go('metrics/backend');
  await until(() => page.$('#c-cpu svg'), 8000);
  check('incident marker on CPU chart', !!(await page.$('#c-cpu a[href^="#/incidents/"]')));
  check('threshold label on CPU chart', /critical 90%/.test(await page.$eval('#c-cpu', e => e.innerHTML)));
  const box = await (await page.$('#c-cpu svg')).boundingBox();
  await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5); await sleep(300);
  const tip = await page.$eval('#c-cpu .tip', e => ({d: getComputedStyle(e).display, t: e.innerText}));
  check('hover tooltip shows time + value', tip.d === 'block' && /CPU: \d/.test(tip.t), JSON.stringify(tip));
  await shot('05-metrics-tooltip');

  // ---- demo application UI, opened through KubeGuard's proxy
  await go('applications');
  check('"Open app" link on application cards', !!(await page.$('a[href="/demo/backend/"]')));
  const demo = await browser.newPage(); await demo.setViewport({width: 1280, height: 900, deviceScaleFactor: 1.5});
  const dproblems = [];
  demo.on('pageerror', e => dproblems.push(e.message)); demo.on('console', m => { if (m.type() === 'error' && !/status of 500/.test(m.text())) dproblems.push(m.text()); });   // 500s are the injected fault, on purpose
  await demo.goto(`${BASE}/demo/backend/`, {waitUntil: 'networkidle0'});
  await demo.waitForFunction(() => document.querySelector('#v-mem').textContent !== '–', {timeout: 10000}).catch(() => {});
  const dt = sel => demo.$eval(sel, e => e.innerText).catch(() => '');
  check('demo UI renders with live stats', /backend/i.test(await dt('h1')) && (await dt('#v-mem')) !== '–' && /Healthy/.test(await dt('#status')), await dt('#status'));
  check('demo UI shows KubeGuard link + whole-app scope when proxied', !(await demo.$eval('#kg', e => e.hidden)) && !(await demo.$eval('#sc-app', e => e.hidden)));
  await demo.click('[data-n="20"]'); await demo.waitForFunction(() => /20 sent/.test(document.querySelector('#gen-sum').textContent), {timeout: 15000}).catch(() => {});
  check('traffic generator sends requests and logs the serving pod', /20 sent/.test(await dt('#gen-sum')) && (await demo.$$('#log tr')).length >= 10, await dt('#gen-sum'));
  await demo.click('.fault[data-k="errors"]');
  const faulted = await demo.waitForFunction(() => document.querySelectorAll('#active .af').length > 0, {timeout: 8000}).then(() => true, () => false);
  check('pod-scope error fault shows an active fault chip', faulted);
  await demo.click('[data-n="20"]'); await sleep(2500);
  check('status leaves Healthy while the fault is active', !/^Healthy$/.test((await dt('#status')).trim()), await dt('#status'));
  await demo.screenshot({path: OUT ? `${OUT}/12-demo-app-fault.png` : '/dev/null', fullPage: true});
  await demo.click('#stopfaults'); await sleep(2200);
  check('Stop all faults clears the chips', (await demo.$$('#active .af')).length === 0);
  await demo.click('#sc-app'); await demo.click('.fault[data-k="memory"]'); await sleep(900);
  check('whole-application scope goes through KubeGuard', /injected|fault/i.test(await dt('#toast')), await dt('#toast'));
  await post('/api/experiments/stop', {});
  await demo.setViewport({width: 390, height: 844, deviceScaleFactor: 2, isMobile: true}); await sleep(500);
  check('demo UI has no horizontal overflow on mobile', (await demo.evaluate(() => document.documentElement.scrollWidth - innerWidth)) <= 1);
  if (OUT) await demo.screenshot({path: `${OUT}/13-demo-app-mobile.png`, fullPage: true});
  check('demo UI had no JS errors', dproblems.length === 0, dproblems.join(' | '));
  const direct = await fetch('http://127.0.0.1:8102/', {headers: {Accept: 'application/json'}});
  check('demo app still answers plain JSON to API clients', (await direct.json()).app === 'backend');
  await demo.close();
  await post('/api/experiments/stop', {application: 'backend'});

  // ---- pods mini bars
  await go('pods'); await until(() => page.$('.minibar'), 8000);
  check('pod rows show usage bars', (await page.$$('.minibar')).length > 0);

  // ---- settings reset
  await go('settings');
  await page.$eval('#s_cpu_critical', e => e.value = '75');
  page.once('dialog', d => d.accept());
  await page.click('#reset'); await sleep(1200);
  check('settings reset restores defaults', (await page.$eval('#s_cpu_critical', e => e.value)) === '90');
  await post('/api/settings', {sustain_seconds: 5, cooldown_seconds: 5});

  // ---- dark mode toggle + persistence
  await go('dashboard');
  const bgLight = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  await page.click('#theme'); await sleep(300);
  const bgDark = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  check('dark mode changes the theme', bgLight !== bgDark && (await page.evaluate(() => document.documentElement.dataset.theme)) === 'dark');
  await page.reload({waitUntil: 'networkidle0'}); await sleep(900);
  check('theme persists across reload', (await page.evaluate(() => document.documentElement.dataset.theme)) === 'dark');
  await shot('06-dashboard-dark');
  await go('experiments'); await shot('07-experiments-dark');
  await go('metrics/backend'); await sleep(800); await shot('08-metrics-dark');
  await page.click('#theme');

  // ---- responsive: no horizontal overflow on any route at phone width
  await page.setViewport({width: 390, height: 844, deviceScaleFactor: 2, isMobile: true});
  for (const r of ['dashboard', 'applications', 'pods', 'incidents', 'experiments', 'metrics/backend', 'settings']) {
    await go(r);
    const over = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    check(`no horizontal overflow on mobile: ${r}`, over <= 1, `overflow ${over}px`);
    if (r === 'dashboard') await shot('09-mobile-dashboard');
    if (r === 'experiments') await shot('10-mobile-experiments');
  }

  check('no JS errors / failed requests', problems.length === 0, '\n   ' + problems.join('\n   '));
  await browser.close();
  const failed = results.filter(x => !x).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('E2E crashed:', e); process.exit(2); });
