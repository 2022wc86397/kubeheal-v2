import base64
import time

import pytest

from app.config import Config
from app.main import create_app


@pytest.fixture
def client(rt):
    rt.monitor.tick()
    return create_app(Config(), runtime=rt, start_threads=False).test_client()


def test_health_and_config(client):
    assert client.get("/api/health").json["status"] == "ok"
    assert client.get("/api/config").json["brand"] == "KubeGuard"
    assert client.get("/").status_code == 200


def test_overview_shape(client):
    d = client.get("/api/overview").json
    assert d["cluster_connected"] and d["counts"]["applications"] == 3
    assert d["counts"]["pods"] == 5 and d["counts"]["running"] == 5
    assert {a["name"] for a in d["apps"]} == {"frontend", "backend", "database"}
    assert d["cluster"]["pods_max"] == 12


def test_experiment_and_incident_endpoints(client, rt):
    r = client.post("/api/experiments/crash", json={"application": "frontend"})
    assert r.status_code == 200 and r.json["ok"]
    iid = r.json["incident"]
    d = client.get(f"/api/incidents/{iid}").json
    assert d["type_label"] == "Pod Failure" and len(d["steps"]) == 5
    assert rt.wait(lambda: client.get(f"/api/incidents/{iid}").json["status"] == "RECOVERED", 30)
    assert client.get("/api/incidents?status=recovered").json["incidents"][0]["id"] == iid
    assert client.get("/api/incidents/9999").status_code == 404


def test_experiment_errors(client):
    assert client.post("/api/experiments/cpu", json={"application": "nope"}).status_code == 404
    assert client.post("/api/experiments/nope", json={}).status_code == 404
    assert client.post("/api/experiments/cpu", json={"seconds": "x"}).status_code == 400


def test_settings_validation(client):
    assert client.post("/api/settings", json={"cpu_critical": 75}).json["cpu_critical"] == 75
    assert client.post("/api/settings", json={"cpu_critical": "abc"}).status_code == 400


def test_add_and_remove_application(client):
    assert client.get("/api/candidates").json["candidates"] == ["analytics"]
    assert client.post("/api/apps", json={"name": "ghost"}).status_code == 404
    assert client.post("/api/apps", json={"name": "analytics"}).json["ok"]
    assert "analytics" in {a["name"] for a in client.get("/api/apps").json["apps"]}
    assert client.delete("/api/apps/analytics").json["ok"]
    assert client.delete("/api/apps/analytics").status_code == 404


def test_metrics_endpoints(client):
    assert client.get("/api/metrics/app/backend?range=1h").status_code == 200
    assert client.get("/api/metrics/app/zzz").status_code == 404
    assert "cpu" in client.get("/api/metrics/overview").json


def test_pod_delete_only_for_known_pods(client):
    assert client.post("/api/pods/not-a-pod/delete").status_code == 404
    name = client.get("/api/pods?app=database").json["pods"][0]["name"]
    assert client.post(f"/api/pods/{name}/delete").json["ok"]


def test_basic_auth(rt):
    cfg = Config()
    cfg.auth_password = "s3cret"
    c = create_app(cfg, runtime=rt, start_threads=False).test_client()
    assert c.get("/api/overview").status_code == 401
    assert c.get("/api/health").status_code == 200            # probes must keep working
    tok = base64.b64encode(b"admin:s3cret").decode()
    assert c.get("/api/overview", headers={"Authorization": f"Basic {tok}"}).status_code == 200
    bad = base64.b64encode(b"admin:nope").decode()
    assert c.get("/api/overview", headers={"Authorization": f"Basic {bad}"}).status_code == 401
