import time

import pytest

from app.config import Config
from app.db import DEFAULT_SETTINGS, MAX_INCIDENTS, Store
from app.main import create_app
from app.notify import Notifier


class FakeHttp:
    def __init__(self, fail=False):
        self.calls, self.fail = [], fail

    def post(self, url, json, timeout):
        if self.fail:
            raise ConnectionError("down")
        self.calls.append((url, json))


INC = {"id": 7, "application": "backend", "type_label": "CPU Overload", "severity": "High",
       "description": "d", "action": "Scale Replicas", "recovery_seconds": 4.2}


def test_notifier_messages_and_delivery():
    h = FakeHttp()
    n = Notifier("http://hook", session=h)
    assert "incident #7 opened" in n.send("opened", INC, wait=True)
    n.send("recovered", INC, wait=True)
    assert len(h.calls) == 2 and "in 4.2s" in h.calls[1][1]["text"] and h.calls[1][1]["content"]


def test_notifier_disabled_and_failure_are_silent():
    assert Notifier("").send("opened", INC) is None
    Notifier("http://x", session=FakeHttp(fail=True)).send("failed", INC, wait=True)   # must not raise


def test_recovery_sends_webhooks(rt):
    h = FakeHttp()
    rt.recovery.notifier = Notifier("http://hook", session=h)
    rt.monitor.tick()
    rt.experiments.run("crash", "frontend")
    assert rt.wait(lambda: any("recovered" in c[1]["text"] for c in h.calls), 30)
    assert "opened" in h.calls[0][1]["text"]


def test_summary_mttr_success_rate_and_retention(tmp_path):
    s = Store(str(tmp_path / "s.db"))
    assert s.summary()["success_rate"] is None
    a = s.create_incident("a", "CPU_OVERLOAD", "High", "d", {})
    b = s.create_incident("a", "POD_FAILURE", "High", "d", {})
    s.update_incident(a, status="RECOVERED", recovery_seconds=10)
    s.update_incident(b, status="FAILED", recovery_seconds=99)
    sm = s.summary()
    assert sm["success_rate"] == 50.0 and sm["mttr_seconds"] == 10.0 and sm["by_type"]["CPU_OVERLOAD"] == 1
    for _ in range(MAX_INCIDENTS + 5):
        s.create_incident("a", "POD_FAILURE", "High", "d", {})
    assert len(s.list_incidents(limit=5000)) == MAX_INCIDENTS


@pytest.fixture
def client(rt):
    rt.monitor.tick()
    return create_app(Config(), runtime=rt, start_threads=False).test_client()


def test_ready_and_overview_extras(client, rt):
    assert client.get("/api/ready").status_code == 200
    rt.experiments.run("crash", "backend")
    d = client.get("/api/overview").json
    assert d["active_incidents"][0]["application"] == "backend"
    assert rt.wait(lambda: client.get("/api/overview").json["counts"]["active"] == 0, 30)


def test_csv_export_and_summary(client, rt):
    rt.experiments.run("crash", "frontend")
    assert rt.wait(lambda: client.get("/api/summary").json["recovered"] == 1, 30)
    r = client.get("/api/incidents.csv")
    assert r.mimetype == "text/csv" and "attachment" in r.headers["Content-Disposition"]
    lines = r.data.decode().strip().splitlines()
    assert lines[0].startswith("id,detected_at") and "frontend" in lines[1] and "RECOVERED" in lines[1]


def test_active_experiments_listing_and_stop(client):
    assert client.get("/api/experiments/active").json["active"] == []
    assert client.post("/api/experiments/cpu", json={"application": "backend", "seconds": 60}).json["ok"]
    act = client.get("/api/experiments/active").json["active"]
    assert act[0]["kind"] == "cpu" and 0 < act[0]["seconds_left"] <= 60
    client.post("/api/experiments/stop", json={"application": "backend"})
    assert client.get("/api/experiments/active").json["active"] == []


def test_metrics_app_has_thresholds_and_incident_markers(client, rt):
    rt.experiments.run("crash", "frontend")
    d = client.get("/api/metrics/app/frontend?range=15m").json
    assert d["thresholds"]["cpu"] == 90 and d["incidents"][0]["label"] == "Pod Failure"
    assert rt.wait(lambda: client.get("/api/summary").json["active"] == 0, 30)


def test_settings_reset(client):
    client.post("/api/settings", json={"cpu_critical": 70})
    assert client.post("/api/settings/reset").json == DEFAULT_SETTINGS


def test_planned_scale_out_is_not_scored_as_lost_availability(rt):
    rt.monitor.tick()                                        # records baseline = 2
    rt.world.scale("backend", 3)
    rt.monitor.tick()
    a = rt.monitor.app_state("backend")
    assert (a["ready"], a["desired"], a["baseline"]) == (2, 3, 2)
    assert a["status"] == "healthy" and a["score"] >= 85


def test_real_pod_loss_still_scores_badly(rt):
    rt.monitor.tick()
    victim = rt.world.list_pods("backend")[0].name
    rt.world.delete_pod(victim)
    rt.world.startup = 600                                   # replacement never becomes ready
    rt.world.list_pods("backend")                            # controller spawns the stuck replacement
    rt.monitor.tick()
    a = rt.monitor.app_state("backend")
    assert a["ready"] == 1 and a["status"] == "critical"
