"""Real backends exercised with fakes: Kubernetes object mapping and PromQL generation."""
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace as NS

from app.k8s import KubeCluster, parse_cpu, parse_mem, MONITOR_LABEL, BASELINE_ANN
from app.models import AppInfo
from app.prom import PromMetrics, pod_regex


def test_quantity_parsing():
    assert parse_cpu("200m") == 0.2 and parse_cpu("1") == 1.0 and parse_cpu("500u") == 0.0005
    assert parse_mem("192Mi") == 192 * 2**20 and parse_mem("1Gi") == 2**30 and parse_mem("500M") == 5e8


def _deployment(limits=True, scrape=True, baseline="2"):
    lim = {"cpu": "200m", "memory": "192Mi"} if limits else None
    c = NS(resources=NS(limits=lim))
    return NS(metadata=NS(name="backend", annotations={BASELINE_ANN: baseline} if baseline else {}, labels={MONITOR_LABEL: "true"}),
              spec=NS(replicas=2, template=NS(metadata=NS(annotations={"prometheus.io/scrape": "true"} if scrape else None),
                                              spec=NS(containers=[c]))),
              status=NS(ready_replicas=1, updated_replicas=2, replicas=2))


def _cluster():
    kc = KubeCluster.__new__(KubeCluster)
    kc.ns = "kubeheal-demo"
    return kc


def test_deployment_to_appinfo():
    a = _cluster()._app(_deployment())
    assert (a.desired, a.ready, a.updated, a.baseline) == (2, 1, 2, 2)
    assert a.cpu_limit == 0.2 and a.mem_limit == 192 * 2**20 and a.has_app_metrics
    assert not a.rollout_complete                       # 1 of 2 ready


def test_missing_limits_yield_none_not_wrong_percentages():
    a = _cluster()._app(_deployment(limits=False, scrape=False, baseline=None))
    assert a.cpu_limit is None and a.mem_limit is None and not a.has_app_metrics and a.baseline is None


def _pod(name, owner="backend-5d9f8c6b4", ready=True, waiting=None, deleting=False, restarts=0):
    state = NS(waiting=NS(reason=waiting)) if waiting else NS(waiting=None)
    return NS(metadata=NS(name=name, labels={"app": "backend"}, deletion_timestamp=datetime.now() if deleting else None,
                          owner_references=[NS(kind="ReplicaSet", name=owner)],
                          creation_timestamp=datetime.now(timezone.utc) - timedelta(seconds=120)),
              spec=NS(node_name="n1"),
              status=NS(phase="Running", pod_ip="10.0.0.5",
                        conditions=[NS(type="Ready", status="True" if ready else "False")],
                        container_statuses=[NS(restart_count=restarts, state=state, last_state=NS(terminated=None))]))


def test_pod_mapping_and_states():
    kc = _cluster()
    kc.core = NS(list_namespaced_pod=lambda ns: NS(items=[
        _pod("backend-5d9f8c6b4-aaaaa"), _pod("backend-5d9f8c6b4-bbbbb", ready=False, waiting="CrashLoopBackOff", restarts=4),
        _pod("db-7c7d8e9f1-ccccc", owner="db-7c7d8e9f1"), _pod("backend-5d9f8c6b4-ddddd", deleting=True)]))
    pods = {p.name: p for p in kc.list_pods()}
    assert pods["backend-5d9f8c6b4-aaaaa"].app == "backend" and pods["db-7c7d8e9f1-ccccc"].app == "db"
    assert pods["backend-5d9f8c6b4-bbbbb"].status == "CrashLoopBackOff" and pods["backend-5d9f8c6b4-bbbbb"].restarts == 4
    assert pods["backend-5d9f8c6b4-ddddd"].status == "Terminating"
    assert [p.name for p in kc.list_pods("db")] == ["db-7c7d8e9f1-ccccc"]


def test_quota_and_actions_call_expected_api():
    calls = []
    kc = _cluster()
    kc.core = NS(list_namespaced_resource_quota=lambda ns: NS(items=[NS(status=NS(hard={"pods": "10"}, used={"pods": "7"}))]))
    kc.apps = NS(patch_namespaced_deployment_scale=lambda n, ns, b: calls.append(("scale", n, b)),
                 patch_namespaced_deployment=lambda n, ns, b: calls.append(("patch", n, b)))
    assert kc.quota_pods() == (7, 10)
    kc.scale("backend", 3)
    kc.rolling_restart("backend")
    kc.set_monitor("x", False)
    assert calls[0] == ("scale", "backend", {"spec": {"replicas": 3}})
    assert "kubectl.kubernetes.io/restartedAt" in calls[1][2]["spec"]["template"]["metadata"]["annotations"]
    assert calls[2][2]["metadata"]["labels"][MONITOR_LABEL] is None       # null removes the label


class FakeSession:
    def __init__(self, values=None):
        self.queries, self.values = [], values or {}

    def get(self, url, params, timeout):
        self.queries.append(params["query"])
        val = next((v for k, v in self.values.items() if k in params["query"]), None)
        res = [] if val is None else [{"metric": {}, "value": [0, str(val)]}]
        return NS(raise_for_status=lambda: None, json=lambda: {"status": "success", "data": {"result": res}})


def test_pod_regex_is_specific():
    import re
    rx = re.compile(pod_regex("backend") + "$")
    assert rx.match("backend-5d9f8c6b4-abcde")
    assert not rx.match("backend-db-5d9f8c6b4-abcde")          # a different deployment sharing a prefix
    assert not rx.match("backend-5d9f8c6b4-abcde-extra")


def test_app_metrics_percentages_and_traffic_gate():
    s = FakeSession({"container_cpu_usage_seconds_total": 0.19, "container_memory_working_set_bytes": 100 * 2**20,
                     "sum(rate(http_requests_total{namespace": 3.0})
    pm = PromMetrics("http://p", "kubeheal-demo", session=s)
    app = AppInfo("backend", 2, 2, 2, 2, cpu_limit=0.2, mem_limit=200 * 2**20, has_app_metrics=True)
    m = pm.app_metrics(app)
    assert round(m["cpu_pct"]) == 95 and round(m["mem_pct"]) == 50
    assert any('namespace="kubeheal-demo"' in q and 'container!="POD"' in q for q in s.queries)
    assert any('or vector(0)' in q for q in s.queries)          # error-rate query survives having zero 5xx series


def test_no_traffic_means_no_error_or_latency_numbers():
    s = FakeSession({"container_cpu": 0.1, "sum(rate(http_requests_total{namespace": 0.0})
    app = AppInfo("backend", 2, 2, 2, 2, cpu_limit=0.2, mem_limit=1.0, has_app_metrics=True)
    m = PromMetrics("http://p", "n", session=s).app_metrics(app)
    assert m["err_pct"] is None and m["resp_ms"] is None


def test_prometheus_down_returns_none_and_flags_not_ok():
    class Boom:
        def get(self, *a, **k):
            raise ConnectionError("down")
    pm = PromMetrics("http://p", "n", session=Boom())
    app = AppInfo("a", 1, 1, 1, 1, cpu_limit=0.2, mem_limit=1.0)
    assert pm.app_metrics(app)["cpu_pct"] is None and pm.ok is False
