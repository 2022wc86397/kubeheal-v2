"""KubeCluster (real kubernetes client) against a fake API server that enforces real wire-protocol rules."""
import time

import pytest
from kubernetes import client

import fake_apiserver as fake
from app.db import Store
from app.k8s import KubeCluster
from app.monitor import Monitor
from app.recovery import Recovery


@pytest.fixture
def env():
    st, srv, url = fake.start()
    cfg = client.Configuration()
    cfg.host = url
    api = client.ApiClient(cfg)
    kc = KubeCluster.__new__(KubeCluster)
    kc.ns, kc.core, kc.apps = fake.NS, client.CoreV1Api(api), client.AppsV1Api(api)
    yield kc, st
    srv.shutdown()


def calls(st, method):
    return [c for c in st.log if c[0] == method]


def test_list_apps_uses_label_selector_and_parses_real_models(env):
    kc, st = env
    apps = kc.list_apps()
    assert [a.name for a in apps] == ["backend", "database", "frontend"]            # analytics is unmonitored
    b = apps[0]
    assert (b.desired, b.ready, b.updated, b.replicas) == (2, 2, 2, 2) and b.rollout_complete
    assert b.cpu_limit == 0.2 and b.mem_limit == 192 * 2**20 and b.has_app_metrics
    assert calls(st, "GET")[0][2]["labelSelector"] == ["kubeheal.io/monitor=true"]


def test_pods_are_mapped_to_their_deployment_and_states_are_detected(env):
    kc, st = env
    st.pod_state["backend-5d9f8c6b4-aaaaa"] = {"reason": "CrashLoopBackOff"}
    pods = {p.name: p for p in kc.list_pods()}
    assert len(pods) == 6 and {p.app for p in pods.values()} == {"frontend", "backend", "database", "analytics"}
    bad = pods["backend-5d9f8c6b4-aaaaa"]
    assert bad.status == "CrashLoopBackOff" and not bad.ready and bad.ip == "10.42.0.9"
    assert [p.name for p in kc.list_pods("database")] == ["database-5d9f8c6b4-aaaaa"]


def test_quota_and_candidates(env):
    kc, st = env
    assert kc.quota_pods() == (6, 12)
    assert kc.candidates() == ["analytics"]


def test_actions_send_patch_types_a_real_api_server_accepts(env):
    kc, st = env
    kc.scale("backend", 3)
    kc.rolling_restart("backend")
    kc.set_baseline("backend", 2)
    kc.set_monitor("analytics", True)
    kc.set_monitor("analytics", False)
    patches = calls(st, "PATCH")
    assert len(patches) == 5
    for _, path, _, ctype, body in patches:
        assert ctype.split(";")[0] in fake.PATCH_TYPES, f"{path} used {ctype}: a real API server would answer 415"
    assert patches[0][1].endswith("/deployments/backend/scale") and patches[0][4] == {"spec": {"replicas": 3}}
    assert st.deps["backend"]["replicas"] == 3 and st.deps["backend"]["baseline"] == 2
    assert st.deps["analytics"]["monitored"] is False                          # null removed the label


def test_delete_pod_sets_grace_period(env):
    kc, st = env
    kc.delete_pod("backend-5d9f8c6b4-aaaaa", grace=0)
    method, path, query, _, _ = calls(st, "DELETE")[0]
    assert path.endswith("/pods/backend-5d9f8c6b4-aaaaa") and query.get("gracePeriodSeconds") == ["0"]


class StubMetrics:
    """Prometheus stand-in: CPU is high until the Deployment has 3 replicas, as with the real scale-out."""
    ok = True

    def __init__(self, st):
        self.st = st

    def app_metrics(self, app):
        reps = self.st.deps[app.name]["replicas"]
        cpu = 95.0 if (app.name == "backend" and reps < 3) else 30.0
        return {"cpu_pct": cpu, "mem_pct": 30.0, "cpu_cores": 0.06, "mem_mib": 60, "resp_ms": 90, "err_pct": 0.1, "req_rate": 3.0}

    def cluster_metrics(self):
        return {"cpu_pct": 40.0, "mem_pct": 50.0}

    def pod_metrics(self):
        return {}


def test_full_cpu_recovery_through_the_real_client(env, tmp_path):
    """Detect -> scale out -> verify, with every Kubernetes call going through the real client and wire protocol."""
    kc, st = env
    store = Store(str(tmp_path / "k.db"))
    store.save_settings({"sustain_seconds": 0, "cooldown_seconds": 0, "verify_timeout": 30})
    rec = Recovery(kc, StubMetrics(st), store, poll=0.2)
    mon = Monitor(kc, StubMetrics(st), store, rec, interval=0.2)
    end = time.time() + 30
    while time.time() < end:
        mon.tick()
        inc = next(iter(store.list_incidents()), None)
        if inc and inc["status"] != "ACTIVE":
            break
        time.sleep(0.2)
    inc = store.list_incidents()[0]
    assert inc["type"] == "CPU_OVERLOAD" and inc["status"] == "RECOVERED" and inc["action"] == "Scale Replicas", inc
    assert st.deps["backend"]["replicas"] == 3 and st.deps["backend"]["baseline"] == 2
    assert all(c[3].split(";")[0] in fake.PATCH_TYPES for c in calls(st, "PATCH"))
