from app.db import Store, DEFAULT_SETTINGS


def test_settings_roundtrip_and_clamping(tmp_path):
    s = Store(str(tmp_path / "a.db"))
    assert s.get_settings() == DEFAULT_SETTINGS
    out = s.save_settings({"cpu_critical": 500, "max_replicas": 0, "auto_recovery": 0, "bogus": 1})
    assert out["cpu_critical"] == 100 and out["max_replicas"] == 1 and out["auto_recovery"] == 0
    assert "bogus" not in out


def test_incident_lifecycle(tmp_path):
    s = Store(str(tmp_path / "a.db"))
    iid = s.create_incident("backend", "CPU_OVERLOAD", "High", "d", {"cpu_pct": 93})
    s.update_incident(iid, after={"cpu_pct": 60}, status="RECOVERED", resolved_at=1.0)
    i = s.get_incident(iid)
    assert i["before"]["cpu_pct"] == 93 and i["after"]["cpu_pct"] == 60 and i["status"] == "RECOVERED"
    assert [x["id"] for x in s.list_incidents("recovered")] == [iid]
    assert s.list_incidents("failed") == []


def test_stale_incidents_are_closed_on_restart(tmp_path):
    s = Store(str(tmp_path / "a.db"))
    iid = s.create_incident("a", "POD_FAILURE", "High", "d", {})
    s.close_stale()
    assert s.get_incident(iid)["status"] == "FAILED"
    assert s.counts()["active"] == 0
