"""A small stateful fake of the Kubernetes REST API (apps/v1 deployments + core/v1 pods, quotas).

It speaks the real wire protocol, so the real `kubernetes` Python client talks to it unmodified. That catches things
mocks cannot: wrong PATCH content types (a real API server answers 415), bad label selectors, model parsing errors.
"""
import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

NS = "kubeheal-demo"
PATCH_TYPES = {"application/strategic-merge-patch+json", "application/merge-patch+json", "application/json-patch+json"}


def _iso(t):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))


class State:
    def __init__(self):
        self.lock = threading.RLock()
        self.log = []                                   # (method, path, query, content_type, body)
        self.deps = {}
        self.quota = {"hard": {"pods": "12"}, "used": {"pods": "0"}}
        for name, replicas, monitored in [("frontend", 2, True), ("backend", 2, True), ("database", 1, True), ("analytics", 1, False)]:
            self.deps[name] = {"replicas": replicas, "rs": "5d9f8c6b4", "monitored": monitored, "baseline": None, "restarts": 0,
                               "annotations": {}, "ready_after": 0.0}
        self.pod_state = {}                             # pod name -> {"reason": str|None}
        self.deleted = []

    def pods(self, name):
        d = self.deps[name]
        return [f"{name}-{d['rs']}-{chr(97 + i) * 5}" for i in range(d["replicas"]) if f"{name}-{d['rs']}-{chr(97 + i) * 5}" not in self.deleted]


def deployment_json(st, name):
    d = st.deps[name]
    labels = {"app": name}
    if d["monitored"]:
        labels["kubeheal.io/monitor"] = "true"
    ann = dict(d["annotations"])
    if d["baseline"] is not None:
        ann["kubeheal.io/baseline-replicas"] = str(d["baseline"])
    ready = len(st.pods(name)) if time.time() >= d["ready_after"] else max(0, d["replicas"] - 1)
    return {"apiVersion": "apps/v1", "kind": "Deployment",
            "metadata": {"name": name, "namespace": NS, "labels": labels, "annotations": ann, "resourceVersion": "1"},
            "spec": {"replicas": d["replicas"], "selector": {"matchLabels": {"app": name}},
                     "template": {"metadata": {"labels": {"app": name}, "annotations": {"prometheus.io/scrape": "true"}},
                                  "spec": {"containers": [{"name": "app", "image": "kubeheal/demo-app:x",
                                                           "resources": {"limits": {"cpu": "200m", "memory": "192Mi"},
                                                                         "requests": {"cpu": "20m", "memory": "48Mi"}}}]}}},
            "status": {"replicas": d["replicas"], "updatedReplicas": d["replicas"], "readyReplicas": ready, "availableReplicas": ready}}


def pod_json(st, dname, pname):
    d = st.deps[dname]
    reason = st.pod_state.get(pname, {}).get("reason")
    state = {"waiting": {"reason": reason}} if reason else {"running": {"startedAt": _iso(time.time() - 120)}}
    ready = reason is None
    return {"apiVersion": "v1", "kind": "Pod",
            "metadata": {"name": pname, "namespace": NS, "labels": {"app": dname}, "creationTimestamp": _iso(time.time() - 120),
                         "ownerReferences": [{"apiVersion": "apps/v1", "kind": "ReplicaSet", "name": f"{dname}-{d['rs']}", "uid": "u-1", "controller": True}]},
            "spec": {"nodeName": "ip-172-31-42-77", "containers": [{"name": "app", "image": "x"}]},
            "status": {"phase": "Running", "podIP": "10.42.0.9",
                       "conditions": [{"type": "Ready", "status": "True" if ready else "False"}],
                       "containerStatuses": [{"name": "app", "image": "x", "imageID": "y", "ready": ready, "restartCount": d["restarts"],
                                              "state": state, "lastState": {}}]}}


def make_handler(st):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body):
            data = json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _record(self, body=None):
            u = urlparse(self.path)
            st.log.append((self.command, u.path, parse_qs(u.query), self.headers.get("Content-Type"), body))
            return u

        def do_GET(self):
            u = self._record()
            with st.lock:
                m = re.fullmatch(rf"/apis/apps/v1/namespaces/{NS}/deployments(?:/(\w+))?", u.path)
                if m:
                    if m.group(1):
                        return self._send(200, deployment_json(st, m.group(1))) if m.group(1) in st.deps else self._send(404, {"kind": "Status", "code": 404})
                    sel = parse_qs(u.query).get("labelSelector", [""])[0]
                    names = [n for n, d in st.deps.items() if not sel or (sel == "kubeheal.io/monitor=true" and d["monitored"])]
                    return self._send(200, {"apiVersion": "apps/v1", "kind": "DeploymentList", "metadata": {}, "items": [deployment_json(st, n) for n in sorted(names)]})
                if u.path == f"/api/v1/namespaces/{NS}/pods":
                    items = [pod_json(st, n, p) for n in sorted(st.deps) for p in st.pods(n)]
                    return self._send(200, {"apiVersion": "v1", "kind": "PodList", "metadata": {}, "items": items})
                if u.path == f"/api/v1/namespaces/{NS}/resourcequotas":
                    used = sum(len(st.pods(n)) for n in st.deps)
                    return self._send(200, {"apiVersion": "v1", "kind": "ResourceQuotaList", "metadata": {},
                                            "items": [{"metadata": {"name": "demo-quota"}, "status": {"hard": st.quota["hard"], "used": {"pods": str(used)}}}]})
            self._send(404, {"kind": "Status", "code": 404, "message": "not found: " + u.path})

        def do_PATCH(self):
            raw = self.rfile.read(int(self.headers.get("Content-Length", 0)))
            body = json.loads(raw or b"null")
            u = self._record(body)
            ctype = (self.headers.get("Content-Type") or "").split(";")[0]
            if ctype not in PATCH_TYPES:                # exactly what a real API server does
                return self._send(415, {"kind": "Status", "code": 415, "reason": "UnsupportedMediaType"})
            with st.lock:
                m = re.fullmatch(rf"/apis/apps/v1/namespaces/{NS}/deployments/(\w+)(/scale)?", u.path)
                if not m or m.group(1) not in st.deps:
                    return self._send(404, {"kind": "Status", "code": 404})
                d = st.deps[m.group(1)]
                if m.group(2):
                    d["replicas"] = body["spec"]["replicas"]
                    d["ready_after"] = time.time() + 0.6
                    return self._send(200, {"apiVersion": "autoscaling/v1", "kind": "Scale", "metadata": {"name": m.group(1), "namespace": NS},
                                            "spec": {"replicas": d["replicas"]}, "status": {"replicas": d["replicas"], "selector": f"app={m.group(1)}"}})
                meta = body.get("metadata", {})
                if "labels" in meta and "kubeheal.io/monitor" in meta["labels"]:
                    d["monitored"] = meta["labels"]["kubeheal.io/monitor"] == "true"      # None (null) removes the label
                ann = meta.get("annotations", {})
                if "kubeheal.io/baseline-replicas" in ann:
                    d["baseline"] = int(ann["kubeheal.io/baseline-replicas"])
                tpl = body.get("spec", {}).get("template", {}).get("metadata", {}).get("annotations", {})
                if "kubectl.kubernetes.io/restartedAt" in tpl:
                    d["rs"] = f"{abs(hash(tpl['kubectl.kubernetes.io/restartedAt'])) % 10**9:09d}"
                    d["ready_after"] = time.time() + 0.6
                    st.deleted.clear()
                return self._send(200, deployment_json(st, m.group(1)))

        def do_DELETE(self):
            u = self._record()
            with st.lock:
                m = re.fullmatch(rf"/api/v1/namespaces/{NS}/pods/([\w-]+)", u.path)
                if not m:
                    return self._send(404, {"kind": "Status", "code": 404})
                st.deleted.append(m.group(1))
                return self._send(200, {"apiVersion": "v1", "kind": "Status", "status": "Success"})
    return H


def start():
    st = State()
    srv = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(st))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return st, srv, f"http://127.0.0.1:{srv.server_address[1]}"
