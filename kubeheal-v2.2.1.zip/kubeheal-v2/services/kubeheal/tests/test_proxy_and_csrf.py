import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from app.config import Config
from app.main import create_app

SEEN = []


class Upstream(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype):
        data = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("X-Served-By", "pod-xyz")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        SEEN.append(("GET", self.path, self.headers.get("Accept")))
        if self.path.startswith("/api/stats"):
            self._send(200, json.dumps({"pod": "pod-xyz"}), "application/json")
        else:
            self._send(200, "<h1>demo ui</h1>", "text/html; charset=utf-8")

    def do_POST(self):
        SEEN.append(("POST", self.path, None))
        self._send(200, json.dumps({"ok": True}), "application/json")

    def log_message(self, *a):
        pass


@pytest.fixture(scope="module")
def upstream():
    srv = HTTPServer(("127.0.0.1", 0), Upstream)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield srv.server_address[1]
    srv.shutdown()


@pytest.fixture
def client(rt, upstream):
    SEEN.clear()
    rt.monitor.tick()
    cfg = Config()
    cfg.demo_url_template = f"http://127.0.0.1:{upstream}"
    return create_app(cfg, runtime=rt, start_threads=False).test_client()


def test_proxy_serves_ui_and_api_for_monitored_apps(client):
    page = client.get("/demo/backend/", headers={"Accept": "text/html"})
    assert page.status_code == 200 and b"demo ui" in page.data and page.mimetype == "text/html"
    assert page.headers["X-Served-By"] == "pod-xyz"
    assert client.get("/demo/backend/api/stats").json == {"pod": "pod-xyz"}
    assert client.post("/demo/backend/chaos/cpu?seconds=30").json["ok"]
    assert ("POST", "/chaos/cpu?seconds=30", None) in SEEN
    assert SEEN[0][2] == "text/html"                       # Accept is forwarded so the app can pick HTML vs JSON


def test_slash_redirect(client):
    assert client.get("/demo/backend").status_code in (301, 308)


def test_proxy_is_an_allow_list_not_an_open_proxy(client):
    for bad in ("/demo/backend/../../etc/passwd", "/demo/backend/admin", "/demo/backend/metrics", "/demo/backend/chaos/rm",
                "/demo/backend/http://evil.example/"):
        assert client.get(bad).status_code == 404, bad
    assert client.get("/demo/analytics/").status_code == 404          # unmonitored deployment
    assert client.get("/demo/ghost/").status_code == 404
    assert not any("etc/passwd" in s[1] or "evil" in s[1] for s in SEEN)


def test_unreachable_upstream_is_502(rt):
    rt.monitor.tick()
    cfg = Config()
    cfg.demo_url_template = "http://127.0.0.1:9"
    c = create_app(cfg, runtime=rt, start_threads=False).test_client()
    assert c.get("/demo/backend/").status_code == 502


def test_per_app_mapping_template(rt, upstream):
    rt.monitor.tick()
    cfg = Config()
    cfg.demo_url_template = f"frontend=http://127.0.0.1:{upstream},backend=http://127.0.0.1:9"
    c = create_app(cfg, runtime=rt, start_threads=False).test_client()
    assert c.get("/demo/frontend/api/stats").status_code == 200
    assert c.get("/demo/backend/api/stats").status_code == 502
    assert c.get("/demo/database/api/stats").status_code == 404        # not in the mapping


def test_cluster_mode_pins_a_pod_with_a_cookie(rt, upstream):
    rt.monitor.tick()
    pods = [dict(p, ip="127.0.0.1") for p in rt.monitor.snapshot["pods"]]
    rt.monitor.snapshot["pods"] = pods
    cfg = Config()                                         # no template: proxy to pod IP:chaos_port
    cfg.chaos_port = upstream
    c = create_app(cfg, runtime=rt, start_threads=False).test_client()
    r = c.get("/demo/backend/api/stats")
    assert r.status_code == 200 and "kg_pod_backend=" in r.headers["Set-Cookie"] and "Path=/demo/backend/" in r.headers["Set-Cookie"]
    backend_pods = sorted(p["name"] for p in pods if p["app"] == "backend")
    assert backend_pods[0] in r.headers["Set-Cookie"]
    c.set_cookie("kg_pod_backend", backend_pods[1], path="/demo/backend/")
    assert backend_pods[1] not in (c.get("/demo/backend/api/stats").headers.get("Set-Cookie") or "x")   # already pinned: no re-set
    c.set_cookie("kg_pod_backend", "pod-that-died", path="/demo/backend/")
    assert backend_pods[0] in c.get("/demo/backend/api/stats").headers["Set-Cookie"]                    # falls back and re-pins


def test_no_ready_pod_is_503(rt):
    rt.monitor.tick()
    rt.monitor.snapshot["pods"] = []
    c = create_app(Config(), runtime=rt, start_threads=False).test_client()
    assert c.get("/demo/backend/").status_code == 503


def test_proxy_requires_auth_when_enabled(rt, upstream):
    rt.monitor.tick()
    cfg = Config()
    cfg.auth_password = "pw"
    cfg.demo_url_template = f"http://127.0.0.1:{upstream}"
    c = create_app(cfg, runtime=rt, start_threads=False).test_client()
    assert c.get("/demo/backend/").status_code == 401


# ---------------- CSRF -----------------
@pytest.fixture
def api(rt):
    rt.monitor.tick()
    return create_app(Config(), runtime=rt, start_threads=False).test_client()


def test_cross_origin_state_changes_are_rejected(api):
    r = api.post("/api/experiments/cpu", headers={"Origin": "http://evil.example"}, data="application=backend")
    assert r.status_code == 403
    assert api.post("/api/settings", json={"cpu_critical": 50}, headers={"Origin": "null"}).status_code == 403
    assert api.post("/api/experiments/cpu", headers={"Sec-Fetch-Site": "cross-site"}).status_code == 403
    assert api.get("/api/settings").json["cpu_critical"] == 90          # nothing changed


def test_same_origin_and_non_browser_clients_still_work(api):
    assert api.post("/api/settings", json={"cpu_critical": 80}, headers={"Origin": "http://localhost"}).status_code == 200
    assert api.post("/api/settings", json={"cpu_critical": 85}).status_code == 200       # curl / scripts send no Origin
    assert api.get("/api/overview", headers={"Origin": "http://evil.example"}).status_code == 200   # reads are unaffected
