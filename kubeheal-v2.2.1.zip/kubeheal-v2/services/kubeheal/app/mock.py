"""In-memory cluster simulator implementing both the cluster and metrics interfaces.

Used for (a) automated tests, and (b) previewing the dashboard on a laptop with no
Kubernetes (KUBEHEAL_MODE=mock). It models pods, readiness delay, chaos effects,
scaling, rolling restarts and metric history closely enough to exercise every code path.
"""
import math
import random
import string
import threading
import time
from collections import deque

from .models import AppInfo, PodInfo

MI = 1048576


class _Pod:
    def __init__(self, name, rs, startup, now, ip):
        self.name, self.rs, self.ip = name, rs, ip
        self.born, self.ready_at, self.drop_at = now, now + startup, None
        self.chaos = {}                       # kind -> (until, param)
        self.restarts = 0


class MockWorld:
    def __init__(self, startup=4.0, seed=None, seed_history=True, quota=12):
        self.startup, self.quota = startup, quota
        self.rng = random.Random(seed)
        self.lock = threading.RLock()
        self.apps = {}
        self.ok = True
        self.history = {}
        self._ip = 10
        for name, n, monitored in [("frontend", 2, True), ("backend", 2, True),
                                   ("database", 1, True), ("analytics", 1, False)]:
            self.apps[name] = {"desired": n, "baseline": None, "monitored": monitored,
                               "cpu_limit": 0.2, "mem_limit": 192.0 * MI, "pods": [], "rs": self._hash()}
            for _ in range(n):
                self._spawn(name, ready_now=True)
        if seed_history:
            self._seed_history()

    # ---- helpers --------------------------------------------------------
    def _hash(self):
        return "".join(self.rng.choices("bcdfghjklmnpqrstvwxz2456789", k=9))

    def _suffix(self):
        return "".join(self.rng.choices(string.ascii_lowercase + string.digits, k=5))

    def _spawn(self, app, ready_now=False):
        a, now = self.apps[app], time.time()
        self._ip += 1
        p = _Pod(f"{app}-{a['rs']}-{self._suffix()}", a["rs"], 0 if ready_now else self.startup, now,
                 f"10.42.0.{self._ip}")
        a["pods"].append(p)
        return p

    def _reconcile(self, app):
        a, now = self.apps[app], time.time()
        a["pods"] = [p for p in a["pods"] if not (p.drop_at and now >= p.drop_at)]
        live = [p for p in a["pods"] if p.drop_at is None]
        while len(live) < a["desired"]:
            live.append(self._spawn(app))
        while len(live) > a["desired"]:
            a["pods"].remove(live.pop())

    @staticmethod
    def _is_ready(p, now):
        return now >= p.ready_at

    def _ready_pods(self, a, now):
        return [p for p in a["pods"] if self._is_ready(p, now)]

    # ---- cluster interface ---------------------------------------------
    def _info(self, name):
        a, now = self.apps[name], time.time()
        live = [p for p in a["pods"] if p.drop_at is None]
        return AppInfo(name=name, desired=a["desired"], ready=len(self._ready_pods(a, now)),
                       updated=len([p for p in live if p.rs == a["rs"] and self._is_ready(p, now)]),
                       replicas=len(a["pods"]), baseline=a["baseline"],
                       cpu_limit=a["cpu_limit"], mem_limit=a["mem_limit"], has_app_metrics=True)

    def list_apps(self):
        with self.lock:
            out = []
            for n in sorted(self.apps):
                if self.apps[n]["monitored"]:
                    self._reconcile(n)
                    out.append(self._info(n))
            return out

    def get_app(self, name):
        with self.lock:
            self._reconcile(name)
            return self._info(name)

    def list_pods(self, app=None):
        with self.lock:
            now, out = time.time(), []
            for n in sorted(self.apps):
                if (app and n != app) or not self.apps[n]["monitored"]:
                    continue
                self._reconcile(n)
                for p in self.apps[n]["pods"]:
                    ready = self._is_ready(p, now)
                    out.append(PodInfo(p.name, n, "Running" if ready else "Pending", ready, p.restarts,
                                       "node-1", p.ip, now - p.born))
            return out

    def quota_pods(self):
        with self.lock:
            return sum(len(a["pods"]) for a in self.apps.values()) + 1, self.quota   # +1 load generator

    def candidates(self):
        with self.lock:
            return sorted(n for n, a in self.apps.items() if not a["monitored"])

    def scale(self, name, replicas):
        with self.lock:
            self.apps[name]["desired"] = int(replicas)
            self._reconcile(name)

    def rolling_restart(self, name):
        with self.lock:
            a, now = self.apps[name], time.time()
            a["rs"] = self._hash()
            for p in a["pods"]:
                if p.drop_at is None:
                    p.drop_at = now + self.startup
            for _ in range(a["desired"]):
                self._spawn(name)

    def delete_pod(self, name, grace=0):
        with self.lock:
            for a in self.apps.values():
                a["pods"] = [p for p in a["pods"] if p.name != name]

    def set_baseline(self, name, replicas):
        with self.lock:
            self.apps[name]["baseline"] = int(replicas)

    def set_monitor(self, name, enabled):
        with self.lock:
            self.apps[name]["monitored"] = bool(enabled)

    # ---- chaos ----------------------------------------------------------
    def apply_chaos(self, pod, kind, params):
        """Signature matches experiments.http_chaos: (pod, kind, params) -> bool."""
        with self.lock:
            for a in self.apps.values():
                for p in a["pods"]:
                    if p.name == pod.name:
                        if kind == "stop":
                            p.chaos.clear()
                        else:
                            p.chaos[kind] = (time.time() + float(params.get("seconds", 60)),
                                             params.get("rate", params.get("percent", 1)))
                        return True
        return False

    def _active(self, p, kind, now):
        c = p.chaos.get(kind)
        return c if c and now < c[0] else None

    # ---- metrics interface ---------------------------------------------
    def _pod_vals(self, a, p, now):
        n = lambda s: self.rng.uniform(-s, s)
        cpu = 0.97 if self._active(p, "cpu", now) else 0.26 + n(0.05)
        mem_c = self._active(p, "memory", now)
        mem = float(mem_c[1]) / 100 if mem_c else 0.31 + n(0.03)
        err_c = self._active(p, "errors", now)
        err = float(err_c[1]) * 100 if err_c else max(0.0, 0.15 + n(0.1))
        resp = 90 + n(15) + (330 if self._active(p, "cpu", now) else 0) + (40 if err_c else 0)
        return cpu * a["cpu_limit"], mem * a["mem_limit"], err, resp

    def app_metrics(self, app):
        with self.lock:
            a, now = self.apps[app.name], time.time()
            pods = self._ready_pods(a, now)
            if not pods:
                return {"cpu_pct": None, "mem_pct": None, "cpu_cores": None, "mem_mib": None,
                        "req_rate": None, "err_pct": None, "resp_ms": None}
            vals = [self._pod_vals(a, p, now) for p in pods]
            avg = lambda i: sum(v[i] for v in vals) / len(vals)
            cpu, mem = avg(0), avg(1)
            return {"cpu_cores": cpu, "mem_mib": mem / MI, "cpu_pct": 100 * cpu / a["cpu_limit"],
                    "mem_pct": 100 * mem / a["mem_limit"], "req_rate": 3.0, "err_pct": avg(2), "resp_ms": avg(3)}

    def cluster_metrics(self):
        with self.lock:
            now, used_cpu, used_mem = time.time(), 0.0, 0.0
            for a in self.apps.values():
                for p in self._ready_pods(a, now):
                    c, m, _, _ = self._pod_vals(a, p, now)
                    used_cpu += c
                    used_mem += m
            return {"cpu_pct": min(100.0, 14 + 100 * used_cpu / 2.0), "mem_pct": 38 + 100 * used_mem / (2048 * MI)}

    def pod_metrics(self):
        with self.lock:
            now, out = time.time(), {}
            for a in self.apps.values():
                for p in self._ready_pods(a, now):
                    c, m, _, _ = self._pod_vals(a, p, now)
                    out[p.name] = {"cpu_cores": c, "mem_bytes": m}
            return out

    # ---- history --------------------------------------------------------
    def _push(self, key, ts, value):
        self.history.setdefault(key, deque(maxlen=2500)).append((ts, value))

    def _seed_history(self):
        now = time.time()
        for i in range(120):
            ts, ph = now - 3600 + i * 30, i / 9.0
            for name in self.apps:
                if name == "analytics":
                    continue
                self._push((name, "cpu"), ts, 28 + 6 * math.sin(ph) + self.rng.uniform(-3, 3))
                self._push((name, "memory"), ts, 32 + 3 * math.sin(ph / 2) + self.rng.uniform(-1.5, 1.5))
                self._push((name, "response"), ts, 95 + 12 * math.sin(ph) + self.rng.uniform(-8, 8))
                self._push((name, "errors"), ts, max(0, 0.2 + self.rng.uniform(-0.15, 0.2)))
            self._push(("_", "cpu"), ts, 40 + 5 * math.sin(ph) + self.rng.uniform(-2, 2))
            self._push(("_", "memory"), ts, 52 + 2 * math.sin(ph / 3) + self.rng.uniform(-1, 1))
            self._push(("_", "requests"), ts, 8 + 1.5 * math.sin(ph) + self.rng.uniform(-.5, .5))
            self._push(("_", "errors"), ts, max(0, 0.2 + self.rng.uniform(-.15, .2)))

    def sample(self):
        """Record one history point per metric (called periodically by start_sampler)."""
        ts = time.time()
        for info in self.list_apps():
            m = self.app_metrics(info)
            for key, mk in [("cpu", "cpu_pct"), ("memory", "mem_pct"), ("response", "resp_ms"), ("errors", "err_pct")]:
                if m[mk] is not None:
                    self._push((info.name, key), ts, m[mk])
        c = self.cluster_metrics()
        self._push(("_", "cpu"), ts, c["cpu_pct"])
        self._push(("_", "memory"), ts, c["mem_pct"])
        self._push(("_", "requests"), ts, 8.0)
        self._push(("_", "errors"), ts, sum(self.app_metrics(i)["err_pct"] or 0 for i in self.list_apps()) / 3)

    def start_sampler(self, every=5):
        def loop():
            while True:
                try:
                    self.sample()
                except Exception:
                    pass
                time.sleep(every)
        threading.Thread(target=loop, daemon=True, name="mock-sampler").start()

    def _window(self, key, seconds):
        cutoff = time.time() - seconds
        pts = [[t, v] for t, v in self.history.get(key, []) if t >= cutoff]
        stride = max(1, len(pts) // 200)
        return pts[::stride]

    def series(self, app, metric, seconds):
        return self._window((app.name, metric), seconds)

    def overview_series(self, seconds):
        return {k: self._window(("_", k), seconds) for k in ("cpu", "memory", "requests", "errors")}
