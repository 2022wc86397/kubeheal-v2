"""Prometheus client: per-application and cluster metrics, plus history for charts."""
import logging
import math
import time

import requests

log = logging.getLogger("kubeheal.prom")


def pod_regex(app):
    """Regex matching pods of Deployment `app` (name-<rs-hash>-<5 chars>) and nothing else."""
    return app.replace(".", r"\\.") + "-[a-z0-9]{8,10}-[a-z0-9]{5}"


class PromMetrics:
    def __init__(self, url, namespace, session=None):
        self.url = url.rstrip("/")
        self.ns = namespace
        self.http = session or requests.Session()
        self.ok = False

    # ---- low level ------------------------------------------------------
    def _get(self, path, params):
        r = self.http.get(self.url + path, params=params, timeout=6)
        r.raise_for_status()
        body = r.json()
        if body.get("status") != "success":
            raise RuntimeError(body.get("error", "prometheus error"))
        return body["data"]

    @staticmethod
    def _num(v):
        v = float(v)
        return None if math.isnan(v) or math.isinf(v) else v

    def scalar(self, q):
        try:
            res = self._get("/api/v1/query", {"query": q})["result"]
            self.ok = True
        except Exception as exc:  # network, HTTP or PromQL errors all mean "no data"
            self.ok = False
            log.warning("prometheus query failed: %s", exc)
            return None
        return self._num(res[0]["value"][1]) if res else None

    def vector(self, q, label):
        try:
            res = self._get("/api/v1/query", {"query": q})["result"]
            self.ok = True
        except Exception as exc:
            self.ok = False
            log.warning("prometheus query failed: %s", exc)
            return {}
        out = {}
        for r in res:
            v = self._num(r["value"][1])
            if v is not None:
                out[r["metric"].get(label, "")] = v
        return out

    def range(self, q, seconds, scale=1.0):
        end = time.time()
        step = max(15, int(seconds // 120))
        try:
            res = self._get("/api/v1/query_range",
                            {"query": q, "start": end - seconds, "end": end, "step": step})["result"]
        except Exception as exc:
            log.warning("prometheus range query failed: %s", exc)
            return []
        if not res:
            return []
        pts = []
        for ts, v in res[0]["values"]:
            n = self._num(v)
            if n is not None:
                pts.append([float(ts), n * scale])
        return pts

    # ---- query builders -------------------------------------------------
    def _cpu_q(self, app):
        sel = f'namespace="{self.ns}",pod=~"{pod_regex(app)}",container!="",container!="POD"'
        return f"avg(sum by (pod) (rate(container_cpu_usage_seconds_total{{{sel}}}[1m])))"

    def _mem_q(self, app):
        sel = f'namespace="{self.ns}",pod=~"{pod_regex(app)}",container!="",container!="POD"'
        return f"avg(sum by (pod) (container_memory_working_set_bytes{{{sel}}}))"

    def _http_sel(self, app):
        return f'namespace="{self.ns}",app="{app}"'

    def _req_q(self, app):
        return f"sum(rate(http_requests_total{{{self._http_sel(app)}}}[1m]))"

    def _err_q(self, app):
        s = self._http_sel(app)
        return (f'100 * (sum(rate(http_requests_total{{{s},code=~"5.."}}[1m])) or vector(0)) '
                f"/ sum(rate(http_requests_total{{{s}}}[1m]))")

    def _lat_q(self, app):
        s = self._http_sel(app)
        return (f"1000 * sum(rate(http_request_duration_seconds_sum{{{s}}}[1m])) "
                f"/ sum(rate(http_request_duration_seconds_count{{{s}}}[1m]))")

    # ---- public API -----------------------------------------------------
    def app_metrics(self, app):
        """`app` is an AppInfo. Every value is None when it cannot be measured."""
        cpu = self.scalar(self._cpu_q(app.name))
        mem = self.scalar(self._mem_q(app.name))
        out = {
            "cpu_cores": cpu,
            "mem_mib": mem / 1048576 if mem is not None else None,
            "cpu_pct": 100 * cpu / app.cpu_limit if cpu is not None and app.cpu_limit else None,
            "mem_pct": 100 * mem / app.mem_limit if mem is not None and app.mem_limit else None,
            "req_rate": None, "err_pct": None, "resp_ms": None,
        }
        if app.has_app_metrics:
            req = self.scalar(self._req_q(app.name))
            out["req_rate"] = req
            if req is not None and req > 0.05:       # too little traffic = meaningless ratios
                out["err_pct"] = self.scalar(self._err_q(app.name))
                out["resp_ms"] = self.scalar(self._lat_q(app.name))
        return out

    def cluster_metrics(self):
        cpu = self.scalar('100 * sum(rate(container_cpu_usage_seconds_total{id="/"}[1m])) '
                          "/ sum(machine_cpu_cores)")
        mem = self.scalar('100 * sum(container_memory_working_set_bytes{id="/"}) '
                          "/ sum(machine_memory_bytes)")
        return {"cpu_pct": cpu, "mem_pct": mem}

    def pod_metrics(self):
        sel = f'namespace="{self.ns}",container!="",container!="POD"'
        cpu = self.vector(f"sum by (pod) (rate(container_cpu_usage_seconds_total{{{sel}}}[1m]))", "pod")
        mem = self.vector(f"sum by (pod) (container_memory_working_set_bytes{{{sel}}})", "pod")
        return {p: {"cpu_cores": cpu.get(p), "mem_bytes": mem.get(p)} for p in set(cpu) | set(mem)}

    def series(self, app, metric, seconds):
        """History of one metric for one AppInfo: cpu | memory | response | errors."""
        if metric == "cpu":
            return self.range(self._cpu_q(app.name), seconds, 100 / app.cpu_limit) if app.cpu_limit else []
        if metric == "memory":
            return self.range(self._mem_q(app.name), seconds, 100 / app.mem_limit) if app.mem_limit else []
        if metric == "response":
            return self.range(self._lat_q(app.name), seconds)
        if metric == "errors":
            return self.range(self._err_q(app.name), seconds)
        return []

    def overview_series(self, seconds):
        ns = f'namespace="{self.ns}"'
        return {
            "cpu": self.range('100 * sum(rate(container_cpu_usage_seconds_total{id="/"}[1m])) '
                              "/ sum(machine_cpu_cores)", seconds),
            "memory": self.range('100 * sum(container_memory_working_set_bytes{id="/"}) '
                                 "/ sum(machine_memory_bytes)", seconds),
            "requests": self.range(f"sum(rate(http_requests_total{{{ns}}}[1m]))", seconds),
            "errors": self.range(
                f'100 * (sum(rate(http_requests_total{{{ns},code=~"5.."}}[1m])) or vector(0)) '
                f"/ sum(rate(http_requests_total{{{ns}}}[1m]))", seconds),
        }
