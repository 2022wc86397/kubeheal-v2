/* KubeGuard dashboard: dependency-free single page app. */
'use strict';

const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num = (v, d = 0) => v == null ? '–' : Number(v).toFixed(d);
const pct = (v, d = 0) => v == null ? '–' : num(v, d) + '%';
const mini = (v, w = 75, c = 90) => v == null ? '' : `<span class="minibar"><i class="${v >= c ? 'c' : v >= w ? 'w' : ''}" style="width:${Math.min(100, v)}%"></i></span>`;
const hms = ts => ts ? new Date(ts * 1000).toLocaleTimeString([], {hour12: false}) : '';
const dur = s => s == null ? '–' : s.toFixed(1) + 's';
const sev = v => String(v || '').toLowerCase();

const IC = {
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  box: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
  layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
  alert: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
  zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  bars: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  refresh: '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m5 0V4a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v2"/>',
  cpu: '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>',
  db: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
  tri: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  sun: '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  recycle: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
};
const ico = (n, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg>`;

const NAV = [['dashboard', 'Dashboard', 'grid'], ['applications', 'Applications', 'box'], ['pods', 'Pods', 'layers'],
  ['incidents', 'Incidents', 'alert'], ['experiments', 'Experiments', 'zap'], ['metrics', 'Metrics', 'bars'],
  ['settings', 'Settings', 'sliders']];

const S = {cfg: {}, ov: null, spark: {}, sparkAt: 0, overview: null, overviewAt: 0, filter: 'all', range: '1h',
           route: {}, podApp: '', settings: null, paused: false, nums: {}, laneRange: null, lastOk: Date.now()};
const ISMAC = /Mac|iPhone|iPad/.test(navigator.platform || '');
const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;


/* ------------------------------------------------- DOM patching + animation */
/* Replace an element's HTML only when it changed: keeps hover states, tooltips and animations alive across polls. */
function patch(id, html) {
  const el = document.getElementById(id);
  if (!el || el.__h === html) return false;
  el.innerHTML = html; el.__h = html; return true;
}

/* Count numbers up/down from their previous value (keyed so each stat remembers its own). */
function animateNumbers(root) {
  root.querySelectorAll('.cu').forEach(el => {
    const k = el.dataset.k, to = +el.dataset.v, from = S.nums[k], suffix = el.dataset.s || '';
    S.nums[k] = to;
    if (from == null || from === to || REDUCED || Number.isNaN(to)) { el.textContent = (Number.isNaN(to) ? '–' : to) + suffix; return; }
    const t0 = performance.now(), dur = 500;
    const step = now => { const p = Math.min(1, (now - t0) / dur), e = 1 - (1 - p) ** 3; el.textContent = Math.round(from + (to - from) * e) + suffix; if (p < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  });
}
const cu = (k, v, suffix = '') => `<span class="cu" data-k="${k}" data-v="${v}" data-s="${suffix}">${v}${suffix}</span>`;

/* ------------------------------------------------------------ shared actions */
const EXP_LABEL = {crash: 'Crash a pod', cpu: 'CPU stress', memory: 'Memory stress', errors: 'HTTP 500 errors'};
async function runExp(kind, app, seconds = 90) {
  const r = await post('/api/experiments/' + kind, {application: app, seconds});
  toast(r.ok ? r.data.message : (r.data.message || 'Experiment failed'));
  if (r.ok && r.data.incident) location.hash = '#/incidents/' + r.data.incident;
  return r;
}
const ACT = {
  palette: () => openPalette(),
  refresh: () => tick(true),
  pause() { S.paused = !S.paused; chrome(); toast(S.paused ? 'Live updates paused' : 'Live updates resumed'); if (!S.paused) tick(true); },
};
document.addEventListener('click', e => { const b = e.target.closest('[data-act]'); if (b && ACT[b.dataset.act]) ACT[b.dataset.act](b, e); });

/* ------------------------------------------------------------ command palette */
const SHORTCUT = {dashboard: 'd', applications: 'a', pods: 'p', incidents: 'i', experiments: 'e', metrics: 'm', settings: 's'};
function commands() {
  const c = NAV.map(([k, l, i]) => ({t: `Go to ${l}`, icon: i, g: 'Navigate', keys: ['G', SHORTCUT[k].toUpperCase()], run: () => { location.hash = '#/' + k; }}));
  for (const a of S.ov?.apps || []) {
    c.push({t: `Metrics: ${a.name}`, icon: 'bars', g: 'Application', run: () => { location.hash = '#/metrics/' + encodeURIComponent(a.name); }});
    c.push({t: `Pods: ${a.name}`, icon: 'layers', g: 'Application', run: () => { location.hash = '#/pods?app=' + encodeURIComponent(a.name); }});
    if (a.has_app_metrics) c.push({t: `Open ${a.name} demo UI`, icon: 'box', g: 'Application', run: () => window.open('/demo/' + encodeURIComponent(a.name) + '/', '_blank', 'noopener')});
    for (const k of ['crash', 'cpu', 'memory', 'errors'])
      c.push({t: `Run ${EXP_LABEL[k]} on ${a.name}`, icon: 'zap', g: 'Experiment', run: () => runExp(k, a.name)});
  }
  c.push({t: 'Stop all experiments', icon: 'x', g: 'Experiment', run: async () => { const r = await post('/api/experiments/stop', {}); toast(r.ok ? `Stopped experiments on ${r.data.pods} pod(s)` : 'Failed'); }});
  c.push({t: S.paused ? 'Resume live updates' : 'Pause live updates', icon: 'refresh', g: 'View', run: () => ACT.pause()});
  c.push({t: 'Toggle dark mode', icon: 'moon', g: 'View', run: () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark')});
  c.push({t: 'Export incidents as CSV', icon: 'download', g: 'Data', run: () => { location.href = '/api/incidents.csv'; }});
  return c;
}
function fuzzy(q, text) {            // subsequence match; consecutive and early hits score higher. null = no match
  q = q.toLowerCase().replace(/\s+/g, ' ').trim(); text = text.toLowerCase();
  if (!q) return 0;
  let score = 0, ti = 0, run = 0;
  for (const ch of q) {
    if (ch === ' ') { run = 0; continue; }
    const at = text.indexOf(ch, ti); if (at < 0) return null;
    run = at === ti ? run + 1 : 0; score += 1 + run * 2 - Math.min(at - ti, 8) * .1 - (at === 0 ? -2 : 0); ti = at + 1;
  }
  return score;
}
const PAL = {items: [], sel: 0};
function palRender() {
  const q = $('#pal-q').value, all = commands();
  PAL.items = all.map(c => ({c, s: fuzzy(q, c.t + ' ' + c.g)})).filter(x => x.s != null).sort((a, b) => b.s - a.s).slice(0, 12).map(x => x.c);
  PAL.sel = Math.min(PAL.sel, Math.max(0, PAL.items.length - 1));
  $('#pal-list').innerHTML = PAL.items.length ? PAL.items.map((c, i) => `<li role="option" data-i="${i}" aria-selected="${i === PAL.sel}">${ico(c.icon)}<span>${esc(c.t)}</span>
    <span class="grp">${(c.keys || []).map(k => `<kbd class="kbd">${k}</kbd>`).join('')}${esc(c.g)}</span></li>`).join('') : '<li class="none">No matching command</li>';
}
function openPalette(prefill = '') { $('#pal').classList.add('on'); const q = $('#pal-q'); q.value = prefill; PAL.sel = 0; palRender(); q.focus(); }
function closePalette() { $('#pal').classList.remove('on'); }
function palRun(i) { const c = PAL.items[i]; if (!c) return; closePalette(); c.run(); }
function initPalette() {
  $('#kbd').textContent = ISMAC ? '⌘K' : 'Ctrl K';
  $('#pal-q').addEventListener('input', () => { PAL.sel = 0; palRender(); });
  $('#pal-q').addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { PAL.sel = (PAL.sel + 1) % Math.max(1, PAL.items.length); palRender(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { PAL.sel = (PAL.sel - 1 + PAL.items.length) % Math.max(1, PAL.items.length); palRender(); e.preventDefault(); }
    else if (e.key === 'Enter') { palRun(PAL.sel); e.preventDefault(); }
    else if (e.key === 'Escape') closePalette();
    $('#pal-list .on, [aria-selected=true]')?.scrollIntoView({block: 'nearest'});
  });
  $('#pal-list').addEventListener('click', e => { const li = e.target.closest('li[data-i]'); if (li) palRun(+li.dataset.i); });
  $('#pal').addEventListener('mousedown', e => { if (e.target.id === 'pal') closePalette(); });
}

/* ------------------------------------------------------------ keyboard shortcuts */
let gPending = 0;
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); $('#pal').classList.contains('on') ? closePalette() : openPalette(); return; }
  if (e.ctrlKey || e.metaKey || e.altKey || $('#pal').classList.contains('on')) return;
  if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable) return;
  if (e.key === '/' || e.key === '?') { e.preventDefault(); openPalette(); return; }
  if (gPending && Date.now() - gPending < 1200) {
    gPending = 0;
    const dest = Object.entries(SHORTCUT).find(([, k]) => k === e.key.toLowerCase());
    if (dest) { location.hash = '#/' + dest[0]; e.preventDefault(); }
  } else if (e.key === 'g') gPending = Date.now();
});

/* ------------------------------------------------------------------ api */
async function api(path, opts) {
  const r = await fetch(path, {cache: 'no-store', ...opts});
  let body = {};
  try { body = await r.json(); } catch (_) { /* non-JSON error page */ }
  if (!r.ok && !body.message && !body.error) body = {ok: false, message: `Request failed (${r.status})`};
  return {ok: r.ok, status: r.status, data: body};
}
const post = (path, body) => api(path, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})});

let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('on');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('on'), 4500);
}

/* --------------------------------------------------------------- charts */
function niceMax(v) { if (v <= 0) return 1; const p = 10 ** Math.floor(Math.log10(v)); return [1, 2, 5, 10].map(m => m * p).find(m => m >= v * 1.05); }

function lineChart(series, {max = null, unit = '', h = 190, fill = false, threshold = null, markers = []} = {}) {
  const pts = series.flatMap(s => s.points);
  if (!pts.length) return {html: '<div class="empty small">No data yet. Metrics appear after the first scrapes.</div>', geo: null};
  const W = 640, L = 40, R = 10, T = 12, B = 24, w = W - L - R, ht = h - T - B;
  const t0 = Math.min(...pts.map(p => p[0])), t1 = Math.max(...pts.map(p => p[0])) || t0 + 1;
  const ymax = max ?? niceMax(Math.max(...pts.map(p => p[1]), threshold ? threshold.value * 1.05 : 0));
  const X = t => L + (t1 === t0 ? 0 : (t - t0) / (t1 - t0) * w), Y = v => T + ht - Math.min(v, ymax) / ymax * ht;
  let g = '';
  for (let i = 0; i <= 4; i++) {
    const v = ymax * i / 4, y = Y(v);
    g += `<line class="gl" x1="${L}" x2="${W - R}" y1="${y}" y2="${y}"/><text class="axis" x="${L - 6}" y="${y + 3}" text-anchor="end">${+v.toFixed(1)}${unit}</text>`;
  }
  for (let i = 0; i <= 4; i++) {
    const t = t0 + (t1 - t0) * i / 4;
    g += `<text class="axis" x="${X(t)}" y="${h - 6}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${new Date(t * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', hour12: false})}</text>`;
  }
  if (threshold && threshold.value <= ymax) {
    const y = Y(threshold.value);
    g += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" stroke="#dc3a3a" stroke-dasharray="5 4" opacity=".7"/><text class="axis" x="${W - R - 2}" y="${y - 4}" text-anchor="end" style="fill:#dc3a3a">${esc(threshold.label)}</text>`;
  }
  const paths = series.map(s => {
    if (!s.points.length) return '';
    const d = s.points.map((p, i) => `${i ? 'L' : 'M'}${X(p[0]).toFixed(1)},${Y(p[1]).toFixed(1)}`).join('');
    const area = fill ? `<path d="${d}L${X(s.points.at(-1)[0])},${T + ht}L${X(s.points[0][0])},${T + ht}Z" fill="${s.color}" opacity=".08"/>` : '';
    return `${area}<path d="${d}" fill="none" stroke="${s.color}" stroke-width="1.8" stroke-linejoin="round"/>`;
  }).join('');
  const mk = markers.filter(m => m.t >= t0 && m.t <= t1).map(m => {
    const x = X(m.t), c = m.status === 'RECOVERED' ? '#12a05c' : m.status === 'FAILED' ? '#dc3a3a' : '#e8890c';
    return `<a href="#/incidents/${m.id}"><title>Incident #${m.id}: ${esc(m.label)} (${esc(m.status.toLowerCase())})</title>
      <line x1="${x}" x2="${x}" y1="${T + 8}" y2="${T + ht}" stroke="${c}" stroke-dasharray="3 3" opacity=".8"/>
      <path d="M${x - 6},${T - 2}L${x + 6},${T - 2}L${x},${T + 9}Z" fill="${c}"/></a>`;
  }).join('');
  const svg = `<svg viewBox="0 0 ${W} ${h}" role="img" style="touch-action:pan-y" aria-label="${esc(series.map(s => s.name).join(', '))} over time">${g}${paths}${mk}<line class="cross" y1="${T}" y2="${T + ht}" stroke="#8794ab" stroke-dasharray="2 3" visibility="hidden"/></svg>`;
  return {html: svg, geo: {W, L, R, w, t0, t1, X}};
}

/* Render a chart into `el` and wire the hover tooltip. */
function renderChart(el, series, opts = {}) {
  const {html, geo} = lineChart(series, opts);
  el.innerHTML = (opts.legend || '') + html + '<div class="tip" role="tooltip"></div>';
  if (!geo) return;
  const svg = el.querySelector('svg'), tip = el.querySelector('.tip'), cross = svg.querySelector('.cross');
  const fmt = opts.fmt || (v => (+v.toFixed(1)) + (opts.unit || ''));
  const hide = () => { tip.style.display = 'none'; cross.setAttribute('visibility', 'hidden'); };
  svg.addEventListener('pointerleave', hide);
  svg.addEventListener('pointermove', e => {
    const r = svg.getBoundingClientRect(), x = (e.clientX - r.left) / r.width * geo.W;
    if (x < geo.L || x > geo.W - geo.R) return hide();
    const t = geo.t0 + (x - geo.L) / geo.w * (geo.t1 - geo.t0);
    let rows = '', tx = null;
    series.forEach(s => {
      if (!s.points.length) return;
      const best = s.points.reduce((a, p) => Math.abs(p[0] - t) < Math.abs(a[0] - t) ? p : a);
      tx = best[0];
      rows += `<div><i style="background:${s.color}"></i>${esc(s.name)}: <b>${esc(fmt(best[1]))}</b></div>`;
    });
    if (tx == null) return hide();
    tip.innerHTML = `<time>${new Date(tx * 1000).toLocaleTimeString([], {hour12: false})}</time>${rows}`;
    tip.style.display = 'block';
    const er = el.getBoundingClientRect();
    tip.style.left = Math.max(4, Math.min(e.clientX - er.left + 14, el.clientWidth - tip.offsetWidth - 4)) + 'px';
    tip.style.top = Math.max(0, e.clientY - er.top - tip.offsetHeight - 10) + 'px';
    const cx = geo.X(tx); cross.setAttribute('x1', cx); cross.setAttribute('x2', cx); cross.setAttribute('visibility', 'visible');
  });
}

const legend = items => `<div class="legend">${items.map(([n, c]) => `<span><i style="background:${c}"></i>${n}</span>`).join('')}</div>`;

function donut(value, label, color) {
  const r = 42, c = 2 * Math.PI * r, v = Math.max(0, Math.min(100, value ?? 0));
  return `<div class="donut"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="${r}" fill="none" class="gl" stroke-width="9"/>
    <circle cx="50" cy="50" r="${r}" fill="none" stroke="${color}" stroke-width="9" stroke-linecap="round" stroke-dasharray="${c * v / 100} ${c}"/></svg>
    <div class="c"><small>${label}</small><b>${value == null ? '–' : Math.round(value) + '%'}</b></div></div>`;
}

function spark(points, color) {
  if (!points || points.length < 2) return '';
  const t0 = points[0][0], t1 = points.at(-1)[0] || t0 + 1, vs = points.map(p => p[1]), lo = Math.min(...vs), hi = Math.max(...vs, lo + 1);
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${((p[0] - t0) / (t1 - t0) * 200).toFixed(1)},${(38 - (p[1] - lo) / (hi - lo) * 34).toFixed(1)}`).join('');
  return `<svg viewBox="0 0 200 42" preserveAspectRatio="none"><path d="${d}L200,42L0,42Z" fill="${color}" opacity=".1"/><path d="${d}" fill="none" stroke="${color}" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;
}

const statusColor = s => s === 'healthy' ? 'var(--green)' : s === 'warning' ? 'var(--amber)' : 'var(--red)';
const bar = (v, cls = '') => `<div class="bar"><i class="${cls}" style="width:${Math.max(0, Math.min(100, v ?? 0))}%"></i></div>`;
const head = (title, sub, right = '') => `<div class="page-head"><div><h1>${title}</h1>${sub ? `<p class="sub">${sub}</p>` : ''}</div><div class="head-right">${right}</div></div>`;

/* ---------------------------------------------------------------- views */
const V = {};

V.dashboard = {
  render() {
    $('#main').innerHTML = `<div id="d-head"></div><div id="d-warn"></div><div id="d-hero"><div class="skeleton" style="height:150px;border-radius:20px"></div></div>
      <div id="d-live"></div><div id="d-tiles" class="grid g4"></div><div class="card mt" id="d-map"></div>
      <div class="split mt"><div class="card" id="d-health"></div><div class="card" id="d-res"></div></div>
      <div class="card mt"><h2>Metrics Overview (Last 1 Hour)</h2><div id="ovchart" class="chart"></div></div><div class="card mt" id="d-feed"></div>`;
    this.refresh();
  },
  hero(o) {
    const apps = o.apps, c = o.counts, act = (o.active_incidents || [])[0];
    const bad = apps.filter(a => a.status === 'critical' || a.status === 'stopped'), warn = apps.filter(a => a.status === 'warning');
    const score = apps.length ? Math.round(apps.reduce((t, a) => t + a.score, 0) / apps.length) : null;
    let tone = 'healthy', title = 'All systems operational', sub = `${apps.length} applications · ${c.running} of ${c.pods} pods ready`;
    if (!o.cluster_connected) { tone = 'critical'; title = 'Cluster unreachable'; sub = o.error || 'Cannot reach the Kubernetes API'; }
    else if (act) { tone = 'warning'; title = `Recovering ${act.application}`; sub = `${act.type_label}${act.action ? ' · ' + act.action : ''}`; }
    else if (bad.length) { tone = 'critical'; title = bad.length === 1 ? `${bad[0].name} needs attention` : `${bad.length} applications need attention`; sub = (bad[0].reasons || []).join(' · '); }
    else if (warn.length) { tone = 'warning'; title = warn.length === 1 ? `${warn[0].name} is degraded` : `${warn.length} applications are degraded`; sub = (warn[0].reasons || []).join(' · ') || 'Watching closely'; }
    const R = 46, C = 2 * Math.PI * R, v = score ?? 0, col = tone === 'healthy' ? ['#34d399', '#2a7bff'] : tone === 'warning' ? ['#fbbf24', '#f97316'] : ['#ff8a8a', '#dc3a3a'];
    const ring = `<div class="hring"><svg viewBox="0 0 110 110"><defs><linearGradient id="hg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${col[0]}"/><stop offset="1" stop-color="${col[1]}"/></linearGradient></defs>
      <circle cx="55" cy="55" r="${R}" fill="none" stroke="#ffffff1f" stroke-width="9"/><circle cx="55" cy="55" r="${R}" fill="none" stroke="url(#hg)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${C * v / 100} ${C}"/></svg>
      <b>${score == null ? '–' : cu('h-score', score, '%')}<small>health</small></b></div>`;
    return `<section class="hero ${tone}" aria-label="System status">${ring}<div><h2>${esc(title)}</h2><p>${esc(sub)}</p>
      <div class="chips2"><a class="hchip ${o.auto_recovery ? 'on' : 'off'}" href="#/settings">Auto-recovery ${o.auto_recovery ? 'on' : 'off'}</a>
      <span class="hchip">MTTR ${o.mttr_seconds == null ? '–' : o.mttr_seconds + 's'}</span><span class="hchip">${c.recoveries_24h} recoveries / 24h</span></div></div>
      <div class="hright"><button class="hchip" data-act="palette" type="button">Search or run… <kbd class="kbd">${ISMAC ? '⌘K' : 'Ctrl K'}</kbd></button></div></section>`;
  },
  map(o) {
    const podsBy = {}; (S.pods || []).forEach(p => (podsBy[p.app] ||= []).push(p));
    const rows = o.apps.map(a => {
      const pods = podsBy[a.name] || [], ghosts = Math.max(0, a.desired - pods.filter(p => p.status !== 'Terminating').length);
      const tiles = pods.map(p => {
        const st = p.status === 'Terminating' ? 'term' : p.ready ? '' : /Crash|BackOff|Err|OOM|Error/.test(p.status) ? 'bad' : 'wait';
        return `<a class="pod-t ${st}" href="#/pods?app=${encodeURIComponent(a.name)}" title="${esc(p.name)}\n${esc(p.status)} · restarts ${p.restarts}\nCPU ${p.cpu_pct == null ? '–' : num(p.cpu_pct) + '%'} · mem ${p.mem_pct == null ? '–' : num(p.mem_pct) + '%'}" aria-label="Pod ${esc(p.name)}: ${esc(p.status)}">${esc(p.name.slice(-5))}<u style="width:calc((100% - 14px) * ${Math.min(100, p.cpu_pct || 0) / 100})"></u></a>`;
      }).join('') + Array.from({length: ghosts}, () => '<span class="pod-t ghost" title="Scheduled, not yet created">+</span>').join('');
      return `<div class="map-row"><div class="map-name"><b>${esc(a.name)}</b><span>${a.ready}/${a.desired} ready${a.baseline && a.baseline !== a.desired ? ` · baseline ${a.baseline}` : ''}</span></div>
        <div class="pods">${tiles || '<span class="muted small">No pods</span>'}</div><span class="pill ${a.status}">${a.score}% ${a.status}</span></div>`;
    }).join('');
    return `<h2>Cluster map</h2>${rows || '<div class="empty">No monitored applications</div>'}
      <div class="map-legend"><span><i style="background:#12a05c"></i>Ready</span><span><i style="background:#e8890c"></i>Starting</span><span><i style="background:#dc3a3a"></i>Failing</span><span><i style="background:#8a97ad"></i>Terminating</span><span>Bar on tile = CPU of limit · click to open pods</span></div>`;
  },
  async refresh() {
    const o = S.ov; if (!o || !$('#d-hero')) return;
    const c = o.counts, cl = o.cluster || {};
    if (!S.pods || Date.now() - (S.podsAt || 0) > 2500) { S.podsAt = Date.now(); const r = await api('/api/pods'); if (r.ok) S.pods = r.data.pods; if (!$('#d-hero')) return; }
    const right = `<span><span class="dot ${o.cluster_connected ? '' : 'off'}"></span> ${o.cluster_connected ? 'Cluster Connected' : 'Cluster Unreachable'}</span>
      <span id="d-clock"></span>
      <button class="icon-btn" data-act="pause" title="${S.paused ? 'Resume' : 'Pause'} live updates" aria-label="${S.paused ? 'Resume' : 'Pause'} live updates">${S.paused ? '▶' : '❚❚'}</button>
      <button class="icon-btn" data-act="refresh" title="Refresh now" aria-label="Refresh now">${ico('refresh')}</button>`;
    patch('d-head', head('Dashboard', 'Kubernetes Application Health &amp; Auto-Recovery', right));
    const clock = $('#d-clock'); if (clock) clock.textContent = new Date().toLocaleString([], {dateStyle: 'medium', timeStyle: 'medium', hour12: false});
    patch('d-warn', !o.cluster_connected ? `<div class="banner">Cannot reach the Kubernetes API: ${esc(o.error || 'unknown error')}</div>`
      : !o.prometheus_ok ? `<div class="banner">Prometheus is not answering, so CPU, memory and latency are unavailable. Availability checks still work.</div>` : '');
    if (patch('d-hero', this.hero(o))) animateNumbers($('#d-hero'));
    const act = (o.active_incidents || [])[0];
    patch('d-live', act ? `<div class="live"><span class="pulse"></span><div class="grow"><b>Auto-recovery in progress</b> · ${esc(act.application)} · ${esc(act.type_label)}${act.action ? ' · ' + esc(act.action) : ''}</div><a class="btn sm" href="#/incidents/${act.id}">Watch</a></div>` : '');
    const tile = (cls, icon, n, k, label, sub) => `<div class="tile ${cls}"><div class="ti">${ico(icon)}</div><div><div class="n">${cu(k, n)}</div><div class="l">${label}</div><div class="s">${sub}</div></div></div>`;
    if (patch('d-tiles', tile('green', 'box', c.applications, 't-apps', 'Applications', `${c.healthy} Healthy ${c.warning + c.critical} Warning`) +
      tile('blue', 'layers', c.pods, 't-pods', 'Pods', `${c.running} Running ${c.not_ready} Restarting`) +
      tile('red', 'alert', c.active, 't-act', 'Active Incident', c.active ? 'Auto-recovery in progress' : 'All clear') +
      tile('purple', 'recycle', c.recoveries_24h, 't-rec', 'Successful Recoveries', 'Last 24 hours'))) animateNumbers($('#d-tiles'));
    patch('d-map', this.map(o));
    patch('d-health', `<h2>Application Health</h2>${o.apps.map(a => `<div class="health-row"><b>${esc(a.name)}</b>${bar(a.score, a.status)}<span class="num">${a.score}%</span><span class="pill ${a.status}">${a.status[0].toUpperCase() + a.status.slice(1)}</span></div>`).join('') || '<div class="empty">No monitored applications</div>'}`);
    const pm = cl.pods_max;
    patch('d-res', `<h2>Cluster Resource Usage</h2><div class="donuts">${donut(cl.cpu_pct, 'CPU', 'var(--blue)')}${donut(cl.mem_pct, 'Memory', 'var(--green)')}
      ${donut(pm ? 100 * cl.pods_used / pm : null, 'Pods', 'var(--purple)').replace(/<b>.*?<\/b>/, `<b>${pm ? cl.pods_used + '/' + pm : (cl.pods_used ?? '–')}</b>`)}</div>`);
    patch('d-feed', `<h2>Recent activity</h2><ul class="feed">${(o.events || []).map(e => `<li><time>${hms(e.ts)}</time><span class="${e.level === 'error' ? 'bad' : e.level === 'ok' ? 'ok' : ''}">${esc(e.message)}</span></li>`).join('') || '<li class="muted">Nothing yet. Trigger an experiment to see KubeGuard work.</li>'}</ul>`);
    this.chart();
  },
  async chart() {
    if (!$('#ovchart')) return;
    let fetched = false;
    if (Date.now() - S.overviewAt > 15000) {
      const r = await api('/api/metrics/overview?range=1h'); if (r.ok) { S.overview = r.data; S.overviewAt = Date.now(); fetched = true; }
    }
    const m = S.overview; if (!m || !$('#ovchart')) return;
    if (!fetched && $('#ovchart').firstChild) return;          // keep the live tooltip alive between data refreshes
    const L = [['CPU (%)', 'var(--blue)'], ['Memory (%)', 'var(--green)'], ['Request Rate (% of peak)', 'var(--purple)'], ['Error Rate (%)', 'var(--red)']];
    renderChart($('#ovchart'), [
      {name: 'CPU', color: '#1769e0', points: m.cpu}, {name: 'Memory', color: '#12a05c', points: m.memory},
      {name: 'Requests (% of peak)', color: '#7a3de0', points: m.requests_pct || []}, {name: 'Errors', color: '#dc3a3a', points: m.errors}],
      {max: 100, unit: '', legend: legend(L), fmt: v => v.toFixed(1) + '%'});
  }
};

V.applications = {
  render() { $('#main').innerHTML = `<div id="apps"></div>`; this.refresh(); this.sparks(); },
  async sparks() {
    if (Date.now() - S.sparkAt < 15000 || !S.ov) return;
    S.sparkAt = Date.now();
    await Promise.all(S.ov.apps.map(async a => { const r = await api(`/api/metrics/app/${encodeURIComponent(a.name)}?range=15m`); if (r.ok) S.spark[a.name] = r.data.cpu; }));
    this.refresh();
  },
  refresh() {
    const o = S.ov; if (!o || !$('#apps')) return;
    $('#apps').innerHTML = head('Applications', 'Manage and monitor your Kubernetes applications', `<button class="btn" id="addapp">+ Add Application</button>`) +
      `<div class="grid g3">${o.apps.map(a => `
      <div class="card app ${a.status}">
        <div class="app-top"><span class="badge-ico">${ico('box')}</span><h3>${esc(a.name)}</h3><span class="pill ${a.status}">${a.status[0].toUpperCase() + a.status.slice(1)}</span></div>
        ${a.active_incident ? `<div class="ribbon"><a href="#/incidents/${a.active_incident}">Incident #${a.active_incident} in progress</a></div>` : ''}
        <div class="kpis"><div><b>${a.ready}/${a.desired}</b><span>Running Pods</span></div><div><b>${a.score}%</b><span>Health Score</span></div><div><b>${a.resp_ms == null ? '–' : num(a.resp_ms) + 'ms'}</b><span>Avg Response Time</span></div></div>
        <div class="spark" title="CPU, last 15 minutes">${spark(S.spark[a.name], statusColor(a.status).replace('var(--green)', '#12a05c').replace('var(--amber)', '#e8890c').replace('var(--red)', '#dc3a3a'))}</div>
        <div class="mini"><div><span>CPU</span><b class="${a.cpu_pct >= 90 ? 'bad' : a.cpu_pct >= 70 ? 'warn' : 'ok'}">${pct(a.cpu_pct)}</b></div><div><span>Memory</span><b class="${a.mem_pct >= 90 ? 'bad' : a.mem_pct >= 75 ? 'warn' : 'ok'}">${pct(a.mem_pct)}</b></div><div><span>Errors</span><b class="${a.err_pct >= 5 ? 'bad' : a.err_pct >= 1 ? 'warn' : 'ok'}">${pct(a.err_pct, 1)}</b></div></div>
        <div class="app-actions"><a class="btn ghost sm" style="text-align:center" href="#/metrics/${encodeURIComponent(a.name)}">View Details</a><a class="btn ghost sm" style="text-align:center" href="#/pods?app=${encodeURIComponent(a.name)}">View Pods</a>${a.has_app_metrics ? `<a class="btn ghost sm" style="text-align:center" target="_blank" rel="noopener" href="/demo/${encodeURIComponent(a.name)}/" title="Open the application's own UI">Open app ↗</a>` : ''}</div>
      </div>`).join('') || '<div class="card empty">No monitored applications yet. Add one to start.</div>'}</div>`;
    $('#addapp').onclick = addAppDialog;
    this.sparks();
  }
};

async function addAppDialog() {
  const r = await api('/api/candidates'), list = r.data.candidates || [], m = $('#modal');
  m.innerHTML = `<h2 style="margin-bottom:6px">Add application</h2><p class="muted" style="margin-bottom:14px">Choose a Deployment in the watched namespace. KubeGuard labels it and starts monitoring.</p>
    ${list.map(n => `<div class="set-row"><b>${esc(n)}</b><button class="btn sm" data-n="${esc(n)}">Add</button></div>`).join('') || '<p class="empty">Every deployment in this namespace is already monitored.</p>'}
    <div style="text-align:right;margin-top:14px"><button class="btn ghost" id="mc">Close</button></div>`;
  m.showModal(); $('#mc').onclick = () => m.close();
  m.querySelectorAll('[data-n]').forEach(b => b.onclick = async () => {
    b.disabled = true; const res = await post('/api/apps', {name: b.dataset.n});
    toast(res.ok ? `${b.dataset.n} is now monitored` : res.data.message); m.close(); tick();
  });
}

V.pods = {
  render() {
    S.podApp = S.route.query.app || '';
    $('#main').innerHTML = head('Pods', 'Live state of every pod in the watched namespace',
      `<select id="podsel" aria-label="Filter by application"><option value="">All applications</option></select>`) +
      `<div class="card scroll"><table class="tbl"><thead><tr><th>Pod</th><th>Application</th><th>Status</th><th>Ready</th><th>Restarts</th><th>CPU</th><th>Memory</th><th>Age</th><th></th></tr></thead><tbody id="podrows"></tbody></table></div>`;
    $('#podsel').onchange = e => { S.podApp = e.target.value; this.refresh(); };
    this.refresh();
  },
  refresh() {
    const o = S.ov; if (!o || !$('#podrows')) return;
    const sel = $('#podsel'); if (sel.options.length === 1) o.apps.forEach(a => sel.add(new Option(a.name, a.name)));
    sel.value = S.podApp;
    api('/api/pods' + (S.podApp ? '?app=' + encodeURIComponent(S.podApp) : '')).then(r => {
      if (!$('#podrows')) return;
      const age = s => s < 90 ? Math.round(s) + 's' : s < 5400 ? Math.round(s / 60) + 'm' : (s / 3600).toFixed(1) + 'h';
      $('#podrows').innerHTML = (r.data.pods || []).map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.app)}</td>
        <td><span class="pill ${p.ready ? '' : 'warning'}">${esc(p.status)}</span></td><td class="${p.ready ? 'ok' : 'bad'}">${p.ready ? 'Ready' : 'Not ready'}</td>
        <td class="num">${p.restarts}</td><td class="num">${p.cpu_cores == null ? '–' : num(p.cpu_cores * 1000) + 'm'}${p.cpu_pct == null ? '' : ` <span class="muted small">${num(p.cpu_pct)}%</span>${mini(p.cpu_pct, 70)}`}</td>
        <td class="num">${p.mem_mib == null ? '–' : num(p.mem_mib) + ' MiB'}${p.mem_pct == null ? '' : ` <span class="muted small">${num(p.mem_pct)}%</span>${mini(p.mem_pct, 75)}`}</td>
        <td class="num">${age(p.age_s)}</td><td><button class="btn ghost sm" data-p="${esc(p.name)}">Restart</button></td></tr>`).join('') || '<tr><td colspan="9" class="empty">No pods</td></tr>';
      document.querySelectorAll('[data-p]').forEach(b => b.onclick = async () => {
        if (!confirm(`Delete pod ${b.dataset.p}? Its Deployment will create a replacement.`)) return;
        const res = await post(`/api/pods/${encodeURIComponent(b.dataset.p)}/delete`); toast(res.ok ? 'Pod deleted; a replacement is starting' : res.data.message);
        tick();
      });
    });
  }
};

V.incidents = {
  render() {
    const id = S.route.param;
    if (id) return this.detail(id);
    $('#main').innerHTML = head('Incidents', 'View and track all detected incidents and recovery actions',
      `<a class="btn ghost sm" href="/api/incidents.csv" download>${ico('download')} Export CSV</a>`) + `<div class="strip" id="strip"></div>` + `<div class="card lane" id="lane" style="margin-bottom:14px"></div>` +
      `<div class="card"><div class="tabs" id="tabs">${['all', 'active', 'recovered', 'failed'].map(t => `<button class="tab ${S.filter === t ? 'on' : ''}" data-t="${t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div>
      <div class="scroll"><table class="tbl"><thead><tr><th>ID</th><th>Time</th><th>Application</th><th>Incident Type</th><th>Severity</th><th>Status</th><th>Recovery Action</th><th>Recovery Time</th><th>Actions</th></tr></thead><tbody id="increws"></tbody></table></div></div>`;
    document.querySelectorAll('.tab').forEach(b => b.onclick = () => { S.filter = b.dataset.t; document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === b)); this.refresh(); });
    this.refresh();
  },
  async refresh() {
    if (S.route.param) return this.detail(S.route.param);
    const r = await api('/api/incidents' + (S.filter === 'all' ? '' : '?status=' + S.filter)); if (!$('#increws')) return;
    const rows = r.data.incidents || [];
    (S.filter === 'all' ? Promise.resolve(r) : api('/api/incidents')).then(all => this.lane(all.data.incidents || []));
    api('/api/summary').then(sm => { if (!$('#strip')) return; const d = sm.data, c = (n, l, cls = '') => `<div class="card"><div class="n ${cls}">${n}</div><div class="l">${l}</div></div>`;
      $('#strip').innerHTML = c(d.total, 'Total incidents') + c(d.success_rate == null ? '–' : d.success_rate + '%', 'Recovery success rate', d.success_rate != null && d.success_rate < 80 ? 'warn' : 'ok') +
        c(d.mttr_seconds == null ? '–' : d.mttr_seconds + 's', 'Mean time to recovery') + c(d.active, 'Active now', d.active ? 'bad' : ''); });
    $('#increws').innerHTML = rows.map(i => `<tr><td class="num">#${i.id}</td><td class="num">${hms(i.detected_at)}</td><td>${esc(i.application)}</td><td>${esc(i.type_label)}${i.source === 'experiment' ? ' <span class="muted small">(experiment)</span>' : ''}</td>
      <td><span class="pill ${sev(i.severity)}">${esc(i.severity)}</span></td><td><span class="pill ${sev(i.status)}">${i.status[0] + i.status.slice(1).toLowerCase()}</span></td>
      <td>${esc(i.action || (i.status === 'ACTIVE' ? 'Planning…' : '–'))}</td><td class="num">${dur(i.recovery_seconds)}</td><td><a class="btn sm" href="#/incidents/${i.id}">View</a></td></tr>`).join('')
      || '<tr><td colspan="9" class="empty">No incidents. Run an experiment to create one.</td></tr>';
  },
  lane(incs) {
    if (!$('#lane')) return;
    const ranges = {'15m': 900, '1h': 3600, '6h': 21600, '24h': 86400};
    const end = S.ov?.now || Date.now() / 1000;
    const oldest = incs.length ? end - Math.min(...incs.map(i => i.detected_at)) : 0;
    const range = S.laneRange || Object.keys(ranges).find(k => ranges[k] >= oldest * 1.15) || '24h';   // auto-fit until the user picks one
    const span = ranges[range], t0 = end - span;
    const inWin = incs.filter(i => (i.resolved_at || end) >= t0 && i.detected_at <= end);
    const names = [...new Set([...(S.ov?.apps || []).map(a => a.name), ...inWin.map(i => i.application)])];
    const W = 1000, L = 96, R = 12, T = 8, LH = 34, H = T + names.length * LH + 26, w = W - L - R, X = t => L + Math.max(0, Math.min(1, (t - t0) / span)) * w;
    let g = '';
    for (let k = 0; k <= 4; k++) { const t = t0 + span * k / 4, x = X(t); g += `<line x1="${x}" x2="${x}" y1="${T}" y2="${H - 22}" class="gl"/><text class="axis" x="${x}" y="${H - 6}" text-anchor="${k === 0 ? 'start' : k === 4 ? 'end' : 'middle'}">${new Date(t * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', hour12: false})}</text>`; }
    names.forEach((n, r) => { const y = T + r * LH; g += `<text class="lbl" x="${L - 10}" y="${y + LH / 2 + 4}" text-anchor="end">${esc(n)}</text><line x1="${L}" x2="${W - R}" y1="${y + LH}" y2="${y + LH}" class="gl" opacity=".5"/>`; });
    g += inWin.map(i => {
      const r = names.indexOf(i.application), y = T + r * LH + 6, x1 = X(i.detected_at), x2 = Math.max(x1 + 7, X(i.resolved_at || end));
      const c = i.status === 'RECOVERED' ? '#12a05c' : i.status === 'FAILED' ? '#dc3a3a' : '#e8890c';
      return `<a href="#/incidents/${i.id}"><title>#${i.id} ${esc(i.type_label)} · ${esc(i.status.toLowerCase())}${i.recovery_seconds != null ? ' · ' + i.recovery_seconds + 's' : ''}</title>
        <rect class="${i.status === 'ACTIVE' ? 'bar-a' : ''}" x="${x1}" y="${y}" width="${x2 - x1}" height="${LH - 12}" rx="6" fill="${c}"/>${x2 - x1 > 34 ? `<text x="${x1 + 8}" y="${y + 15}" fill="#fff" font-size="11" font-weight="600">#${i.id}</text>` : ''}</a>`;
    }).join('');
    $('#lane').innerHTML = `<div class="lane-head"><h2>Incident timeline</h2><select id="laner" aria-label="Timeline range">${Object.keys(ranges).map(k => `<option value="${k}" ${k === range ? 'selected' : ''}>Last ${k}</option>`).join('')}</select></div>` +
      (inWin.length ? `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Incident timeline">${g}</svg>` : `<div class="empty small">No incidents in the last ${range}. Nothing needed recovering.</div>`);
    $('#laner').onchange = e => { S.laneRange = e.target.value; this.lane(incs); };
  },
  async detail(id) {
    const r = await api('/api/incidents/' + id);
    if (!r.ok) { $('#main').innerHTML = head('Incident not found', '') + `<a href="#/incidents">Back to incidents</a>`; return; }
    const i = r.data, live = i.status === 'ACTIVE', now = i.live;
    const metrics = (m, liveNow) => {
      const x = liveNow ? {cpu_pct: now?.cpu_pct, mem_pct: now?.mem_pct, resp_ms: now?.resp_ms, err_pct: now?.err_pct} : (m || {});
      const row = (l, v, txt, w, cls) => `<div class="metric-row"><span>${l}</span>${bar(w, cls)}<b>${txt}</b></div>`;
      const cls = (v, hi) => v == null ? '' : v >= hi ? 'critical' : v >= hi * .75 ? 'warning' : 'blue';
      return row('CPU Usage', x.cpu_pct, pct(x.cpu_pct), x.cpu_pct, cls(x.cpu_pct, 90)) + row('Memory Usage', x.mem_pct, pct(x.mem_pct), x.mem_pct, cls(x.mem_pct, 90)) +
        row('Response Time', x.resp_ms, x.resp_ms == null ? '–' : num(x.resp_ms) + 'ms', (x.resp_ms || 0) / 10, cls(x.resp_ms, 1000)) + row('Error Rate', x.err_pct, pct(x.err_pct, 1), (x.err_pct || 0) * 10, cls(x.err_pct, 5));
    };
    const stepsHtml = i.steps.map((s, n) => {
      const inner = s.state === 'done' ? ico('check') : s.state === 'failed' ? ico('x') : n + 1;
      return `<li><span class="sdot ${s.state}">${inner}</span><div><b>${esc(s.label)}</b>${s.detail ? `<div class="d">${esc(s.detail)}${s.state === 'active' ? ' …' : ''}</div>` : ''}</div><span class="t">${hms(s.ts)}</span></li>`;
    }).join('');
    const afterTitle = live ? 'Metrics After Recovery (Live)' : i.status === 'RECOVERED' ? 'Metrics After Recovery' : 'Metrics At End Of Attempt';
    const html = head(`<span class="back"><a href="#/incidents" aria-label="Back to incidents">${ico('back')}</a>Incident #${i.id}</span>`, '', `<span class="pill ${sev(i.status)}">${i.status[0] + i.status.slice(1).toLowerCase()}</span>`) + `
      <div class="split">
        <div class="card"><h2>Incident Information</h2><div class="kv">
          <div>Application</div><div><b>${esc(i.application)}</b></div><div>Incident Type</div><div>${esc(i.type_label)}</div>
          <div>Severity</div><div><span class="pill ${sev(i.severity)}">${esc(i.severity)}</span></div>
          <div>Detected Time</div><div>${new Date(i.detected_at * 1000).toLocaleString([], {hour12: false})}</div>
          <div>Status</div><div><span class="pill ${sev(i.status)}">${i.status[0] + i.status.slice(1).toLowerCase()}</span></div>
          <div>Recovery Action</div><div>${esc(i.action || 'Planning…')}</div><div>Recovery Time</div><div>${live ? `<span class="kv-live">${Math.max(0, (S.ov?.now || Date.now() / 1000) - i.detected_at).toFixed(0)}s elapsed</span>` : dur(i.recovery_seconds)}</div>
          <div>Description</div><div style="white-space:normal">${esc(i.description)}</div></div></div>
        <div class="card"><h2>Recovery Progress</h2><ul class="steps">${stepsHtml}</ul></div>
      </div>
      <div class="split mt"><div class="card"><h2>Metrics Before Incident</h2>${metrics(i.before)}</div>
        <div class="card"><h2>${afterTitle}</h2>${metrics(i.after, live && now)}</div></div>`;
    $('#main').innerHTML = html;
  }
};

V.experiments = {
  render() {
    const names = (S.ov?.apps || []).map(a => a.name);
    const exp = (cls, icon, title, text, kind, btn) => `<div class="exp ${cls}">${ico(icon)}<h3>${title}</h3><p>${text}</p><button class="btn" data-k="${kind}">${btn}</button></div>`;
    $('#main').innerHTML = head('Experiments', 'Trigger test scenarios to demonstrate KubeGuard\'s auto-recovery capability') + `
      <div class="opts"><label>Target application <select id="xapp">${names.map(n => `<option ${n === 'backend' ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
        <label>Duration <select id="xsec"><option value="60">60 s</option><option value="90" selected>90 s</option><option value="120">120 s</option><option value="180">180 s</option></select></label>
        <button class="btn ghost sm" id="xstop">Stop all experiments</button></div>
      <div class="chips" id="xactive"></div>
      <div class="grid g4">
        ${exp('red', 'trash', 'Crash Pod', 'Delete a running pod to simulate pod failure', 'crash', 'Trigger Crash')}
        ${exp('orange', 'cpu', 'CPU Stress', 'Generate high CPU load on application pods', 'cpu', 'Trigger CPU Stress')}
        ${exp('purple', 'db', 'Memory Stress', 'Generate high memory usage on application pods', 'memory', 'Trigger Memory Stress')}
        ${exp('blue', 'tri', 'Generate Errors', 'Make application pods return HTTP 500 to increase error rate', 'errors', 'Trigger Errors')}
      </div>
      <div class="note mt"><b>Experiment Instructions</b><ul>
        <li>Each experiment injects a real failure into the selected application (not a simulated incident row).</li>
        <li>KubeGuard detects the problem from live metrics (it must persist for the sustained time in Settings) and applies recovery.</li>
        <li>Open <a href="#/incidents">Incidents</a> to watch detection, recovery and verification. Crash Pod opens its incident immediately.</li></ul></div>`;
    document.querySelectorAll('[data-k]').forEach(b => b.onclick = async () => {
      b.disabled = true;
      const r = await post('/api/experiments/' + b.dataset.k, {application: $('#xapp').value, seconds: +$('#xsec').value});
      toast(r.ok ? r.data.message : (r.data.message || 'Experiment failed'));
      setTimeout(() => b.disabled = false, 2000);
      if (r.ok && r.data.incident) location.hash = '#/incidents/' + r.data.incident;
    });
    $('#xstop').onclick = async () => { const r = await post('/api/experiments/stop', {application: $('#xapp').value}); toast(r.ok ? `Stopped experiments on ${r.data.pods} pod(s)` : r.data.message); this.refresh(); };
    this.refresh();
  },
  async refresh() {
    const r = await api('/api/experiments/active'); const el = $('#xactive'); if (!el || !r.ok) return;
    const names = {cpu: 'CPU stress', memory: 'Memory stress', errors: 'Error injection'};
    el.innerHTML = r.data.active.map(a => `<span class="chip">${names[a.kind] || a.kind} on ${esc(a.application)} · ${a.seconds_left}s left <button data-s="${esc(a.application)}">Stop</button></span>`).join('');
    el.querySelectorAll('[data-s]').forEach(b => b.onclick = async () => { await post('/api/experiments/stop', {application: b.dataset.s}); toast('Experiment stopped'); this.refresh(); });
  }
};

V.metrics = {
  render() {
    const o = S.ov; if (!o) return;
    const app = S.route.param || o.apps[0]?.name;
    $('#main').innerHTML = head(`<span class="back"><a href="#/applications" aria-label="Back to applications">${ico('back')}</a>Application Metrics - ${esc(app || '')}</span>`, '',
      `<select id="msel" aria-label="Application">${o.apps.map(a => `<option ${a.name === app ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select>
       <select id="mrange" aria-label="Time range">${[['15m', 'Last 15 minutes'], ['1h', 'Last 1 hour'], ['3h', 'Last 3 hours'], ['6h', 'Last 6 hours']].map(([v, l]) => `<option value="${v}" ${S.range === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
       <button class="btn ghost sm" id="mstop">Stop monitoring</button>`) +
      `<div class="grid g2" id="mcharts"></div>`;
    $('#msel').onchange = e => location.hash = '#/metrics/' + encodeURIComponent(e.target.value);
    $('#mrange').onchange = e => { S.range = e.target.value; this.refresh(true); };
    $('#mstop').onclick = async () => { if (!app || !confirm(`Stop monitoring ${app}? Its deployment is not changed.`)) return; const r = await api('/api/apps/' + encodeURIComponent(app), {method: 'DELETE'}); toast(r.ok ? app + ' is no longer monitored' : r.data.message); location.hash = '#/applications'; };
    this.refresh(true);
  },
  async refresh(force) {
    const app = S.route.param || S.ov?.apps[0]?.name; if (!app || !$('#mcharts')) return;
    if (!force && Date.now() - (this.at || 0) < 10000) return;
    this.at = Date.now();
    const r = await api(`/api/metrics/app/${encodeURIComponent(app)}?range=${S.range}`); if (!r.ok || !$('#mcharts')) return;
    const d = r.data, th = d.thresholds || {}, mk = d.incidents || [];
    const card = (id, t, hint) => `<div class="card"><h2>${t}${hint ? ` <span class="muted small" style="font-weight:400">${hint}</span>` : ''}</h2><div class="chart" id="${id}"></div></div>`;
    $('#mcharts').innerHTML = card('c-cpu', 'CPU Usage (%)', mk.length ? '▼ incident marker (click)' : '') + card('c-mem', 'Memory Usage (%)') + card('c-resp', 'Response Time (ms)') + card('c-err', 'Error Rate (%)');
    const o = (extra) => ({fill: true, markers: mk, ...extra});
    renderChart($('#c-cpu'), [{name: 'CPU', color: '#1769e0', points: d.cpu}], o({max: 100, unit: '%', threshold: {value: th.cpu, label: `critical ${th.cpu}%`}}));
    renderChart($('#c-mem'), [{name: 'Memory', color: '#12a05c', points: d.memory}], o({max: 100, unit: '%', threshold: {value: th.memory, label: `critical ${th.memory}%`}}));
    renderChart($('#c-resp'), [{name: 'Response time', color: '#7a3de0', points: d.response}], o({fmt: v => v.toFixed(0) + ' ms'}));
    renderChart($('#c-err'), [{name: 'Errors', color: '#dc3a3a', points: d.errors}], o({unit: '%', threshold: {value: th.errors, label: `critical ${th.errors}%`}}));
  }
};

V.settings = {
  fields: [['sustain_seconds', 'Sustained duration', 'seconds a breach must last before an incident is raised', 's'],
    ['cpu_critical', 'CPU critical threshold', '% of the pod CPU limit', '%'], ['memory_critical', 'Memory critical threshold', '% of the pod memory limit', '%'],
    ['error_rate_critical', 'Error-rate threshold', '% of requests answered with HTTP 5xx', '%'], ['latency_warn_ms', 'Latency warning', 'only lowers the health score', 'ms'],
    ['max_replicas', 'Maximum replicas', 'upper bound for automatic scale-out', ''], ['cooldown_seconds', 'Cooldown', 'minimum time between incidents of the same type', 's'],
    ['verify_timeout', 'Verification timeout', 'mark recovery as failed after this long', 's'], ['self_heal_grace', 'Self-heal grace', 'time Kubernetes gets to replace a failed pod first', 's'],
    ['scale_down_idle_seconds', 'Scale-down delay', 'low load for this long returns to the baseline replica count', 's']],
  async render() {
    const r = await api('/api/settings'); S.settings = r.data;
    $('#main').innerHTML = head('Settings', 'Detection thresholds and auto-recovery policy') + `<div class="card" style="max-width:760px">
      <div class="set-row"><div><b>Auto-recovery</b><div class="muted small">When off, KubeGuard still detects and records incidents but takes no action.</div></div>
        <button class="switch" id="auto" role="switch" aria-checked="${!!S.settings.auto_recovery}" aria-label="Auto-recovery"></button></div>
      ${this.fields.map(([k, l, h, u]) => `<div class="set-row"><div><b>${l}</b><div class="muted small">${h}</div></div><label><input type="number" id="s_${k}" value="${S.settings[k]}" step="any"> ${u}</label></div>`).join('')}
      <div style="margin-top:16px;display:flex;gap:10px"><button class="btn" id="save">Save settings</button><button class="btn ghost" id="reset">Reset to defaults</button></div></div>`;
    $('#reset').onclick = async () => { if (!confirm('Reset all thresholds to their defaults?')) return; const r = await post('/api/settings/reset'); toast(r.ok ? 'Defaults restored' : 'Reset failed'); this.render(); };
    $('#auto').onclick = e => e.currentTarget.setAttribute('aria-checked', e.currentTarget.getAttribute('aria-checked') !== 'true');
    $('#save').onclick = async () => {
      const body = {auto_recovery: $('#auto').getAttribute('aria-checked') === 'true' ? 1 : 0};
      this.fields.forEach(([k]) => body[k] = parseFloat($('#s_' + k).value));
      const res = await post('/api/settings', body); toast(res.ok ? 'Settings saved' : (res.data.error || 'Could not save settings'));
      if (res.ok) this.render();
    };
  },
  refresh() {}
};

/* --------------------------------------------------------------- router */
function parseRoute() {
  const [path, qs] = location.hash.replace(/^#\/?/, '').split('?');
  const [name, param] = path.split('/');
  return {name: V[name] ? name : 'dashboard', param: param ? decodeURIComponent(param) : '', query: Object.fromEntries(new URLSearchParams(qs || ''))};
}

function route() {
  S.route = parseRoute();
  $('#nav').innerHTML = NAV.map(([k, l, i]) => `<a href="#/${k}" class="${S.route.name === k ? 'active' : ''}" ${S.route.name === k ? 'aria-current="page"' : ''}>${ico(i)}<span>${l}</span>${k === 'incidents' ? '<span class="nav-badge" id="nb" hidden></span>' : ''}</a>`).join('');
  chrome();
  const m = $('#main'); m.classList.remove('enter'); void m.offsetWidth; m.classList.add('enter');
  V[S.route.name].render();
}

function chrome() {
  const n = S.ov?.counts?.active || 0, nb = $('#nb');
  if (nb) { nb.hidden = !n; nb.textContent = n; nb.setAttribute('aria-label', `${n} active incidents`); }
  document.title = (n ? `(${n}) ` : '') + (S.cfg.brand || 'KubeGuard');
  const lv = $('#live'); if (lv) { lv.className = 'live-ind' + (S.paused ? ' paused' : ''); lv.innerHTML = `<span class="ldot"></span>${S.paused ? 'Paused' : 'Live'}`; }
}

function announce() {
  const evs = (S.ov?.events || []).slice().reverse(), top = Math.max(0, ...evs.map(e => e.id));
  if (S.lastEvent == null) { S.lastEvent = top; return; }
  const fresh = evs.filter(e => e.id > S.lastEvent && ['ok', 'warn', 'error'].includes(e.level));
  S.lastEvent = Math.max(S.lastEvent, top);
  if (fresh.length) toast(fresh.at(-1).message);
}

function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem('kg-theme', t); } catch (_) { /* private mode */ }
  $('#theme').innerHTML = ico(t === 'dark' ? 'sun' : 'moon') + (t === 'dark' ? 'Light mode' : 'Dark mode');
}

async function tick(force) {
  if (S.paused && force !== true) return;
  const r = await api('/api/overview');
  if (r.ok) S.ov = r.data;
  announce(); chrome();
  const v = V[S.route.name];
  if (S.ov && v.refresh) v.refresh();
}

(async function init() {
  const c = await api('/api/config'); S.cfg = c.data;
  $('#brand').textContent = S.cfg.brand || 'KubeGuard'; document.title = S.cfg.brand || 'KubeGuard';
  $('#mode').textContent = S.cfg.mode === 'mock' ? 'Simulator mode' : `ns: ${S.cfg.namespace}`;
  const r = await api('/api/overview'); if (r.ok) S.ov = r.data;
  applyTheme(document.documentElement.dataset.theme || 'light');
  $('#theme').onclick = () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  announce(); initPalette();
  window.addEventListener('hashchange', route);
  route();
  setInterval(tick, 3000);
})();
