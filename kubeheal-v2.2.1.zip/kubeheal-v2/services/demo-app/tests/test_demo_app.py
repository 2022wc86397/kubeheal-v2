import importlib
import os
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
HTML = {"Accept": "text/html,application/xhtml+xml"}


@pytest.fixture
def mod(monkeypatch):
    monkeypatch.setenv("APP_NAME", "backend")
    monkeypatch.delenv("ALLOW_CRASH", raising=False)
    import app as m
    m = importlib.reload(m)
    return m


@pytest.fixture
def c(mod):
    return mod.app.test_client()


def test_browsers_get_the_ui_and_clients_get_json(c):
    page = c.get("/", headers=HTML)
    assert page.status_code == 200 and page.mimetype == "text/html"
    body = page.get_data(as_text=True)
    assert "<h1>backend</h1>" in body and "API tier" in body and "__APP__" not in body and "#7a3de0" in body
    j = c.get("/")                                           # urllib / curl / loadgen send no text/html Accept
    assert j.mimetype == "application/json" and j.json["app"] == "backend"
    assert c.get("/", headers={"Accept": "application/json"}).mimetype == "application/json"


def test_ui_is_escaped_and_themed_per_app(monkeypatch):
    monkeypatch.setenv("APP_NAME", 'x"><script>alert(1)</script>')
    import app as m
    m = importlib.reload(m)
    body = m.app.test_client().get("/", headers=HTML).get_data(as_text=True)
    assert "<script>alert(1)</script>" not in body


def test_served_by_header_everywhere(c, mod):
    for path in ("/", "/healthz", "/api/stats"):
        assert c.get(path).headers["X-Served-By"] == mod.POD


def test_ui_page_loads_are_not_counted_in_metrics(c):
    c.get("/", headers=HTML); c.get("/api/stats"); c.get("/healthz")
    assert "http_requests_total" not in c.get("/metrics").get_data(as_text=True).replace("# TYPE http_requests_total counter", "")
    c.get("/")
    assert 'http_requests_total{code="200"} 1' in c.get("/metrics").get_data(as_text=True)


def test_stats_shape_and_traffic_numbers(c):
    for _ in range(6):
        c.get("/")
    s = c.get("/api/stats").json
    assert s["app"] == "backend" and s["role"] == "API tier" and s["total"] == 6 and s["codes"] == {"200": 6}
    assert s["rps"] == 0.6 and s["avg_ms"] and s["err_pct"] == 0.0
    assert 0 < s["mem_pct"] < 100 and s["mem_limit_mib"] == 192 and s["cpu_limit_cores"] > 0
    assert s["faults"] == {"cpu": 0, "memory": 0, "errors": 0, "error_rate": 0}


def test_error_fault_shows_in_stats_but_never_breaks_the_ui_or_health(c):
    assert c.post("/chaos/errors?seconds=30&rate=1").json["ok"]
    assert c.get("/").status_code == 500                     # API traffic fails...
    assert c.get("/", headers=HTML).status_code == 200       # ...but the UI page still loads
    assert c.get("/healthz").status_code == 200 and c.get("/api/stats").status_code == 200
    s = c.get("/api/stats").json
    assert s["err_pct"] == 100.0 and s["codes"]["500"] == 1 and s["faults"]["errors"] > 0 and s["faults"]["error_rate"] == 1.0
    c.post("/chaos/stop")
    assert c.get("/").status_code == 200 and c.get("/api/stats").json["faults"]["errors"] == 0


def test_memory_fault_really_allocates_and_releases(c, mod):
    before = c.get("/api/stats").json["mem_mib"]
    assert c.post("/chaos/memory?seconds=3&percent=60").json["percent"] == 60
    time.sleep(1.2)
    held = c.get("/api/stats").json
    assert held["mem_mib"] > before + 20 and held["faults"]["memory"] > 0
    time.sleep(2.8)
    assert len(mod._ballast) == 0 and c.get("/api/stats").json["mem_mib"] < held["mem_mib"]


def test_memory_fault_never_requests_oom_levels(c):
    assert c.post("/chaos/memory?seconds=1&percent=500").json["percent"] == 96


def test_cpu_fault_raises_measured_cpu_and_app_stays_responsive(c, mod):
    mod._cpu_cores()
    time.sleep(1.1)
    idle = c.get("/api/stats").json["cpu_pct"]
    assert c.post("/chaos/cpu?seconds=4").json["ok"]
    time.sleep(1.2)
    t0 = time.time(); assert c.get("/healthz").status_code == 200
    assert time.time() - t0 < 2                               # health checks survive the burn
    busy = c.get("/api/stats").json
    assert busy["cpu_pct"] > idle + 40 and busy["faults"]["cpu"] > 0
    c.post("/chaos/stop")


def test_crash_endpoint_is_disabled_unless_explicitly_enabled(c):
    r = c.post("/chaos/crash")
    assert r.status_code == 403 and "ALLOW_CRASH" in r.json["error"]


def test_cpu_uses_process_time_when_no_cgroup_quota(mod, monkeypatch):
    """Unlimited container: cgroup counters cover the whole machine, so they must not be used."""
    monkeypatch.setattr(mod, "_cgroup_cpu_quota", lambda: None)
    called = []
    monkeypatch.setattr(mod, "_cgroup_read", lambda *a, **k: called.append(a) or 10 ** 12)
    assert abs(mod._cpu_usage_seconds() - time.process_time()) < 1.0
    assert not called


def test_cpu_uses_cgroup_counters_in_a_limited_pod(mod, monkeypatch):
    monkeypatch.setattr(mod, "_cgroup_cpu_quota", lambda: 0.2)
    monkeypatch.setattr(mod, "_cgroup_read", lambda *a, **k: 5_000_000_000 if "cpuacct" in a[0] else None)
    monkeypatch.setattr("builtins.open", lambda *a, **k: (_ for _ in ()).throw(OSError()))
    assert mod._cpu_usage_seconds() == 5.0
    assert mod._cpu_limit_cores() == 0.2
