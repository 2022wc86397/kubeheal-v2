#!/usr/bin/env bash
# One-shot installer: Amazon Linux 2023 / 2, Ubuntu, Debian. 2 vCPU and >= 2 GB RAM (a swap file is added).
# Installs k3s (lightweight Kubernetes), builds the two images, deploys Prometheus + demo apps + KubeHeal,
# then PROVES the dashboard works (readiness, API, monitored apps) before declaring success.
# Re-runnable: every step is idempotent. On any failure it prints diagnostics automatically.
#
#   ./install.sh               install
#   ./install.sh --dry-run     print every command it would run (no changes); honours OS_RELEASE_FILE for testing
#
# Optional env: KUBEHEAL_PASSWORD=...      dashboard password (default: random, printed once)
#               NOTIFY_WEBHOOK_URL=...     Slack-compatible webhook for incident alerts
#               GUI_PORT=8080              host port of the dashboard (default 8080; k3s' NodePort range is widened to allow it)
#               K3S_VERSION=v1.31.4+k3s1   pin a k3s release
#               USE_EXISTING_CLUSTER=1     skip k3s; use the cluster kubectl already points at (dashboard then defaults to 30080)
#               SKIP_PACKAGES=1            docker and curl are already installed; do not touch the package manager
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="2.2.1"
KH_IMG="kubeheal/kubeheal:${VERSION}"
DEMO_IMG="kubeheal/demo-app:${VERSION}"
K3S=/usr/local/bin/k3s                      # absolute: sudo's secure_path on Amazon Linux/RHEL omits /usr/local/bin
# Dashboard port on the host. k3s only allows NodePorts 30000-32767 by default, so for 8080 we widen the range (step 3).
if [[ -n "${GUI_PORT:-}" ]]; then NODEPORT="$GUI_PORT"
elif [[ "${USE_EXISTING_CLUSTER:-0}" == 1 ]]; then NODEPORT=30080          # we cannot reconfigure someone else's apiserver
else NODEPORT=8080; fi
DRY_RUN=0

for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    -h|--help) sed -n '2,18p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $arg (try --help)" >&2; exit 2 ;;
  esac
done

# shellcheck source=scripts/lib/os.sh
source "$ROOT/scripts/lib/os.sh"

log()  { printf '\n\033[1;34m[KubeHeal]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mWARN:\033[0m %s\n' "$*" >&2; }
fail() { printf '\033[1;31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }
run()  { if (( DRY_RUN )); then printf '+ %s\n' "$*"; else "$@"; fi; }
note() { if (( DRY_RUN )); then printf '# %s\n' "$*"; fi; }

on_error() {
  local line="$1"
  printf '\033[1;31mERROR:\033[0m step failed at line %s.\n' "$line" >&2
  if (( ! DRY_RUN )) && command -v kubectl >/dev/null 2>&1; then
    echo "Collecting diagnostics (also saved under /tmp/kubeheal-diagnose-*.txt) ..." >&2
    "$ROOT/scripts/diagnose.sh" >&2 || true
  fi
}
trap 'on_error $LINENO' ERR

[[ "$NODEPORT" =~ ^[0-9]+$ ]] && (( NODEPORT >= 1024 && NODEPORT <= 32767 )) || { echo "GUI_PORT must be a number between 1024 and 32767 (got '$NODEPORT')" >&2; exit 2; }
PORT_RANGE="$(( NODEPORT < 30000 ? NODEPORT : 30000 ))-32767"

# ----------------------------------------------------------- 0. preflight
(( DRY_RUN )) || [[ $EUID -ne 0 ]] || fail "Run as a normal user with sudo rights (e.g. ec2-user or ubuntu), not as root."
(( DRY_RUN )) || command -v sudo >/dev/null || fail "sudo is required."
case "$(uname -m)" in x86_64|aarch64|arm64) ;; *) fail "Unsupported CPU architecture $(uname -m)";; esac
detect_os || fail "OS detection failed."
log "Host: ${OS_ID} ${OS_VERSION} (${OS_FAMILY}, package manager: ${PKG}, SELinux: ${SELINUX_MODE})"

CPUS=$(nproc); MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
(( CPUS >= 2 )) || warn "Only ${CPUS} vCPU detected. 2 are recommended; recovery will be slow."
(( MEM_MB >= 1700 )) || warn "Only ${MEM_MB} MB RAM. 2 GB is the minimum (4 GB comfortable); swap will be added."

if (( ! DRY_RUN )) && command -v ss >/dev/null 2>&1 && ss -ltn 2>/dev/null | awk '{print $4}' | grep -qE "[:.]${NODEPORT}\$"; then
  warn "Something already listens on port ${NODEPORT} on this host (fine if it is a previous KubeGuard install; otherwise choose GUI_PORT=<other>)."
fi

# ----------------------------------------------------------- 1. swap
log "1/8 Ensuring swap (protects a small instance from OOM during image builds)"
if [[ -z "$(swapon --show --noheadings 2>/dev/null)" ]]; then
  # dd rather than fallocate: swap files on XFS (Amazon Linux's default) must not be sparse
  run sudo dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
  run sudo chmod 600 /swapfile
  run sudo mkswap /swapfile
  run sudo swapon /swapfile
  if (( DRY_RUN )); then echo "+ echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab   # unless already present"
  elif ! grep -q '^/swapfile' /etc/fstab; then echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null; fi
else
  echo "swap already present"
fi

# ----------------------------------------------------------- 2. docker + curl
log "2/8 Installing Docker (used only to build the images)"
if [[ "${SKIP_PACKAGES:-0}" == 1 ]]; then
  echo "SKIP_PACKAGES=1: not touching the package manager"
else
  case "$PKG" in
    apt)
      run sudo apt-get update -y
      run sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y docker.io curl ca-certificates ;;
    dnf|yum)
      run sudo "$PKG" install -y docker
      # Amazon Linux ships curl-minimal; installing 'curl' would conflict with it, so only add curl if truly missing
      command -v curl >/dev/null 2>&1 || run sudo "$PKG" install -y curl ;;
  esac
fi
run sudo systemctl enable --now docker

# ----------------------------------------------------------- 3. k3s
if [[ "${USE_EXISTING_CLUSTER:-0}" != "1" ]]; then
  log "3/8 Installing k3s (traefik, servicelb and metrics-server disabled to save ~300 MB RAM)"
  # Allow the dashboard's NodePort (default 8080). A drop-in leaves any existing /etc/rancher/k3s/config.yaml untouched.
  K3S_DROPIN=/etc/rancher/k3s/config.yaml.d/10-kubeheal.yaml
  K3S_DROPIN_BODY=$(printf 'kube-apiserver-arg:\n  - "service-node-port-range=%s"\n' "$PORT_RANGE")
  if (( DRY_RUN )); then
    echo "+ sudo mkdir -p /etc/rancher/k3s/config.yaml.d"
    echo "+ write ${K3S_DROPIN}: kube-apiserver-arg service-node-port-range=${PORT_RANGE}"
  else
    sudo mkdir -p /etc/rancher/k3s/config.yaml.d
    if [[ "$(sudo cat "$K3S_DROPIN" 2>/dev/null || true)" != "$K3S_DROPIN_BODY" ]]; then
      printf '%s\n' "$K3S_DROPIN_BODY" | sudo tee "$K3S_DROPIN" >/dev/null
      K3S_CONFIG_CHANGED=1
    fi
  fi
  if ! command -v k3s >/dev/null 2>&1 && [[ ! -x "$K3S" ]]; then
    K3S_ENV=(INSTALL_K3S_EXEC="server --disable traefik --disable servicelb --disable metrics-server --write-kubeconfig-mode 644")
    [[ -n "${K3S_VERSION:-}" ]] && K3S_ENV+=(INSTALL_K3S_VERSION="$K3S_VERSION")
    # Amazon Linux is not on the k3s-selinux repo's list; with SELinux not enforcing the policy package is unnecessary.
    if [[ "$OS_FAMILY" == rhel && "$SELINUX_MODE" != Enforcing ]]; then K3S_ENV+=(INSTALL_K3S_SKIP_SELINUX_RPM=true); fi
    if (( DRY_RUN )); then echo "+ curl -sfL https://get.k3s.io | env ${K3S_ENV[*]} sh -"
    else curl -sfL https://get.k3s.io | env "${K3S_ENV[@]}" sh -; fi
  else
    echo "k3s already installed"
    if [[ "${K3S_CONFIG_CHANGED:-0}" == 1 ]]; then
      echo "k3s config changed (NodePort range ${PORT_RANGE}); restarting k3s"
      run sudo systemctl restart k3s
    fi
  fi
  export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
  run mkdir -p "$HOME/.kube"
  run cp -f "$KUBECONFIG" "$HOME/.kube/config"
  run chmod 600 "$HOME/.kube/config"
else
  log "3/8 Using the existing cluster from your kubeconfig"
fi
export PATH="$PATH:/usr/local/bin"

if (( DRY_RUN )); then
  note "waits for the node to become Ready (up to 5 minutes)"
else
  command -v kubectl >/dev/null || fail "kubectl not found"
  for i in $(seq 1 60); do
    kubectl get nodes 2>/dev/null | grep -qw Ready && break
    [[ $i -eq 60 ]] && fail "Node did not become Ready in 5 minutes"
    sleep 5
  done
  kubectl get nodes
fi

# ----------------------------------------------------------- 4-5. images
log "4/8 Building images (${VERSION})"
run sudo docker build -q -t "$KH_IMG"   "$ROOT/services/kubeheal"
run sudo docker build -q -t "$DEMO_IMG" "$ROOT/services/demo-app"

log "5/8 Loading images into the cluster's container runtime"
import_image() {
  if [[ "${USE_EXISTING_CLUSTER:-0}" != "1" ]]; then
    if (( DRY_RUN )); then echo "+ sudo docker save $1 | sudo $K3S ctr images import -"
    else sudo docker save "$1" | sudo "$K3S" ctr images import - >/dev/null; fi
  elif command -v minikube >/dev/null 2>&1; then run minikube image load "$1"
  elif command -v kind >/dev/null 2>&1;     then run kind load docker-image "$1"
  elif (( DRY_RUN )); then echo "+ (load $1 into your cluster with 'minikube image load' / 'kind load docker-image', or push it to a registry)"
  else fail "Don't know how to load $1 into your cluster; push it to a registry and edit deploy/k8s/*.yaml"
  fi
}
import_image "$KH_IMG"; import_image "$DEMO_IMG"

# ----------------------------------------------------------- 6. deploy
log "6/8 Deploying Prometheus, demo applications and KubeHeal"
run kubectl apply -f "$ROOT/deploy/k8s/00-namespaces.yaml"

GENERATED=""
if (( DRY_RUN )); then
  note "creates secret kubeheal-auth (generated password unless KUBEHEAL_PASSWORD is set)"
elif [[ -n "${KUBEHEAL_PASSWORD:-}" ]] || ! kubectl -n kubeheal-system get secret kubeheal-auth >/dev/null 2>&1; then
  PASS="${KUBEHEAL_PASSWORD:-$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 14)}"
  kubectl -n kubeheal-system create secret generic kubeheal-auth --from-literal=password="$PASS" \
    --dry-run=client -o yaml | kubectl apply -f -
  [[ -z "${KUBEHEAL_PASSWORD:-}" ]] && GENERATED="$PASS"
fi
if [[ -n "${NOTIFY_WEBHOOK_URL:-}" ]]; then
  if (( DRY_RUN )); then note "creates secret kubeheal-notify from NOTIFY_WEBHOOK_URL"
  else kubectl -n kubeheal-system create secret generic kubeheal-notify --from-literal=url="$NOTIFY_WEBHOOK_URL" \
         --dry-run=client -o yaml | kubectl apply -f -; fi
fi

run kubectl apply -f "$ROOT/deploy/k8s/10-prometheus.yaml"
run kubectl apply -f "$ROOT/deploy/k8s/20-demo-apps.yaml"
if (( DRY_RUN )); then echo "+ sed 's/nodePort: 30080/nodePort: ${NODEPORT}/' deploy/k8s/30-kubeheal.yaml | kubectl apply -f -"
else sed "s/nodePort: 30080/nodePort: ${NODEPORT}/" "$ROOT/deploy/k8s/30-kubeheal.yaml" | kubectl apply -f -; fi

log "7/8 Waiting for every workload to become READY"
for target in "monitoring prometheus" "kubeheal-demo frontend" "kubeheal-demo backend" "kubeheal-demo database" \
              "kubeheal-demo loadgen" "kubeheal-system kubeheal"; do
  # shellcheck disable=SC2086
  set -- $target
  run kubectl -n "$1" rollout status "deployment/$2" --timeout=300s
done

# ----------------------------------------------------------- 8. self-check
log "8/8 Self-check: is the dashboard really working?"
if (( DRY_RUN )); then
  note "execs into the kubeheal pod: /api/health + /api/ready without credentials (as kubelet), /api/overview with the password"
  note "then probes http://<node-ip>:${NODEPORT}/api/health from this host (warning only)"
else
  kubectl -n kubeheal-system exec deploy/kubeheal -- python -c '
import base64, json, os, sys, time, urllib.request, urllib.error
def get(path, auth=False):
    r = urllib.request.Request("http://localhost:8080" + path)
    if auth:
        r.add_header("Authorization", "Basic " + base64.b64encode(("admin:" + os.environ.get("AUTH_PASSWORD", "")).encode()).decode())
    try:
        resp = urllib.request.urlopen(r, timeout=5)
        return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, b""
for path in ("/api/health", "/api/ready"):                 # exactly what the kubelet does: no credentials
    code, _ = get(path)
    print("  %s -> HTTP %s (as kubelet, no credentials)" % (path, code))
    if code != 200:
        sys.exit("probe %s answers %s: the pod would never become Ready" % (path, code))
d = {}
for _ in range(20):                                         # first monitor cycle + first Prometheus scrape
    code, body = get("/api/overview", auth=True)
    if code == 200:
        d = json.loads(body)
        if d["counts"]["applications"] >= 1 and d["cluster_connected"]:
            break
    time.sleep(3)
if not d or not d["cluster_connected"] or d["counts"]["applications"] < 1:
    sys.exit("KubeHeal is up but cannot see the cluster or any application (HTTP %s)" % code)
print("  monitoring %d applications, %d pods, cluster_connected=%s, prometheus_ok=%s" % (d["counts"]["applications"], d["counts"]["pods"], d["cluster_connected"], d["prometheus_ok"]))
'
  NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
  if curl -fsS -m 5 "http://${NODE_IP}:${NODEPORT}/api/health" >/dev/null 2>&1; then echo "  NodePort ${NODEPORT} reachable on this host"
  else warn "NodePort ${NODEPORT} did not answer on ${NODE_IP}. Use ./scripts/port-forward.sh as a fallback."; fi

  echo; kubectl get pods -A --no-headers | grep -E 'monitoring|kubeheal' || true
  TOKEN=$(curl -s -m2 -X PUT http://169.254.169.254/latest/api/token -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' || true)
  IP=$(curl -s -m2 -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/public-ipv4 || true)
  cat <<MSG

=====================================================================
 KubeGuard dashboard:   http://${IP:-<EC2-PUBLIC-IP>}:${NODEPORT}
   user: admin   password: ${GENERATED:-<unchanged; read it with the command below>}
   (read later: kubectl -n kubeheal-system get secret kubeheal-auth -o jsonpath='{.data.password}' | base64 -d)

 EC2 security group: add an inbound rule TCP ${NODEPORT} with Source = My IP (never 0.0.0.0/0).
 No open port needed:  ssh -L 8080:localhost:${NODEPORT} <user>@<host>   then open http://localhost:8080
 Or on the host:       ./scripts/port-forward.sh                          then open http://localhost:8080

 Each application has its own UI:  Applications > "Open app".   Press Ctrl+K for the command palette.
 Validate any time:  scripts/verify.sh     Live fault test:  scripts/smoke-test.sh
=====================================================================
MSG
fi
