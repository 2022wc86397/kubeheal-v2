# KubeHeal / KubeGuard v2.4

Kubernetes application health monitoring with **real fault detection and automatic recovery**, built only from
open-source parts and sized for a 2 vCPU AWS instance.

| Component | Tool | Why |
|---|---|---|
| Kubernetes | **k3s** | ~500 MB RAM vs ~1.5 GB for Minikube-in-Docker |
| Metrics | **Prometheus** (single pod) | CPU/memory via the kubelet's built-in cAdvisor, app metrics via pod scraping. No operator, Grafana, Alertmanager, node-exporter or kube-state-metrics |
| Control plane | **KubeHeal** (Flask + SQLite) | detector, recovery engine, REST API and dashboard in one 80 MB pod |
| Sample application | **KubeShop** (Flask): storefront, API, database service, simulated shoppers | a real three-tier e-commerce app; every tier exposes `/metrics` and token-protected fault injection |

## Architecture

```
 Browser ──► KubeHeal (kubeheal-system)  ───────────── Kubernetes API (namespace-scoped RBAC)
              │  monitor loop every 10 s                 · list/patch deployments, delete pods
              │  detect → recover → verify               · scale / rolling restart
              │  SQLite on a PVC (incidents, settings)
              ▼
         Prometheus (monitoring) ◄── kubelet cAdvisor (container CPU / memory)
              ▲                  ◄── demo pods :8080/metrics (requests, 5xx, latency)
              │
   frontend / backend / database  (kubeheal-demo, quota: 12 pods)   loadgen = steady traffic
```

## Quick start (Amazon Linux 2023, also Ubuntu / Debian / Amazon Linux 2)

```bash
unzip kubeheal-v2.2.1.zip && cd kubeheal-v2
./install.sh            # ~5-8 minutes: swap, Docker, k3s, build, deploy, then a built-in self-check
```
The installer detects the OS (`dnf` on Amazon Linux 2023, `yum` on 2, `apt` on Ubuntu/Debian), and **proves the dashboard
works before it says "Done"**: it calls the health and readiness endpoints exactly like the kubelet does (no credentials),
checks that KubeHeal sees the cluster, that a customer request really flows storefront → API → database, and that both ports answer from the host. If any step fails it prints
diagnostics (pod events, logs, probe results) automatically and saves them under `/tmp/kubeheal-diagnose-*.txt`.
Preview what it will do on your machine without changing anything: `./install.sh --dry-run`.

**The GUI is on port 8080:** open `http://<EC2-PUBLIC-IP>:8080` (user `admin`, the password is printed at the end).
The sample shop is on **port 8081**: `http://<EC2-PUBLIC-IP>:8081` (no login: it is the customer-facing site).
In the EC2 console add inbound rules **TCP 8080 and TCP 8081, Source = My IP** (never 0.0.0.0/0). Or keep the ports closed and tunnel:
`ssh -L 8080:localhost:8080 -L 8081:localhost:8081 ec2-user@<host>` then browse to `http://localhost:8080` and `http://localhost:8081`.
(`GUI_PORT=9090 STORE_PORT=9091 ./install.sh` picks other ports. k3s normally only allows NodePorts 30000-32767, so the installer
widens that range through a drop-in file, `/etc/rancher/k3s/config.yaml.d/10-kubeheal.yaml`, and restarts k3s if it was
already installed.)

**Instance sizing:** 2 vCPU with 2 GB RAM is the minimum (the installer adds 2 GB swap); 4 GB is comfortable.
A 1 vCPU / 1 GB instance (t2/t3.micro) is too small. Check which 2-vCPU types your AWS account's free plan includes.

Steady state uses roughly: k3s 500 MB, Prometheus 250 MB, KubeHeal 80 MB, 6 demo pods x ~45 MB.

**No Kubernetes handy?** `make mock` (or `./scripts/run-mock.sh`) runs the same dashboard against a built-in simulator on
http://localhost:8080. The experiments work there too.


## Project aim and how each part is implemented

> *KubeGuard is a Kubernetes-based application health monitoring and automated recovery system that categorizes application
> health based on multiple application and infrastructure metrics, detects degradation, manages incidents, performs controlled
> recovery actions, and validates recovery effectiveness through pre- and post-recovery analysis using a web dashboard.*

| Part of the aim | What KubeGuard does | Where to see it | Code |
|---|---|---|---|
| **Categorises health from multiple application and infrastructure metrics** | A 0-100 score from six signals: replica availability, CPU, memory and restarts (infrastructure), error rate and response time (application). Category = Healthy / Warning / Critical; the cut-offs are settings. Every signal shows its value, rule and the points it cost | Dashboard hero and Application Health; **Metrics > Health breakdown**; Settings | `app/health.py` |
| **Detects degradation** | Every confirmed change of category (two consecutive readings) is recorded with the reasons, before any incident threshold is reached, and can alert a webhook | **Dashboard > Health timeline**; activity feed; `GET /api/health/events` | `Monitor._track_category` |
| **Manages incidents** | Detect → classify → recover → verify lifecycle with timeline, severity and status; acknowledge, add operator notes, close a failed incident manually; summary (success rate, verified-effective rate, MTTR), swimlane timeline, CSV export, webhook alerts | **Incidents** page and each incident's page | `app/recovery.py`, `app/db.py` |
| **Performs controlled recovery actions** | Bounded actions (scale out up to a maximum, restart pods, rolling restart) with escalation; one recovery per app; cooldown; a breach never retriggers until it has cleared; observe-only mode; and an **approval mode** where KubeGuard only *proposes* the action and waits for an operator | Settings (Auto-recovery, Require approval); approval banner on the Dashboard and incident page | `Recovery._execute`, `Recovery._await_approval` |
| **Validates recovery through pre- and post-recovery analysis** | Metrics at detection vs after verification with absolute and % change per metric; headroom below the threshold; the app's normal level before the incident; a verdict (Effective / Marginal / Ineffective / Relapsed); and a **stability window** that keeps measuring after the fix and flags a relapse. A timeline chart marks detection, action and recovery | **Incident page > Recovery effectiveness** and **Pre- and post-recovery timeline** | `Recovery._finish_analysis`, `Recovery._post_watch` |
| **Web dashboard** | Seven pages, command palette, dark mode, live updates | everything | `services/kubeheal/static` |

How the verdict is decided: *Effective* = recovered with at least 10% headroom below the critical threshold; *Marginal* = recovered
but closer than 10% to the threshold; *Ineffective* = verification timed out; *Relapsed* = the problem returned inside the
stability window. Defaults: stability window 120 s, approval timeout 300 s (an unanswered request is dismissed, never auto-approved).

## The sample application: KubeShop (what KubeGuard monitors)

A small but real e-commerce site. Customers use the storefront; KubeGuard watches and heals the three tiers behind it.

```
customer ──► frontend  (storefront SPA + /api proxy)      public port 8081   deployment "frontend"
                 └──► backend  (shop API: catalogue, pricing, checkout, orders)          "backend"
                          └──► database  (SQLite on a volume: products, stock, orders)    "database"
loadgen = simulated shoppers (browse, search, price carts, buy) so every tier always has traffic
```

| Tier | Source | What it does |
|---|---|---|
| Storefront | `services/kubeshop/web` | product grid, search, categories, cart with live server-side pricing, checkout, order tracking; shows customers a clear message and retries during outages; footer shows which pod served each tier |
| Shop API | `services/kubeshop/api` | catalogue (10 s cache), quotes (shipping free over $50, 8% tax), checkout with card validation (Luhn) and a simulated payment step, order lookup; clean 503 when the database is down |
| Database service | `services/kubeshop/db` | SQLite (WAL) on a persistent volume; stock decremented in one `BEGIN IMMEDIATE` transaction so concurrent buyers can never oversell; background restock keeps long demos supplied |
| Shoppers | `services/kubeshop/loadgen` | standard-library traffic generator through the real storefront |

Each service has its **own Dockerfile** (`web/`, `api/`, `db/`, `loadgen/`; build context is `services/kubeshop`):

```bash
cd services/kubeshop
docker build -f web/Dockerfile     -t kubeheal/kubeshop-web:2.4.0 .
docker build -f api/Dockerfile     -t kubeheal/kubeshop-api:2.4.0 .
docker build -f db/Dockerfile      -t kubeheal/kubeshop-db:2.4.0 .
docker build -f loadgen/Dockerfile -t kubeheal/kubeshop-loadgen:2.4.0 .
```
`./install.sh` does this for you. To run the shop on a laptop without Docker or Kubernetes: `LOADGEN=1 ./scripts/run-shop.sh`
and open http://localhost:8081.

**Try the full story:** buy something in the storefront (test card `4242 4242 4242 4242`; `4000 0000 0000 0002` is declined),
then in KubeGuard open Experiments and inject errors into `database`. Customers see "…your card was not charged", the
storefront's footer health turns red, KubeGuard raises *High Error Rate* on the tiers that feel it and restarts what is
broken, and checkout works again.

**Fault injection is token-protected.** The storefront is reachable from the internet, so `/chaos/*` on every shop service
needs the `X-Chaos-Token` header (a random secret the installer shares between KubeGuard and the apps) and is disabled when no
token is configured. `/healthz` and `/metrics` stay open for Kubernetes and Prometheus.

Why SQLite instead of PostgreSQL? It keeps the sample at ~50 MB per pod on a 2 vCPU instance, still has real transactions
and a persistent volume, and gives KubeGuard the same HTTP metrics and fault injection as the other tiers. KubeGuard
works with any Deployment (see *Adding your own application*); a Postgres Deployment would be monitored for CPU, memory
and availability only, because it has no HTTP metrics.

## Which kinds of systems benefit most from KubeGuard?

KubeGuard's strengths are (1) stateless web/API tiers that can be restarted or scaled out safely, (2) load that spikes or
leaks, and (3) the need to *prove* recovery (every incident is verified from metrics).

| Category | Why it fits | Typical faults it handles |
|---|---|---|
| **E-commerce / retail** | flash sales and campaigns create sudden load; every minute of downtime is lost revenue | CPU overload on checkout/API pods (scale out), memory leaks in catalogue/search (rolling restart), error spikes after a bad release |
| **Payments / fintech APIs** | strict availability targets, retries amplify load | error-rate spikes, pods stuck unready, slow responses |
| **Ticketing, booking, food delivery** | extreme but short peaks (releases, meal times) | burst CPU, then scale back to baseline automatically |
| **SaaS / B2B APIs** | many small services, small ops team | memory growth, crash loops, one noisy pod |
| **Media, news and streaming front-ends** | traffic follows events | CPU overload, error bursts at the edge tier |
| **Ed-tech and exam portals** | huge synchronized peaks (exam start, results day) | CPU overload on login and exam APIs |
| **Healthcare portals and public-sector services** | must stay up, small platform teams | pod failures, error rates (stateless tiers only) |
| **IoT and telemetry ingestion** | continuous high-volume traffic | memory pressure, backlog-driven CPU spikes |
| **Gaming and social backends (API tier)** | event-driven peaks | scale-out and restart of API pods |

Less suitable: databases and other stateful systems needing careful failover, workloads that need a rollback of a bad
deployment (KubeGuard restarts or scales, it does not roll back), and multi-cluster setups (this version watches one
namespace on one cluster).

## Demo on port 8080

```bash
./scripts/demo.sh                  # dashboard on http://localhost:8080 (simulator, no Kubernetes needed)
./scripts/demo.sh --walkthrough    # same, plus a scripted run: crash, CPU, memory and error faults,
                                   # printing each detection and recovery live while you watch the browser
PORT=9090 ./scripts/demo.sh        # another port
```
On the real cluster the dashboard already listens on host port 8080 (see Quick start). Other ways in:

```bash
./scripts/port-forward.sh                    # http://localhost:8080 on the host running kubectl
ADDRESS=0.0.0.0 ./scripts/port-forward.sh   # reachable remotely; restrict the EC2 security group to your IP
ssh -L 8080:localhost:8080 ec2-user@<host>   # or tunnel from your laptop, nothing exposed
```

## Try it

Open **Experiments**, pick `backend`, and trigger a fault. Each one is a real fault, not an inserted row:

| Experiment | What happens in the pods | Detected as | Recovery action |
|---|---|---|---|
| Crash Pod | a ready pod is deleted | Pod Failure (opened immediately) | wait `self_heal_grace`, then delete unhealthy pods, then rolling restart |
| CPU Stress | busy loop in every pod, throttled at the 200m limit | CPU Overload (>= 90% for 30 s) | **scale replicas +1** (max 3); scale back to baseline after load stays low |
| Memory Stress | each pod allocates up to 93% of its 192 Mi limit | Memory Pressure (>= 90% for 30 s) | rolling restart |
| Generate Errors | pods answer 60% of requests with HTTP 500 | High Error Rate (>= 5% for 30 s) | rolling restart |

Watch **Incidents** > View: timeline (Detected, Classifying, Executing, Verifying, Completed), metrics before and live
after recovery. An incident is closed as *Recovered* only when the rollout is complete **and** the triggering metric
has stayed below its threshold for two consecutive checks. Otherwise it is *Failed*.

## Safety rules built into the engine

* One recovery per application at a time; a breach is **latched**: no new incident (and no restart loop) until the
  condition has cleared once. Cooldown (default 120 s) guards against flapping.
* Scale-out is bounded by `max_replicas` and by the namespace ResourceQuota (12 pods, 3 CPU limits).
* **Auto-recovery switch** in Settings: off = detect and record only.
* Least-privilege RBAC: KubeHeal can only touch one namespace; Prometheus reads only nodes and the demo pods.
* Optional HTTP basic auth (the installer generates a password). `/api/health` stays open for probes.
* Incidents left running when KubeHeal restarts are closed as *Failed* instead of hanging forever.

## Adding your own application

Dashboard > Applications > **Add Application** lists unmonitored Deployments in the namespace and labels them
`kubeheal.io/monitor=true`. Percentages need CPU/memory **limits** on the container. Request/error/latency metrics
need `prometheus.io/scrape: "true"` + `prometheus.io/port` on the pod template and `http_requests_total{code}` and
`http_request_duration_seconds` metrics. Without them those values show as "–" and are excluded from the health score.
To watch another namespace, change `WATCH_NAMESPACE`, the Roles, and the Prometheus `namespaces.names`.

## Settings (Settings page, stored in SQLite)

`sustain_seconds` 30, `cpu_critical` 90, `memory_critical` 90, `error_rate_critical` 5, `latency_warn_ms` 300,
`max_replicas` 3, `cooldown_seconds` 120, `verify_timeout` 120, `self_heal_grace` 15, `scale_down_idle_seconds` 120.
Environment (see `app/config.py`): `WATCH_NAMESPACE`, `PROMETHEUS_URL`, `DB_PATH`, `DETECT_INTERVAL_SECONDS`, `BRAND_NAME`,
`AUTH_USER`/`AUTH_PASSWORD`, `KUBEHEAL_MODE=cluster|mock`.

Health score = 100 minus penalties for lost replicas, CPU/memory above (threshold - 20), 5xx rate and latency.
Healthy >= 85, Warning >= 60, otherwise Critical (`app/health.py`).

## Layout

```
install.sh / uninstall.sh      one-shot lifecycle          scripts/verify.sh   pipeline diagnostics
scripts/demo.sh                dashboard on :8080 (+ 3 real demo-app processes) with optional scripted walkthrough
scripts/port-forward.sh        real-cluster dashboard on :8080
scripts/smoke-test.sh          live fault-injection acceptance test (real cluster)
tests/e2e/                     real-browser UI tests (Chromium) against the simulator
deploy/k8s/                    namespaces+quota, prometheus, the KubeShop workloads, kubeheal (RBAC, PVC, Service)
services/kubeheal/             app/ (monitor, recovery, experiments, prom, k8s, mock, db, main) static/ tests/
services/kubeshop/             the sample shop: web/ api/ db/ loadgen/ (a Dockerfile each), common/ (metrics + token-protected chaos), tests/
services/demo-app/             generic diagnostic app used by the simulator and browser tests (live gauges + chaos page)
scripts/run-shop.sh            run the sample shop locally without Docker or Kubernetes
.github/workflows/ci.yaml      tests, manifest + shell checks, image builds
```

## Troubleshooting

Start with `scripts/verify.sh`: it checks pods, Prometheus targets (with scrape errors), key queries and the API.

| Symptom | Root cause / fix |
|---|---|
| Dashboard banner "Prometheus is not answering" | `kubectl -n monitoring logs deploy/prometheus`; check the pod is Running and `verify.sh` shows targets up |
| `cadvisor` target down, 401/403 | the ClusterRole `prometheus-kubelet-read` must include `nodes/metrics` (it does by default) |
| CPU/memory show "–" | the container has no CPU/memory limit, so a percentage is undefined; set limits |
| Error rate / latency show "–" | traffic below 0.05 req/s or pod lacks the scrape annotation; check `loadgen` is running |
| Pod `ImagePullBackOff` for kubeheal images | images weren't imported into the runtime: `sudo docker save IMG | sudo k3s ctr images import -` |
| Experiment says "No pod accepted" | the app doesn't expose `/chaos/*`, or its `CHAOS_TOKEN` differs from KubeGuard's (the installer creates one shared secret `kubeheal-chaos`; if you recreated it, restart both) |
| CPU experiment never triggers | demo pods have 200m limits; check Settings thresholds and that `sustain_seconds` has elapsed |
| Pods Pending after scale-out | namespace quota (12 pods) or node memory exhausted; `kubectl describe resourcequota -n kubeheal-demo` |
| Lost incident history | the PVC `kubeheal-data` was deleted (`uninstall.sh`) |

## Security notes

The dashboard can delete pods and change replicas. Keep it behind the SG allow-list or SSH tunnel and keep basic auth on
(it sends the password in clear text over plain HTTP; put it behind TLS for anything beyond a lab). The shop's
`/chaos/*` endpoints require the shared token, but they are still test hooks: do not copy them into real workloads.

## New in 2.4

* **Health categorisation is transparent and configurable:** per-signal breakdown, restarts as a stability signal, adjustable cut-offs.
* **Degradation detection:** Healthy → Warning → Critical transitions are recorded in a health timeline and can alert the webhook.
* **Incident management:** acknowledge, operator notes, manual close, approve/reject, verdict column and CSV columns.
* **Controlled recovery:** optional approval mode (propose, then wait for an operator).
* **Pre/post-recovery analysis:** quantified before/after table, verdict, baseline, timeline chart and a post-recovery stability watch.
* Existing databases are upgraded in place (new columns are added on startup).

## New in 2.3

* **A real sample application (KubeShop)** replaces the diagnostic pages as the monitored workload: storefront, shop API and
  database service, each with its own Dockerfile, plus simulated shoppers. See *The sample application*.
* **Fault injection is now token-protected** (shared `kubeheal-chaos` secret), because the storefront is publicly reachable.
* **"Open app" is smarter:** public apps (the storefront) open on their own port; diagnostic apps open through KubeGuard.
* **Installer:** builds the four shop images, publishes the storefront on `STORE_PORT` (default 8081), creates the chaos
  token, and fails the install if a customer request cannot flow storefront → API → database.
* **Tests:** 25 shop tests (real HTTP between the tiers, concurrency/oversell, cascading failures), a 23-check browser test
  of the customer journey and outage, and a smoke test that makes a real purchase before injecting faults.

## New in 2.2

* **Demo-app UI:** every demo service now has a real web page (live CPU / memory / throughput / latency gauges, a traffic
  generator that logs which pod answered, fault-injection tiles with countdowns, pod identity). It is reachable from the
  dashboard via **Applications > Open app** at `/demo/<app>/`, through KubeGuard's own authentication. Browsers get the UI;
  API clients (the load generator, curl) still get JSON from the same URL.
* **Console redesign:** system-health hero, cluster map (one tile per pod with CPU bar and state), animated counters,
  flicker-free updates, incident swimlane timeline (auto-fits to your incidents), pause/resume for live updates.
* **Command palette (Ctrl/Cmd+K):** jump anywhere, open a demo UI, or run an experiment on any app (`cpu backend` + Enter).
  Shortcuts: `g d/a/p/i/e/m/s` to navigate, `/` or `?` for the palette.
* **Security:** cross-origin state-changing requests are rejected (a malicious page could otherwise ride your Basic-auth
  session); the demo proxy is an allow-list (fixed paths, monitored apps only), not an open proxy.
* **Fix:** a planned scale-out no longer scores as lost availability while its new pods start.

Demo pages in cluster mode pin to one pod per browser (cookie) with a pod picker; set `DEMO_URL_TEMPLATE`
(`http://{app}.{ns}.svc` or `frontend=http://h:1,backend=...`) to proxy elsewhere. The pod **Crash** tile needs
`ALLOW_CRASH=1`, set for the demo namespace only. In simulator mode the demo pages are real demo-app processes, while the
"Whole application" scope drives the simulator.

## New in 2.1

* **Dashboard:** live "auto-recovery in progress" banner, incident count badge in the sidebar and tab title, toast on every
  incident opened / recovered / failed, dark mode (follows your OS, toggle in the sidebar).
* **Charts:** hover tooltips, dashed critical-threshold lines, clickable incident markers on the timeline.
* **Incidents:** success rate and mean-time-to-recovery strip, CSV export, live elapsed timer on active incidents.
* **Experiments:** running-fault chips with per-app Stop. **Pods:** CPU/memory usage bars. **Settings:** reset to defaults.
* **Alerts:** optional Slack/Mattermost/Discord-compatible webhook: `NOTIFY_WEBHOOK_URL=https://... ./install.sh`
  (stored in the `kubeheal-notify` secret).
* **Ops:** `/api/ready` readiness probe, incident retention (last 1000), `scripts/smoke-test.sh` live acceptance test.

## What changed from the previous scripts

* Phase scripts that wrote code via heredocs became a proper project with tests and CI.
* "CPU / memory / restart detection tests" used to insert fake incident rows. Experiments now inject real faults and
  recovery is detected from metrics and verified from metrics.
* Demo apps were plain nginx (no way to create CPU, memory or error load, no request metrics); now they are instrumented.
* kube-prometheus-stack (~1.5 GB) replaced by a single lean Prometheus; Minikube replaced by k3s.
* Recovery actions are real and bounded: scale-out, pod restart, rolling restart, scale-down, with escalation and verification.
* Added: health score, ResourceQuota, least-privilege RBAC, auth, `Recreate` strategy for the SQLite volume, restart-loop latch,
  non-root containers, swap setup, and the full dashboard (Applications, Pods, Incident detail, Metrics, Settings, Add Application).

## Testing

| Layer | Command | What it covers |
|---|---|---|
| Unit + flow | `make test` | 110 + 12 + 25 tests (KubeHeal + diagnostic app + KubeShop): health scoring, SQLite store, notifier, API incl. auth/CSV/summary, the Kubernetes and Prometheus backends against fakes, and end-to-end detect > recover > verify flows against the simulator |
| Browser | `make e2e` | 67 checks in headless Chromium: hero + cluster map, command palette, shortcuts, pause, live banner, approval flow, pre/post-recovery analysis, health breakdown and timeline, notes and acknowledgement, swimlane, tooltips, incident markers, CSV, the demo-app UI through the proxy (traffic, faults, scopes), dark mode, no horizontal overflow on phones, zero JS errors. Set `CHROME_PATH` to use your own Chrome, otherwise it uses the `@sparticuz/chromium` package |
| Shop browser | `tests/e2e/run-shop-e2e.sh` | 23 checks of a real customer journey (browse, search, cart, checkout, declined and invalid cards, order tracking), then a database outage as the customer sees it and the recovery, and phone layout |
| Live cluster | `scripts/verify.sh` then `scripts/smoke-test.sh` | pipeline diagnostics, then real pod-crash and CPU-stress recoveries on your k3s |

The k3s/AWS install path itself needs a real host (it was not run in the authoring environment): run `./install.sh`, then
`scripts/verify.sh` and `scripts/smoke-test.sh`.
