"""The project aim, clause by clause: categorise health, detect degradation, manage incidents, controlled recovery,
validate recovery through pre/post analysis."""
import sqlite3
import time

import pytest

from app.config import Config
from app.db import DEFAULT_SETTINGS, Store
from app.health import assess, score_app
from app.main import create_app
from app.mock import MockWorld
from app.recovery import Recovery

ST = dict(DEFAULT_SETTINGS)


def finished(rt, typ, timeout=40):
    assert rt.wait(lambda: (rt.incident_for(typ) or {}).get("status") in ("RECOVERED", "FAILED", "DISMISSED"), timeout), rt.store.list_incidents()
    return rt.incident_for(typ)


def pending(rt, typ, timeout=20):
    assert rt.wait(lambda: (rt.incident_for(typ) or {}).get("status") == "PENDING_APPROVAL", timeout), rt.store.list_incidents()
    return rt.incident_for(typ)


def all_pods_chaos(rt, app, kind, seconds=60):
    for p in rt.world.list_pods(app):
        rt.world.apply_chaos(p, kind, {"seconds": seconds})


# ================================================= 1. categorise health from several metrics
def test_each_signal_explains_its_own_contribution():
    m = {"cpu_pct": 78, "mem_pct": 40, "err_pct": 2.3, "resp_ms": 450}
    a = assess(3, 3, m, ST, restarts=2)
    sig = {s["key"]: s for s in a["signals"]}
    assert set(sig) == {"availability", "cpu", "memory", "errors", "latency", "restarts"}
    assert {s["kind"] for s in a["signals"]} == {"infrastructure", "application"}
    assert sig["cpu"]["state"] == "warn" and sig["cpu"]["penalty"] > 0 and "critical ≥ 90%" in sig["cpu"]["rule"]
    assert sig["memory"]["state"] == "ok" and sig["memory"]["penalty"] == 0
    assert sig["errors"]["state"] == "warn" and sig["latency"]["state"] == "warn" and sig["restarts"]["penalty"] == 10
    assert a["score"] == round(100 - sum(s["penalty"] for s in a["signals"]))        # the breakdown IS the score
    assert a["status"] == "warning" and a["reasons"]


def test_unmeasurable_signals_are_unknown_not_penalised():
    a = assess(2, 2, {}, ST)
    assert a["score"] == 100 and {s["key"]: s["state"] for s in a["signals"]}["cpu"] == "unknown"


def test_category_cutoffs_are_configurable():
    m = {"cpu_pct": 82}                                   # 5 points of CPU penalty -> score 94
    assert score_app(2, 2, m, ST)[1] == "healthy"
    assert score_app(2, 2, m, {**ST, "healthy_min": 97})[1] == "warning"
    assert score_app(2, 2, m, {**ST, "healthy_min": 97, "warning_min": 95})[1] == "critical"


def test_restarts_count_as_a_stability_signal():
    assert assess(2, 2, {}, ST, restarts=0)["score"] == 100
    assert assess(2, 2, {}, ST, restarts=1)["score"] == 95
    a = assess(2, 2, {}, ST, restarts=9)
    assert a["score"] == 85 and {s["key"]: s["state"] for s in a["signals"]}["restarts"] == "crit"      # capped at 15 points


def test_settings_keep_the_three_categories_ordered(tmp_path):
    s = Store(str(tmp_path / "s.db"))
    out = s.save_settings({"healthy_min": 70, "warning_min": 90})
    assert out["warning_min"] < out["healthy_min"]
    assert s.save_settings({"approval_required": "yes"})["approval_required"] == 1.0


# ================================================= 2. detect degradation (before any incident threshold is reached)
def test_degradation_is_detected_and_recorded_before_it_becomes_an_incident(rt):
    rt.store.save_settings({"cpu_critical": 100, "sustain_seconds": 3600})        # 97% CPU hurts the score but breaches no incident threshold
    rt.monitor.tick(); rt.monitor.tick()
    assert rt.monitor.app_state("backend")["status"] == "healthy"
    all_pods_chaos(rt, "backend", "cpu")
    for _ in range(4):
        rt.monitor.tick()
    st = rt.monitor.app_state("backend")
    assert st["status"] == "warning" and rt.store.list_incidents() == []          # degraded, but nothing was "incident-worthy"
    ev = rt.store.list_health(app="backend")
    assert ev[0]["kind"] == "degraded" and (ev[0]["from_status"], ev[0]["to_status"]) == ("healthy", "warning")
    assert any("CPU" in r for r in ev[0]["reasons"])
    assert any("Degradation detected: backend Healthy → Warning" in e["message"] for e in rt.store.list_events(20))
    all_pods_chaos(rt, "backend", "stop")
    for p in rt.world.list_pods("backend"):
        rt.world.apply_chaos(p, "stop", {})
    for _ in range(4):
        rt.monitor.tick()
    assert rt.store.list_health(app="backend")[0]["kind"] == "improved"


def test_a_single_noisy_reading_is_not_a_transition(rt):
    rt.store.save_settings({"cpu_critical": 100, "sustain_seconds": 3600})
    rt.monitor.tick(); rt.monitor.tick()
    all_pods_chaos(rt, "backend", "cpu", seconds=1)
    rt.monitor.tick()                                                              # one bad reading...
    time.sleep(1.2)
    rt.monitor.tick(); rt.monitor.tick()                                           # ...then normal again
    assert rt.store.list_health(app="backend") == []


def test_degradation_alert_reaches_the_webhook(rt):
    from app.notify import Notifier

    class H:
        calls = []

        def post(self, url, json, timeout):
            H.calls.append(json["text"])
    rt.monitor.notifier = Notifier("http://hook", session=H())
    rt.store.save_settings({"cpu_critical": 100, "sustain_seconds": 3600})
    rt.monitor.tick(); rt.monitor.tick()
    all_pods_chaos(rt, "backend", "cpu")
    for _ in range(4):
        rt.monitor.tick()
    time.sleep(0.3)
    assert any("Degradation detected: backend" in t for t in H.calls)


# ================================================= 3. controlled recovery: operator approval
def test_with_approval_required_nothing_happens_until_an_operator_approves(rt):
    rt.store.save_settings({"approval_required": 1, "approval_timeout": 60})
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    inc = pending(rt, "CPU_OVERLOAD")
    time.sleep(1.0)
    assert rt.world.get_app("backend").desired == 2                                # proposed, not executed
    assert rt.store.get_incident(inc["id"])["steps"][2]["detail"].startswith("Awaiting operator approval")
    assert rt.store.counts()["pending_approval"] == 1 and rt.recovery.is_busy("backend")
    assert rt.recovery.approve(inc["id"], "alice") is True
    done = finished(rt, "CPU_OVERLOAD")
    assert done["status"] == "RECOVERED" and rt.world.get_app("backend").desired == 3
    assert done["decision"]["decision"] == "approved" and done["decision"]["by"] == "alice"
    assert rt.recovery.approve(inc["id"], "alice") is False                        # a decision can only be made once


def test_rejecting_dismisses_the_incident_without_touching_the_cluster(rt):
    rt.store.save_settings({"approval_required": 1, "approval_timeout": 60})
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    inc = pending(rt, "CPU_OVERLOAD")
    assert rt.recovery.reject(inc["id"], "bob")
    done = finished(rt, "CPU_OVERLOAD")
    assert done["status"] == "DISMISSED" and done["action"] == "None (not approved)" and done["decision"]["decision"] == "rejected"
    assert rt.world.get_app("backend").desired == 2
    for _ in range(6):                                                             # and KubeGuard does not nag with a second incident
        rt.monitor.tick()
    assert len(rt.store.list_incidents()) == 1 and not rt.recovery.is_busy("backend")


def test_unanswered_approval_expires_safely(rt):
    orig = rt.store.get_settings
    rt.store.get_settings = lambda: {**orig(), "approval_required": 1, "approval_timeout": 1.0}
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    done = finished(rt, "CPU_OVERLOAD", timeout=30)
    assert done["status"] == "DISMISSED" and done["decision"]["decision"] == "timeout" and rt.world.get_app("backend").desired == 2


def test_approval_does_not_apply_when_auto_recovery_is_off(rt):
    rt.store.save_settings({"approval_required": 1, "auto_recovery": 0, "verify_timeout": 10})
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    done = finished(rt, "CPU_OVERLOAD", timeout=30)
    assert done["status"] == "FAILED" and done["action"] == "Observe only"           # observe-only never asks to act


# ================================================= 4. validate recovery: pre/post analysis
def test_recovery_is_analysed_before_versus_after(rt):
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    inc = finished(rt, "CPU_OVERLOAD")
    a = inc["analysis"]
    assert inc["status"] == "RECOVERED" and a["verdict"] == "effective"
    t = a["trigger"]
    assert t["before"] >= 90 and t["after"] < 90 and t["headroom_pct"] >= 10 and t["threshold"] == 90
    rows = {r["key"]: r for r in a["metrics"]}
    assert rows["cpu_pct"]["change"] == "improved" and rows["cpu_pct"]["delta"] < 0 and rows["cpu_pct"]["change_pct"] < -5
    assert rows["availability"]["before"] == 100 and rows["availability"]["after"] == 100
    assert "CPU went from" in a["summary"] and "below the 90% critical threshold" in a["summary"] and "Scale Replicas" in a["summary"]
    assert a["post_watch"]["state"] == "off"                                         # stability_window is 0 in this fixture


def test_pod_failure_is_validated_by_availability(rt):
    rt.monitor.tick(); rt.experiments.run("crash", "frontend")
    a = finished(rt, "POD_FAILURE")["analysis"]
    assert a["verdict"] == "effective" and a["trigger"] is None and "replicas are ready again" in a["summary"]


def test_a_recovery_that_holds_for_the_stability_window_is_confirmed_stable(rt):
    rt.store.save_settings({"stability_window": 3})
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    inc = finished(rt, "CPU_OVERLOAD")
    assert inc["analysis"]["post_watch"]["state"] == "observing"
    assert rt.wait(lambda: rt.store.get_incident(inc["id"])["analysis"]["post_watch"]["state"] == "stable", 15)
    pw = rt.store.get_incident(inc["id"])["analysis"]["post_watch"]
    assert pw["readings"] >= 2 and 40 < pw["avg"] < 90 and pw["max"] < 90 and pw["elapsed"] >= 2
    assert rt.store.get_incident(inc["id"])["analysis"]["verdict"] == "effective"
    assert any("held for" in e["message"] for e in rt.store.list_events(20))


def test_a_relapse_inside_the_window_is_caught_and_downgrades_the_verdict(rt):
    rt.store.save_settings({"stability_window": 8})
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    inc = finished(rt, "CPU_OVERLOAD")
    assert inc["status"] == "RECOVERED"
    all_pods_chaos(rt, "backend", "cpu", 60)                                         # the load returns on every pod, including the new one
    assert rt.wait(lambda: rt.store.get_incident(inc["id"])["analysis"]["post_watch"]["state"] == "relapsed", 20)
    a = rt.store.get_incident(inc["id"])["analysis"]
    assert a["verdict"] == "relapsed" and "did not hold" in a["summary"] and a["post_watch"]["relapsed_at"]
    assert any("relapsed" in e["message"] for e in rt.store.list_events(20))


def test_a_failed_recovery_is_analysed_as_ineffective(rt):
    rt.store.save_settings({"auto_recovery": 0, "verify_timeout": 10})
    rt.monitor.tick(); rt.experiments.run("cpu", "backend", 60)
    inc = finished(rt, "CPU_OVERLOAD", timeout=30)
    a = inc["analysis"]
    assert inc["status"] == "FAILED" and a["verdict"] == "ineffective" and a["post_watch"]["state"] == "skipped"
    assert "Not recovered after 10s" in a["summary"]


def test_memory_and_error_recoveries_are_analysed_against_their_own_thresholds(rt):
    rt.monitor.tick(); rt.experiments.run("memory", "database", 60)
    m = finished(rt, "MEMORY_PRESSURE")["analysis"]
    assert m["trigger"]["key"] == "mem_pct" and m["trigger"]["before"] >= 90 and m["verdict"] == "effective"
    rt.monitor.tick(); rt.experiments.run("errors", "frontend", 60)
    e = finished(rt, "HIGH_ERROR_RATE")["analysis"]
    assert e["trigger"]["key"] == "err_pct" and e["trigger"]["threshold"] == 5 and e["verdict"] == "effective"


def test_the_normal_level_before_the_incident_is_reported_as_a_baseline(tmp_path):
    world = MockWorld(startup=0.2, seed=3, seed_history=True)
    rec = Recovery(world, world, Store(str(tmp_path / "b.db")), poll=0.1)
    base = rec._baseline("backend", "cpu", time.time())
    assert 15 < base < 40                                                            # the seeded "normal" CPU of ~28%
    assert rec._baseline("backend", "cpu", time.time() - 7 * 3600) is None            # beyond metric retention: no guess


# ================================================= 5. manage incidents (API)
@pytest.fixture
def client(rt):
    rt.monitor.tick()
    return create_app(Config(), runtime=rt, start_threads=False).test_client(), rt


def test_acknowledge_annotate_and_close_incidents(client):
    c, rt = client
    rt.store.save_settings({"auto_recovery": 0, "verify_timeout": 10})
    iid = c.post("/api/experiments/cpu", json={"application": "backend", "seconds": 60}).status_code == 200 and None
    inc = finished(rt, "CPU_OVERLOAD", timeout=30)
    iid = inc["id"]
    assert inc["status"] == "FAILED" and inc["acknowledged_at"] is None
    r = c.post(f"/api/incidents/{iid}/ack").json
    assert r["incident"]["acknowledged_by"] == "operator" and r["incident"]["acknowledged_at"]
    first = c.post(f"/api/incidents/{iid}/ack").json["incident"]["acknowledged_at"]
    assert first == r["incident"]["acknowledged_at"]                                 # acknowledging twice keeps the first time
    assert c.post(f"/api/incidents/{iid}/notes", json={"text": ""}).status_code == 400
    assert c.post(f"/api/incidents/{iid}/notes", json={"text": "x" * 501}).status_code == 400
    n = c.post(f"/api/incidents/{iid}/notes", json={"text": "Scaled the node group by hand"}).json["notes"]
    assert n[0]["text"] == "Scaled the node group by hand" and n[0]["author"] == "operator"
    out = c.post(f"/api/incidents/{iid}/resolve", json={"resolution": "load dropped after the campaign"}).json["incident"]
    assert out["status"] == "RESOLVED" and out["decision"]["decision"] == "manual" and out["notes"][-1]["text"].startswith("Resolved manually")
    assert c.post(f"/api/incidents/{iid}/resolve").status_code == 409                # already closed
    s = c.get("/api/summary").json
    assert s["resolved_manually"] == 1 and s["verdicts"]["ineffective"] == 1


def test_only_failed_incidents_can_be_closed_manually_and_unknown_ids_are_404(client):
    c, rt = client
    c.post("/api/experiments/crash", json={"application": "frontend"})
    inc = finished(rt, "POD_FAILURE")
    assert inc["status"] == "RECOVERED"
    assert c.post(f"/api/incidents/{inc['id']}/resolve").status_code == 409
    for path in ("ack", "notes", "resolve", "approve", "reject", "analysis"):
        method = c.get if path == "analysis" else c.post
        assert method(f"/api/incidents/9999/{path}").status_code == 404, path
    assert c.post(f"/api/incidents/{inc['id']}/approve").status_code == 409          # not waiting for approval


def test_approval_over_the_api(client):
    c, rt = client
    c.post("/api/settings", json={"approval_required": 1, "approval_timeout": 60})
    c.post("/api/experiments/crash", json={"application": "frontend"})
    inc = pending(rt, "POD_FAILURE")
    d = c.get(f"/api/incidents/{inc['id']}").json
    assert d["status"] == "PENDING_APPROVAL" and d["proposed_action"].startswith("Self-heal")
    assert c.get("/api/overview").json["counts"]["pending_approval"] == 1
    assert c.get("/api/incidents?status=active").json["incidents"][0]["id"] == inc["id"]       # "active" includes pending
    assert c.post(f"/api/incidents/{inc['id']}/approve").json["ok"]
    assert finished(rt, "POD_FAILURE")["status"] == "RECOVERED"


def test_analysis_endpoint_gives_a_timeline_with_markers(client):
    c, rt = client
    c.post("/api/experiments/cpu", json={"application": "backend", "seconds": 60})
    inc = finished(rt, "CPU_OVERLOAD")
    d = c.get(f"/api/incidents/{inc['id']}/analysis").json
    assert set(d["series"]) == {"cpu", "memory", "response", "errors"} and d["thresholds"]["cpu"] == 90
    assert [m["kind"] for m in d["markers"]] == ["detected", "action", "recovered"]
    assert d["markers"][1]["label"] == "Scale Replicas" and d["analysis"]["verdict"] == "effective"


def test_health_history_and_summary_endpoints(client):
    c, rt = client
    rt.store.log_health("backend", "healthy", "warning", 78, ["CPU at 97%"], "degraded")
    ev = c.get("/api/health/events?limit=5&app=backend").json["events"]
    assert ev[0]["to_status"] == "warning" and ev[0]["reasons"] == ["CPU at 97%"]
    assert c.get("/api/overview").json["health_events"][0]["application"] == "backend"
    c.post("/api/experiments/crash", json={"application": "frontend"})
    finished(rt, "POD_FAILURE")
    s = c.get("/api/summary").json
    assert s["verdicts"] == {"effective": 1} and s["effectiveness_rate"] == 100.0


def test_apps_expose_their_signal_breakdown_to_the_dashboard(client):
    c, rt = client
    app = next(a for a in c.get("/api/overview").json["apps"] if a["name"] == "backend")
    assert [s["key"] for s in app["signals"]] == ["availability", "cpu", "memory", "errors", "latency", "restarts"]
    assert app["status"] in ("healthy", "warning", "critical") and "restarts_recent" in app


# ================================================= database migration for installs that predate these features
def test_an_old_database_is_upgraded_in_place(tmp_path):
    path = str(tmp_path / "old.db")
    c = sqlite3.connect(path)
    c.executescript("""CREATE TABLE incidents(id INTEGER PRIMARY KEY AUTOINCREMENT, application TEXT NOT NULL, type TEXT NOT NULL,
      severity TEXT NOT NULL, status TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'auto', description TEXT, action TEXT,
      detected_at REAL NOT NULL, resolved_at REAL, recovery_seconds REAL, before_json TEXT, after_json TEXT, steps_json TEXT);
      INSERT INTO incidents(application,type,severity,status,detected_at,before_json) VALUES('backend','CPU_OVERLOAD','High','RECOVERED',1.0,'{"cpu_pct": 95}');
      CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL); INSERT INTO settings VALUES('cpu_critical','80');""")
    c.commit(); c.close()
    s = Store(path)
    inc = s.get_incident(1)
    assert inc["before"] == {"cpu_pct": 95} and inc["notes"] == [] and inc["analysis"] is None and inc["acknowledged_at"] is None
    s.add_note(1, "me", "hello"); s.acknowledge(1, "me")
    assert s.get_incident(1)["notes"][0]["text"] == "hello" and s.get_incident(1)["acknowledged_by"] == "me"
    cfg = s.get_settings()
    assert cfg["cpu_critical"] == 80 and cfg["healthy_min"] == 85 and cfg["stability_window"] == 120     # old values kept, new defaults added
    Store(path)                                                                       # opening twice must be harmless


@pytest.mark.parametrize("after_cpu,verdict", [(70.0, "effective"), (81.0, "effective"), (82.0, "marginal"), (89.5, "marginal")])
def test_verdict_depends_on_how_far_below_the_threshold_the_recovery_lands(rt, after_cpu, verdict):
    """Headroom = (threshold - after) / threshold. 10% headroom (81% of a 90% limit) is the effective/marginal boundary."""
    iid = rt.store.create_incident("backend", "CPU_OVERLOAD", "High", "d", {"cpu_pct": 96.0, "ready": 2, "desired": 2})
    rt.store.update_incident(iid, status="RECOVERED", after={"cpu_pct": after_cpu, "ready": 2, "desired": 2}, resolved_at=time.time())
    rt.recovery._finish_analysis(iid, "backend", "CPU_OVERLOAD", rt.store.get_settings(), True, "Scale Replicas", 5.0)
    a = rt.store.get_incident(iid)["analysis"]
    assert a["verdict"] == verdict
    assert ("Headroom is thin" in a["summary"]) == (verdict == "marginal")


def test_unchanged_metrics_are_reported_as_unchanged_not_improved(rt):
    iid = rt.store.create_incident("backend", "CPU_OVERLOAD", "High", "d", {"cpu_pct": 95.0, "mem_pct": 40.0, "ready": 2, "desired": 2})
    rt.store.update_incident(iid, after={"cpu_pct": 60.0, "mem_pct": 41.0, "ready": 2, "desired": 2}, resolved_at=time.time())
    rt.recovery._finish_analysis(iid, "backend", "CPU_OVERLOAD", rt.store.get_settings(), True, "x", 1.0)
    rows = {r["key"]: r for r in rt.store.get_incident(iid)["analysis"]["metrics"]}
    assert rows["cpu_pct"]["change"] == "improved" and rows["mem_pct"]["change"] == "unchanged" and rows["resp_ms"]["change"] == "n/a"


def test_noise_level_changes_are_not_reported_as_worse(rt):
    """0.1% -> 0.2% errors is +100% in relative terms but not a real change: it must read as 'unchanged', not 'worsened'."""
    iid = rt.store.create_incident("backend", "CPU_OVERLOAD", "High", "d", {"cpu_pct": 95.0, "err_pct": 0.1, "resp_ms": 410.0, "ready": 2, "desired": 2})
    rt.store.update_incident(iid, after={"cpu_pct": 60.0, "err_pct": 0.2, "resp_ms": 405.0, "ready": 2, "desired": 2}, resolved_at=time.time())
    rt.recovery._finish_analysis(iid, "backend", "CPU_OVERLOAD", rt.store.get_settings(), True, "x", 1.0)
    rows = {r["key"]: r for r in rt.store.get_incident(iid)["analysis"]["metrics"]}
    assert rows["err_pct"]["change"] == "unchanged" and rows["resp_ms"]["change"] == "unchanged" and rows["cpu_pct"]["change"] == "improved"
    iid2 = rt.store.create_incident("backend", "CPU_OVERLOAD", "High", "d", {"cpu_pct": 95.0, "err_pct": 0.1, "ready": 2, "desired": 2})
    rt.store.update_incident(iid2, after={"cpu_pct": 60.0, "err_pct": 6.0, "ready": 2, "desired": 2}, resolved_at=time.time())
    rt.recovery._finish_analysis(iid2, "backend", "CPU_OVERLOAD", rt.store.get_settings(), True, "x", 1.0)
    assert {r["key"]: r for r in rt.store.get_incident(iid2)["analysis"]["metrics"]}["err_pct"]["change"] == "worsened"   # a real regression still shows


def test_jitter_on_a_healthy_metric_is_not_called_worse(rt):
    """Memory 29.7% -> 31.5% is +6% in relative terms but only 1.8 points: not a finding."""
    iid = rt.store.create_incident("backend", "CPU_OVERLOAD", "High", "d", {"cpu_pct": 97.0, "mem_pct": 29.7, "ready": 2, "desired": 2})
    rt.store.update_incident(iid, after={"cpu_pct": 73.7, "mem_pct": 31.5, "ready": 2, "desired": 2}, resolved_at=time.time())
    rt.recovery._finish_analysis(iid, "backend", "CPU_OVERLOAD", rt.store.get_settings(), True, "x", 1.0)
    rows = {r["key"]: r for r in rt.store.get_incident(iid)["analysis"]["metrics"]}
    assert rows["mem_pct"]["change"] == "unchanged" and rows["cpu_pct"]["change"] == "improved"
