"""Health categorisation: Healthy / Warning / Critical from several application and infrastructure signals.

Every signal explains its own contribution, so the dashboard can show *why* an application has its category and an
operator can verify the rules instead of trusting a single number.

  Infrastructure signals: replica availability, CPU, memory, restarts (stability)
  Application signals:    5xx error rate, response time

The score starts at 100; each signal subtracts a bounded penalty. Missing metrics (None) never penalise an app: we only
score what we can actually measure. Category cut-offs are settings (healthy_min, warning_min).
"""

RESTART_WINDOW_SECONDS = 600


def _signal(key, label, kind, value, display, penalty, state, rule):
    return {"key": key, "label": label, "kind": kind, "value": value, "display": display,
            "penalty": round(penalty, 1), "state": state, "rule": rule}


def assess(desired, ready, m, st, restarts=0):
    """Return {"score", "status", "reasons", "signals"}."""
    if desired <= 0:
        return {"score": 0, "status": "stopped", "reasons": ["Scaled to zero replicas"], "signals": []}

    sig, reasons = [], []

    # --- infrastructure: replica availability
    avail = ready / desired
    pen = (1 - avail) * 100
    state = "ok" if avail >= 1 else "warn" if avail > 0.5 else "crit"
    if avail < 1:
        reasons.append(f"{ready}/{desired} replicas ready")
    sig.append(_signal("availability", "Replica availability", "infrastructure", avail * 100, f"{ready}/{desired} ready",
                       pen, state, "every desired replica must be ready (the lost share counts 1:1)"))

    # --- infrastructure: CPU and memory (percent of the container limit)
    for key, label, mkey, ckey, cap in (("cpu", "CPU", "cpu_pct", "cpu_critical", 25),
                                        ("memory", "Memory", "mem_pct", "memory_critical", 20)):
        crit = st[ckey]
        warn = crit - 20
        v = m.get(mkey)
        if v is None:
            sig.append(_signal(key, label, "infrastructure", None, "n/a", 0, "unknown",
                               f"needs a container limit; warn > {warn:.0f}% · critical ≥ {crit:.0f}%"))
            continue
        pen = min(cap, (v - warn) / 20 * cap) if v > warn else 0
        if pen:
            reasons.append(f"{label} at {v:.0f}%")
        sig.append(_signal(key, label, "infrastructure", v, f"{v:.0f}%", pen,
                           "crit" if v >= crit else "warn" if v > warn else "ok",
                           f"of the container limit: warn > {warn:.0f}% · critical ≥ {crit:.0f}%"))

    # --- application: 5xx error rate
    err = m.get("err_pct")
    if err is None:
        sig.append(_signal("errors", "Error rate", "application", None, "n/a", 0, "unknown",
                           "needs request metrics from the application"))
    else:
        pen = min(30, err * 3) if err > 0.5 else 0
        if pen:
            reasons.append(f"{err:.1f}% errors")
        sig.append(_signal("errors", "Error rate", "application", err, f"{err:.1f}%", pen,
                           "crit" if err >= st["error_rate_critical"] else "warn" if err >= 1 else "ok",
                           f"HTTP 5xx share: warn ≥ 1% · critical ≥ {st['error_rate_critical']:.0f}%"))

    # --- application: response time
    resp, lat = m.get("resp_ms"), st["latency_warn_ms"]
    if resp is None:
        sig.append(_signal("latency", "Response time", "application", None, "n/a", 0, "unknown",
                           "needs request metrics from the application"))
    else:
        pen = min(15, (resp - lat) / lat * 15) if resp > lat else 0
        if pen:
            reasons.append(f"Response time {resp:.0f} ms")
        sig.append(_signal("latency", "Response time", "application", resp, f"{resp:.0f} ms", pen,
                           "crit" if resp >= 2 * lat else "warn" if resp > lat else "ok",
                           f"average: warn > {lat:.0f} ms · critical ≥ {2 * lat:.0f} ms"))

    # --- infrastructure: stability (container restarts in the last 10 minutes)
    pen = min(15, 5 * restarts)
    if restarts:
        reasons.append(f"{restarts} restart(s) in 10 min")
    sig.append(_signal("restarts", "Restarts (10 min)", "infrastructure", restarts, str(restarts), pen,
                       "crit" if restarts >= 3 else "warn" if restarts >= 1 else "ok",
                       "warn ≥ 1 · critical ≥ 3 container restarts"))

    score = int(round(max(0, min(100, 100 - sum(s["penalty"] for s in sig)))))
    healthy_min, warning_min = st.get("healthy_min", 85), st.get("warning_min", 60)
    status = "healthy" if score >= healthy_min else "warning" if score >= warning_min else "critical"
    return {"score": score, "status": status, "reasons": reasons, "signals": sig}


def score_app(desired, ready, m, st, restarts=0):
    """Backwards-compatible tuple form: (score, status, reasons)."""
    a = assess(desired, ready, m, st, restarts)
    return a["score"], a["status"], a["reasons"]
