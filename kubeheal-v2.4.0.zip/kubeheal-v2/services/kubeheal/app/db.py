"""SQLite persistence for incidents, settings and the activity log."""
import json
import os
import sqlite3
import time
from contextlib import closing

DEFAULT_SETTINGS = {
    "auto_recovery": 1,            # 1 = act, 0 = observe only
    "cpu_critical": 90.0,          # % of CPU limit
    "memory_critical": 90.0,       # % of memory limit
    "error_rate_critical": 5.0,    # % of requests returning 5xx
    "latency_warn_ms": 300.0,      # only affects the health score
    "sustain_seconds": 30.0,       # breach must last this long before an incident is raised
    "cooldown_seconds": 120.0,     # minimum gap between incidents of the same type
    "max_replicas": 3.0,           # upper bound for automatic scale-out
    "verify_timeout": 120.0,       # give up verifying recovery after this long
    "self_heal_grace": 15.0,       # let Kubernetes replace a failed pod before KubeHeal acts
    "scale_down_idle_seconds": 120.0,
    "healthy_min": 85.0,           # health score at or above this = Healthy
    "warning_min": 60.0,           # at or above this = Warning, below = Critical
    "approval_required": 0,        # 1 = an operator must approve each automatic recovery action
    "approval_timeout": 300.0,     # an unanswered approval request is dismissed after this long
    "stability_window": 120.0,     # after a recovery, keep watching this long to detect a relapse (0 = off)
}

SETTING_LIMITS = {
    "cpu_critical": (10, 100), "memory_critical": (10, 100), "error_rate_critical": (0.5, 100),
    "latency_warn_ms": (10, 10000), "sustain_seconds": (0, 3600), "cooldown_seconds": (0, 86400),
    "max_replicas": (1, 10), "verify_timeout": (10, 1800), "self_heal_grace": (0, 300),
    "scale_down_idle_seconds": (10, 86400), "healthy_min": (50, 100), "warning_min": (10, 95),
    "approval_timeout": (10, 3600), "stability_window": (0, 1800),
}
BOOL_SETTINGS = ("auto_recovery", "approval_required")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  application TEXT NOT NULL, type TEXT NOT NULL, severity TEXT NOT NULL,
  status TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'auto',
  description TEXT, action TEXT,
  detected_at REAL NOT NULL, resolved_at REAL, recovery_seconds REAL,
  before_json TEXT, after_json TEXT, steps_json TEXT);
CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS health_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, application TEXT NOT NULL,
  from_status TEXT, to_status TEXT NOT NULL, score INTEGER, reasons_json TEXT, kind TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL,
  application TEXT, level TEXT NOT NULL, message TEXT NOT NULL);
"""

MAX_INCIDENTS = 1000
_JSON_COLS = {"before_json": "before", "after_json": "after", "steps_json": "steps", "analysis_json": "analysis",
              "notes_json": "notes", "decision_json": "decision"}
# columns added after the first release: older databases are upgraded in place
_MIGRATIONS = {"analysis_json": "TEXT", "notes_json": "TEXT", "decision_json": "TEXT",
               "acknowledged_at": "REAL", "acknowledged_by": "TEXT"}
ACTIVE_STATES = ("ACTIVE", "PENDING_APPROVAL")


class Store:
    def __init__(self, path):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with closing(self._conn()) as c, c:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript(_SCHEMA)
            have = {r["name"] for r in c.execute("PRAGMA table_info(incidents)")}
            for col, typ in _MIGRATIONS.items():
                if col not in have:
                    c.execute(f"ALTER TABLE incidents ADD COLUMN {col} {typ}")
            for k, v in DEFAULT_SETTINGS.items():
                c.execute("INSERT OR IGNORE INTO settings VALUES(?,?)", (k, str(v)))

    def _conn(self):
        c = sqlite3.connect(self.path, timeout=15)
        c.row_factory = sqlite3.Row
        return c

    # ---- settings -------------------------------------------------------
    def get_settings(self):
        with closing(self._conn()) as c:
            raw = {r["key"]: r["value"] for r in c.execute("SELECT key,value FROM settings")}
        out = dict(DEFAULT_SETTINGS)
        for k in DEFAULT_SETTINGS:
            if k in raw:
                try:
                    out[k] = float(raw[k])
                except ValueError:
                    pass
        return out

    def save_settings(self, data):
        with closing(self._conn()) as c, c:
            for k, v in (data or {}).items():
                if k not in DEFAULT_SETTINGS:
                    continue
                if k in BOOL_SETTINGS:
                    on = str(v).strip().lower() in ("1", "true", "yes", "on") or (not isinstance(v, str) and bool(v))
                    v = 1.0 if on else 0.0
                else:
                    lo, hi = SETTING_LIMITS[k]
                    v = min(max(float(v), lo), hi)
                c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, str(v)))
        cur = self.get_settings()
        if cur["warning_min"] >= cur["healthy_min"]:               # keep the three categories ordered
            with closing(self._conn()) as c, c:
                c.execute("INSERT OR REPLACE INTO settings VALUES('warning_min',?)", (str(cur["healthy_min"] - 1),))
            cur = self.get_settings()
        return cur

    # ---- incidents ------------------------------------------------------
    @staticmethod
    def _row(r):
        d = dict(r)
        for col, name in _JSON_COLS.items():
            raw = d.pop(col, None)
            d[name] = json.loads(raw) if raw else ([] if name in ("steps", "notes") else None)
        return d

    def create_incident(self, application, typ, severity, description, before, source="auto",
                        action=None, steps=None):
        with closing(self._conn()) as c, c:
            cur = c.execute(
                "INSERT INTO incidents(application,type,severity,status,source,description,action,"
                "detected_at,before_json,steps_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (application, typ, severity, "ACTIVE", source, description, action, time.time(),
                 json.dumps(before), json.dumps(steps or [])))
            iid = cur.lastrowid
            c.execute("DELETE FROM incidents WHERE id <= ?", (iid - MAX_INCIDENTS,))   # retention
            return iid

    def update_incident(self, iid, **kw):
        if not kw:
            return
        cols, vals = [], []
        for k, v in kw.items():
            if k in ("before", "after", "steps", "analysis", "notes", "decision"):
                k, v = k + "_json", json.dumps(v)
            cols.append(f"{k}=?")
            vals.append(v)
        with closing(self._conn()) as c, c:
            c.execute(f"UPDATE incidents SET {','.join(cols)} WHERE id=?", vals + [iid])

    def get_incident(self, iid):
        with closing(self._conn()) as c:
            r = c.execute("SELECT * FROM incidents WHERE id=?", (iid,)).fetchone()
        return self._row(r) if r else None

    def list_incidents(self, status=None, limit=200):
        q, args = "SELECT * FROM incidents", []
        if status and status.upper() == "ACTIVE":                    # "active" includes incidents awaiting approval
            q += " WHERE status IN ('ACTIVE','PENDING_APPROVAL')"
        elif status:
            q += " WHERE status=?"
            args.append(status.upper())
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with closing(self._conn()) as c:
            return [self._row(r) for r in c.execute(q, args)]

    def counts(self):
        with closing(self._conn()) as c:
            active = c.execute("SELECT COUNT(*) FROM incidents WHERE status IN ('ACTIVE','PENDING_APPROVAL')").fetchone()[0]
            pending = c.execute("SELECT COUNT(*) FROM incidents WHERE status='PENDING_APPROVAL'").fetchone()[0]
            rec = c.execute("SELECT COUNT(*) FROM incidents WHERE status='RECOVERED' AND resolved_at>?",
                            (time.time() - 86400,)).fetchone()[0]
        return {"active": active, "pending_approval": pending, "recoveries_24h": rec}

    def summary(self):
        """Headline numbers for the Incidents page."""
        with closing(self._conn()) as c:
            rows = c.execute("SELECT status, COUNT(*) n, AVG(recovery_seconds) avg_s FROM incidents GROUP BY status").fetchall()
            by_type = {r["type"]: r["n"] for r in c.execute("SELECT type, COUNT(*) n FROM incidents GROUP BY type")}
        with closing(self._conn()) as c:
            analyses = [json.loads(r[0]) for r in c.execute(
                "SELECT analysis_json FROM incidents WHERE analysis_json IS NOT NULL ORDER BY id DESC LIMIT 1000")]
        verdicts = {}
        for a in analyses:
            verdicts[a.get("verdict")] = verdicts.get(a.get("verdict"), 0) + 1
        n = {r["status"]: r["n"] for r in rows}
        avg = {r["status"]: r["avg_s"] for r in rows}
        rec, failed, active = n.get("RECOVERED", 0), n.get("FAILED", 0), n.get("ACTIVE", 0)
        finished = rec + failed
        active += n.get("PENDING_APPROVAL", 0)
        return {"total": rec + failed + active + n.get("RESOLVED", 0) + n.get("DISMISSED", 0), "recovered": rec, "failed": failed, "active": active,
                "success_rate": round(100 * rec / finished, 1) if finished else None,
                "mttr_seconds": round(avg["RECOVERED"], 1) if avg.get("RECOVERED") is not None else None,
                "by_type": by_type, "resolved_manually": n.get("RESOLVED", 0), "dismissed": n.get("DISMISSED", 0),
                "pending_approval": n.get("PENDING_APPROVAL", 0), "verdicts": verdicts,
                "effectiveness_rate": round(100 * verdicts.get("effective", 0) / sum(verdicts.values()), 1) if verdicts else None}

    def close_stale(self):
        """Incidents left ACTIVE by a previous process can never complete; close them."""
        with closing(self._conn()) as c, c:
            c.execute("UPDATE incidents SET status='FAILED', resolved_at=?, "
                      "description=COALESCE(description,'')||' [KubeHeal restarted during recovery]' "
                      "WHERE status IN ('ACTIVE','PENDING_APPROVAL')", (time.time(),))

    # ---- incident management --------------------------------------------
    def acknowledge(self, iid, by):
        with closing(self._conn()) as c, c:
            c.execute("UPDATE incidents SET acknowledged_at=COALESCE(acknowledged_at,?), acknowledged_by=COALESCE(acknowledged_by,?) WHERE id=?",
                      (time.time(), by, iid))

    def add_note(self, iid, author, text):
        inc = self.get_incident(iid)
        notes = (inc["notes"] or [])[-49:] + [{"ts": time.time(), "author": author, "text": text}]
        self.update_incident(iid, notes=notes)
        return notes

    # ---- health category history -----------------------------------------
    def log_health(self, app, frm, to, score, reasons, kind):
        with closing(self._conn()) as c, c:
            c.execute("INSERT INTO health_events(ts,application,from_status,to_status,score,reasons_json,kind) VALUES(?,?,?,?,?,?,?)",
                      (time.time(), app, frm, to, score, json.dumps(reasons), kind))
            c.execute("DELETE FROM health_events WHERE id <= (SELECT MAX(id) FROM health_events) - 2000")

    def list_health(self, limit=30, app=None):
        q, args = "SELECT * FROM health_events", []
        if app:
            q += " WHERE application=?"
            args.append(app)
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with closing(self._conn()) as c:
            out = []
            for r in c.execute(q, args):
                d = dict(r)
                d["reasons"] = json.loads(d.pop("reasons_json") or "[]")
                out.append(d)
            return out

    # ---- activity log ---------------------------------------------------
    def log_event(self, application, message, level="info"):
        with closing(self._conn()) as c, c:
            c.execute("INSERT INTO events(ts,application,level,message) VALUES(?,?,?,?)",
                      (time.time(), application, level, message))
            c.execute("DELETE FROM events WHERE id <= (SELECT MAX(id) FROM events) - 500")

    def list_events(self, limit=15):
        with closing(self._conn()) as c:
            return [dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))]
