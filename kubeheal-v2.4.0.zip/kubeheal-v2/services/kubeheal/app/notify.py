"""Best-effort webhook notifications (Slack / Mattermost / Discord-compatible JSON)."""
import logging
import threading

import requests

log = logging.getLogger("kubeheal.notify")
ICON = {"opened": ":rotating_light:", "recovered": ":white_check_mark:", "failed": ":x:", "approval": ":raised_hand:", "relapsed": ":repeat:"}


class Notifier:
    def __init__(self, url, session=None):
        self.url = url
        self.http = session or requests

    @property
    def enabled(self):
        return bool(self.url)

    @staticmethod
    def message(kind, inc):
        base = f"{ICON.get(kind, '')} KubeGuard incident #{inc['id']} {kind}: {inc['application']} / {inc['type_label']}"
        if kind == "approval":
            return f"{base} needs approval before KubeGuard acts. {inc.get('description') or ''}".strip()
        if kind == "relapsed":
            return f"{base} relapsed: the problem came back after the recovery ({inc.get('action') or 'no action'})"
        if kind == "opened":
            return f"{base} ({inc['severity']}). {inc.get('description') or ''}".strip()
        action = inc.get("action") or "no action"
        secs = inc.get("recovery_seconds")
        return f"{base} via {action}" + (f" in {secs:.1f}s" if secs is not None else "")

    def send_text(self, text, wait=False):
        """Fire-and-forget a free-text message (used for degradation alerts). Never raises."""
        if not self.enabled:
            return None

        def post():
            try:
                self.http.post(self.url, json={"text": text, "content": text}, timeout=5)
            except Exception as exc:
                log.warning("webhook failed: %s", exc)

        t = threading.Thread(target=post, daemon=True, name="notify")
        t.start()
        if wait:
            t.join(6)
        return text

    def send(self, kind, inc, wait=False):
        """Fire and forget unless wait=True (used by tests). Never raises."""
        if not self.enabled:
            return None
        text = self.message(kind, inc)

        def post():
            try:
                self.http.post(self.url, json={"text": text, "content": text}, timeout=5)
            except Exception as exc:
                log.warning("webhook failed: %s", exc)

        t = threading.Thread(target=post, daemon=True, name="notify")
        t.start()
        if wait:
            t.join(6)
        return text
