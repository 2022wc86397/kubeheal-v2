#!/usr/bin/env bash
# Run the KubeShop sample locally (no Docker or Kubernetes): storefront on http://localhost:8081
#   ./scripts/run-shop.sh                 storefront + API + database
#   LOADGEN=1 ./scripts/run-shop.sh       plus simulated shoppers
#   PORT=9000 ./scripts/run-shop.sh       another storefront port
# Fault injection needs the token:  curl -X POST -H "X-Chaos-Token: $CHAOS_TOKEN" 'http://localhost:8202/chaos/errors?seconds=30&rate=1'
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; K="$ROOT/services/kubeshop"
PORT="${PORT:-8081}"; API_PORT="${API_PORT:-8202}"; DB_PORT="${DB_PORT:-8201}"
if ! python3 -c "import flask, requests" 2>/dev/null; then
  [[ -d "$K/.venv" ]] || python3 -m venv "$K/.venv"
  . "$K/.venv/bin/activate"; pip install -q -r "$K/requirements.txt"
fi
export CHAOS_TOKEN="${CHAOS_TOKEN:-local-dev-token}" DB_PATH="${DB_PATH:-/tmp/kubeshop-local.db}"
trap 'kill $(jobs -p) 2>/dev/null || true' EXIT INT TERM

serve() {   # serve <dir> <port> [ENV=VALUE ...]
  local dir=$1 port=$2; shift 2
  ( cd "$K/$dir" && env "$@" PYTHONPATH="$K" python3 -c "from app import app; app.run(host='127.0.0.1', port=$port, threaded=True)" ) &
}
serve db  "$DB_PORT"
serve api "$API_PORT" DB_URL="http://127.0.0.1:$DB_PORT"
serve web "$PORT"     BACKEND_URL="http://127.0.0.1:$API_PORT"
[[ "${LOADGEN:-0}" == 1 ]] && ( FRONTEND_URL="http://127.0.0.1:$PORT" python3 "$K/loadgen/loadgen.py" ) &

for _ in $(seq 1 40); do curl -sf "http://127.0.0.1:$PORT/api/products" >/dev/null 2>&1 && break; sleep 0.5; done
echo "KubeShop is running:  storefront http://localhost:$PORT   (API :$API_PORT, database :$DB_PORT)   Ctrl+C to stop"
wait
