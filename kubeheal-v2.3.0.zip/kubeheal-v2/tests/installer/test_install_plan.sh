#!/usr/bin/env bash
# Validates the installer's plan per operating system using --dry-run and fake /etc/os-release files.
# Nothing is installed. Catches OS-specific mistakes (wrong package manager, sudo PATH, SELinux flag, curl conflict).
set -uo pipefail
cd "$(dirname "$0")/../.." || exit 1
FAILS=0; N=0
plan() { OS_RELEASE_FILE="tests/installer/os/$1.txt" SELINUX_MODE="${2:-Permissive}" ./install.sh --dry-run 2>&1; }
check() {   # name, haystack, grep -E pattern, expect (yes|no)
  N=$((N+1)); local hit=no; grep -qE -- "$3" <<<"$2" && hit=yes
  if [[ "$hit" == "$4" ]]; then printf 'PASS  %s\n' "$1"; else printf 'FAIL  %s  (pattern: %s, expected %s)\n' "$1" "$3" "$4"; FAILS=$((FAILS+1)); fi
}

echo "--- Amazon Linux 2023 (SELinux permissive, the default)"
P=$(plan al2023)
check "AL2023: detected as rhel/dnf"                    "$P" "amzn 2023 \(rhel, package manager: dnf"      yes
check "AL2023: installs docker with dnf"                "$P" "sudo dnf install -y docker$"                 yes
check "AL2023: never uses apt"                          "$P" "apt-get"                                     no
check "AL2023: does not install conflicting 'curl'"     "$P" "dnf install -y curl"                         no
check "AL2023: skips k3s-selinux rpm when not enforcing" "$P" "INSTALL_K3S_SKIP_SELINUX_RPM=true"          yes
check "AL2023: imports images via absolute k3s path"    "$P" "sudo /usr/local/bin/k3s ctr images import"   yes
check "AL2023: no bare 'sudo k3s' (secure_path trap)"   "$P" "sudo k3s "                                   no
check "AL2023: swap uses dd (XFS-safe), not fallocate"  "$P" "fallocate"                                   no
check "AL2023: builds the KubeGuard image"              "$P" "docker build -q -t kubeheal/kubeheal:2\\.[0-9]+\\.[0-9]+" yes
for svc in web api db loadgen; do
  check "AL2023: builds kubeshop-$svc from its own Dockerfile" "$P" "docker build -q -f .*/services/kubeshop/$svc/Dockerfile -t kubeheal/kubeshop-$svc:[0-9.]+" yes
  check "AL2023: imports kubeshop-$svc into k3s"              "$P" "k3s ctr images import" yes
done
check "AL2023: creates the shared chaos token secret"    "$P" "kubeheal-chaos"                                  yes
check "AL2023: no longer builds the old demo-app image"  "$P" "kubeheal/demo-app"                               no
check "AL2023: waits on every rollout incl. kubeheal"   "$P" "rollout status deployment/kubeheal"          yes
check "AL2023: includes the self-check step"            "$P" "Self-check"                                  yes

echo "--- Amazon Linux 2023 with SELinux enforcing"
P=$(plan al2023 Enforcing)
check "enforcing: lets k3s install its selinux policy"  "$P" "INSTALL_K3S_SKIP_SELINUX_RPM"                no

echo "--- Amazon Linux 2"
P=$(plan al2)
check "AL2: uses yum"                                   "$P" "sudo yum install -y docker$"                 yes
check "AL2: never uses dnf"                             "$P" "sudo dnf"                                    no

echo "--- Ubuntu 24.04"
P=$(plan ubuntu2404)
check "Ubuntu: apt-get installs docker.io + curl"       "$P" "apt-get install -y docker\.io curl"          yes
check "Ubuntu: never uses dnf/yum"                      "$P" "sudo (dnf|yum)"                              no
check "Ubuntu: no SELinux flag"                         "$P" "SKIP_SELINUX"                                no

echo "--- Debian 12"
check "Debian: supported, apt path"                     "$(plan debian12)" "package manager: apt"          yes

echo "--- Unsupported OS"
OUT=$(OS_RELEASE_FILE=tests/installer/os/rocky9.txt ./install.sh --dry-run 2>&1); RC=$?
N=$((N+1)); if (( RC != 0 )) && grep -q "unsupported OS" <<<"$OUT"; then echo "PASS  Rocky: rejected with a clear message"; else echo "FAIL  Rocky should be rejected"; FAILS=$((FAILS+1)); fi
OUT=$(SKIP_PACKAGES=1 OS_RELEASE_FILE=tests/installer/os/rocky9.txt ./install.sh --dry-run 2>&1); RC=$?
N=$((N+1)); if (( RC == 0 )) && ! grep -qE "dnf install|apt-get" <<<"$OUT"; then echo "PASS  Rocky + SKIP_PACKAGES=1: proceeds without touching packages"; else echo "FAIL  SKIP_PACKAGES path"; FAILS=$((FAILS+1)); fi

echo "--- Dashboard port (the GUI must be reachable on 8080)"
P=$(plan al2023)
check "default: k3s NodePort range widened to include 8080"   "$P" "service-node-port-range=8080-32767"      yes
check "default: Service published on nodePort 8080"           "$P" "nodePort: 8080/"                        yes
check "default: self-check probes port 8080"                   "$P" "node-ip>:8080/api/health"               yes
check "default: never replaced with the old 30080"             "$P" "nodePort: 30080/' deploy"                no
P=$(GUI_PORT=9090 OS_RELEASE_FILE=tests/installer/os/al2023.txt SELINUX_MODE=Permissive ./install.sh --dry-run 2>&1)
check "GUI_PORT=9090: range still reaches down to the storefront port 8081" "$P" "service-node-port-range=8081-32767" yes
check "GUI_PORT=9090: nodePort 9090"                           "$P" "nodePort: 9090/"                        yes
P=$(GUI_PORT=31000 STORE_PORT=31001 OS_RELEASE_FILE=tests/installer/os/al2023.txt SELINUX_MODE=Permissive ./install.sh --dry-run 2>&1)
check "both ports high: range keeps the default 30000 floor"   "$P" "service-node-port-range=30000-32767"     yes
P=$(USE_EXISTING_CLUSTER=1 OS_RELEASE_FILE=tests/installer/os/al2023.txt SELINUX_MODE=Permissive ./install.sh --dry-run 2>&1)
check "existing cluster: apiserver is not reconfigured"        "$P" "service-node-port-range"                 no
check "existing cluster: defaults to nodePort 30080"           "$P" "nodePort: 30080/' deploy"                yes
N=$((N+1)); if GUI_PORT=80 OS_RELEASE_FILE=tests/installer/os/al2023.txt ./install.sh --dry-run >/dev/null 2>&1; then echo "FAIL  GUI_PORT=80 accepted"; FAILS=$((FAILS+1)); else echo "PASS  privileged/invalid GUI_PORT rejected"; fi
N=$((N+1)); if GUI_PORT=abc OS_RELEASE_FILE=tests/installer/os/al2023.txt ./install.sh --dry-run >/dev/null 2>&1; then echo "FAIL  GUI_PORT=abc accepted"; FAILS=$((FAILS+1)); else echo "PASS  non-numeric GUI_PORT rejected"; fi

echo "--- Storefront port (the monitored sample shop)"
P=$(plan al2023)
check "default: storefront published on nodePort 8081"         "$P" "s/nodePort: 31081/nodePort: 8081/"       yes
check "default: dashboard stays on 8080"                       "$P" "s/nodePort: 30080/nodePort: 8080/"       yes
check "default: self-check covers the shop chain"              "$P" "storefront -> API -> database"           yes
check "default: host probe covers the storefront port"         "$P" "node-ip>:8081/api/products"              yes
P=$(STORE_PORT=9091 OS_RELEASE_FILE=tests/installer/os/al2023.txt SELINUX_MODE=Permissive ./install.sh --dry-run 2>&1)
check "STORE_PORT=9091 is honoured"                            "$P" "nodePort: 9091/"                         yes
check "STORE_PORT=9091: range starts at the dashboard port"    "$P" "service-node-port-range=8080-32767"      yes
P=$(USE_EXISTING_CLUSTER=1 OS_RELEASE_FILE=tests/installer/os/al2023.txt SELINUX_MODE=Permissive ./install.sh --dry-run 2>&1)
check "existing cluster: storefront defaults to 31081"         "$P" "s/nodePort: 31081/nodePort: 31081/"      yes
N=$((N+1)); if GUI_PORT=9000 STORE_PORT=9000 OS_RELEASE_FILE=tests/installer/os/al2023.txt ./install.sh --dry-run >/dev/null 2>&1; then echo "FAIL  identical GUI_PORT and STORE_PORT accepted"; FAILS=$((FAILS+1)); else echo "PASS  identical GUI_PORT and STORE_PORT rejected"; fi
N=$((N+1)); if STORE_PORT=80 OS_RELEASE_FILE=tests/installer/os/al2023.txt ./install.sh --dry-run >/dev/null 2>&1; then echo "FAIL  STORE_PORT=80 accepted"; FAILS=$((FAILS+1)); else echo "PASS  privileged STORE_PORT rejected"; fi

echo "--- Options"
N=$((N+1)); if ./install.sh --bogus >/dev/null 2>&1; then echo "FAIL  unknown option accepted"; FAILS=$((FAILS+1)); else echo "PASS  unknown option rejected"; fi
check "K3S_VERSION is passed through" "$(K3S_VERSION=v1.31.4+k3s1 OS_RELEASE_FILE=tests/installer/os/al2023.txt SELINUX_MODE=Permissive ./install.sh --dry-run 2>&1)" "INSTALL_K3S_VERSION=v1\.31\.4\+k3s1" yes

echo; echo "$((N-FAILS))/$N installer checks passed"; exit $((FAILS ? 1 : 0))
