/* Real-browser test of the KubeShop sample: a customer journey, then a database outage as the customer sees it.
 *   BASE=http://localhost:8081 DB_BASE=http://localhost:8201 TOKEN=... node shop.test.js    (OUT=dir saves screenshots)
 */
const puppeteer = require('puppeteer-core');
const BASE = process.env.BASE || 'http://localhost:8081';
const DB = process.env.DB_BASE || 'http://localhost:8201';
const TOKEN = process.env.TOKEN || 'e2e-token';
const OUT = process.env.OUT || '';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = []; const problems = [];
const check = (name, ok, extra = '') => { results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`); };
const chaos = (kind, qs = '') => fetch(`${DB}/chaos/${kind}${qs}`, {method: 'POST', headers: {'X-Chaos-Token': TOKEN}}).then(r => r.status);
async function until(fn, ms = 10000, step = 120) { const end = Date.now() + ms; while (Date.now() < end) { try { const v = await fn(); if (v) return v; } catch (_) {} await sleep(step); } return null; }

(async () => {
  let exe = process.env.CHROME_PATH, args = [];
  if (!exe) { const c = require('@sparticuz/chromium'); const cc = c.default || c; exe = await cc.executablePath(); args = cc.args; }
  const browser = await puppeteer.launch({executablePath: exe, headless: 'shell', args: [...args, '--no-sandbox']});
  const page = await browser.newPage();
  await page.setViewport({width: 1280, height: 900, deviceScaleFactor: 1.5});
  page.on('pageerror', e => problems.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/status of (5\d\d|40\d)/.test(m.text())) problems.push('console: ' + m.text()); });
  const shot = async n => { if (OUT) await page.screenshot({path: `${OUT}/${n}.png`, fullPage: false}); };
  const text = sel => page.$eval(sel, e => e.innerText).catch(() => '');
  const cards = () => page.$$eval('.prod', e => e.length);

  // ---- storefront loads from the real stack
  await page.goto(BASE, {waitUntil: 'domcontentloaded'});
  check('storefront renders the catalogue (12 products)', !!(await until(async () => (await cards()) === 12)), String(await cards()));
  check('category chips are built from the data', (await page.$$('.chip')).length === 6, String((await page.$$('.chip')).length));
  check('footer shows the request path through all three tiers', /web .+ → api .+ → db .+/.test(await text('#chain')), await text('#chain'));
  check('health indicator is green', await page.$eval('#dot', e => e.classList.contains('ok')));
  await shot('s1-storefront');

  // ---- search and filter
  await page.type('#q', 'watch'); await until(async () => (await cards()) === 1);
  check('search narrows to the matching product', (await cards()) === 1 && /Smart Watch/.test(await text('.prod')));
  await page.$eval('#q', e => { e.value = ''; e.dispatchEvent(new Event('input')); }); await until(async () => (await cards()) === 12);
  await page.click('.chip[data-c="Home"]'); await until(async () => (await cards()) === 3);
  check('category filter shows only that category', (await cards()) === 3);
  await page.click('.chip[data-c=""]'); await until(async () => (await cards()) === 12);

  // ---- cart with live server-side pricing
  await page.click('[data-add="11"]'); await page.click('[data-add="1"]');
  check('cart badge counts items', (await text('#cartCount')).trim() === '2');
  await page.click('#cartBtn'); await until(async () => /Total/.test(await text('#totals')));
  const totals = await text('#totals');
  check('cart shows subtotal, shipping, tax and total from the API', /Subtotal/.test(totals) && /Shipping/.test(totals) && /Tax/.test(totals) && /\$/.test(totals), totals);
  check('free-shipping message appears over $50 ($18.50 + $79.99)', /free shipping/i.test(totals), totals);
  await page.click('[data-inc="11"]'); await until(async () => /\$/.test(await text('#totals')));
  await sleep(400);
  await shot('s2-cart');

  // ---- checkout: success, order tracking
  await page.click('#checkoutBtn'); await until(() => page.$('#checkout[open]'));
  await page.click('#payBtn');
  const oid = await until(async () => { const t = await text('#oid'); return /^ORD-[0-9A-F]{8}$/.test(t) ? t : null; }, 8000);
  check('checkout confirms the order with an order number', !!oid, await text('#doneBody'));
  await shot('s3-order-confirmed');
  check('cart is emptied after the purchase', (await text('#cartCount')).trim() === '0');
  await page.click('#doneClose');
  await page.type('#trackId', oid || 'ORD-00000000'); await page.click('#trackForm button');
  check('the order can be tracked by its number', !!(await until(async () => /confirmed/i.test(await text('#trackOut')))), await text('#trackOut'));

  // ---- checkout: declined and invalid cards, entirely handled in the UI
  await page.click('[data-add="2"]'); await page.click('#cartBtn'); await until(async () => /Total/.test(await text('#totals')));
  await page.click('#checkoutBtn'); await until(() => page.$('#checkout[open]'));
  await page.$eval('[name=card]', e => { e.value = '4000 0000 0000 0002'; }); await page.click('#payBtn');
  check('declined card shows a clear bank-decline message', !!(await until(async () => /declined/i.test(await text('#payMsg')))), await text('#payMsg'));
  await page.$eval('[name=card]', e => { e.value = '4242 4242 4242 4241'; }); await page.click('#payBtn');
  check('invalid card number is rejected with the API message', !!(await until(async () => /not valid/i.test(await text('#payMsg')))), await text('#payMsg'));

  // ---- outage: the database starts failing; what does the customer see?
  await page.$eval('[name=card]', e => { e.value = '4242 4242 4242 4242'; });
  check('inject database errors (token accepted)', (await chaos('errors', '?seconds=60&rate=1')) === 200);
  await sleep(1300);                                                      // let the API's 1 s catalogue cache expire
  await page.click('#payBtn');
  check('during the outage checkout says so and promises the card was not charged', !!(await until(async () => /not charged/i.test(await text('#payMsg')), 12000)), await text('#payMsg'));
  check('footer health turns red during the outage', await page.$eval('#dot', e => e.classList.contains('bad')));
  await shot('s4-outage');
  check('fault endpoints refuse requests without the token', (await fetch(`${DB}/chaos/stop`, {method: 'POST'})).status === 403);

  // ---- recovery
  check('stop the fault', (await chaos('stop')) === 200);
  await sleep(1300);
  await page.click('#payBtn');
  const oid2 = await until(async () => { const t = await text('#oid'); return (await page.$('#done[open]')) && /^ORD-[0-9A-F]{8}$/.test(t) && t !== oid ? t : null; }, 10000);
  check('the same checkout succeeds once the database is back (a NEW order number)', !!oid2, await text('#payMsg'));
  if (oid2) await page.click('#doneClose');
  check('footer health recovers to green', !!(await until(() => page.$eval('#dot', e => e.classList.contains('ok')))));

  // ---- phone layout
  await page.setViewport({width: 390, height: 844, deviceScaleFactor: 2, isMobile: true});
  await page.goto(BASE, {waitUntil: 'domcontentloaded'}); await until(async () => (await cards()) === 12);
  check('no horizontal overflow on a phone', (await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)) <= 1);
  await shot('s5-mobile');

  check('no JS errors (expected 4xx/5xx resource logs ignored)', problems.length === 0, '\n   ' + problems.join('\n   '));
  await browser.close();
  const failed = results.filter(x => !x).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('SHOP E2E crashed:', e); process.exit(2); });
