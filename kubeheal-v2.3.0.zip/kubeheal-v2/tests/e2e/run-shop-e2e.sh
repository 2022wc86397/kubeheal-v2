#!/usr/bin/env bash
# Real-browser test of the sample shop: starts the three services locally and drives a customer journey in Chromium.
set -euo pipefail
cd "$(dirname "$0")"
[[ -d node_modules ]] || npm install --silent
rm -f /tmp/kubeshop-e2e.db*
export PORT=8203 API_PORT=8202 DB_PORT=8201 CHAOS_TOKEN=e2e-token DB_PATH=/tmp/kubeshop-e2e.db CACHE_TTL=1 AUTO_RESTOCK=0
../../scripts/run-shop.sh >/tmp/kubeshop-e2e.log 2>&1 &
SHOP=$!
trap 'kill $SHOP 2>/dev/null || true; pkill -P $SHOP 2>/dev/null || true' EXIT
for _ in $(seq 1 60); do curl -sf "localhost:$PORT/api/products" >/dev/null && break; sleep 0.5; done
BASE="http://localhost:$PORT" DB_BASE="http://localhost:$DB_PORT" TOKEN="$CHAOS_TOKEN" node shop.test.js
