"""Plain data models shared by the real cluster backend and the simulator."""
from dataclasses import dataclass, asdict
from typing import Optional

INCIDENT_TYPES = {
    "POD_FAILURE": "Pod Failure",
    "CPU_OVERLOAD": "CPU Overload",
    "MEMORY_PRESSURE": "Memory Pressure",
    "HIGH_ERROR_RATE": "High Error Rate",
}

BAD_POD_REASONS = {
    "CrashLoopBackOff", "ImagePullBackOff", "ErrImagePull", "CreateContainerConfigError",
    "RunContainerError", "OOMKilled", "Error",
}


@dataclass
class AppInfo:
    name: str
    desired: int
    ready: int
    updated: int
    replicas: int
    baseline: Optional[int] = None
    cpu_limit: Optional[float] = None      # cores per pod
    mem_limit: Optional[float] = None      # bytes per pod
    has_app_metrics: bool = False          # pods expose http_* metrics
    ui: str = ""                            # kubeheal.io/ui annotation: "public" (own NodePort) or "proxy" (via /demo/<app>/)
    public_port: Optional[int] = None      # NodePort of the Service named like the app, when there is one

    @property
    def rollout_complete(self) -> bool:
        return (self.desired > 0 and self.updated == self.desired
                and self.ready == self.desired and self.replicas == self.desired)

    def to_dict(self):
        return asdict(self)


@dataclass
class PodInfo:
    name: str
    app: str
    phase: str
    ready: bool
    restarts: int = 0
    node: str = ""
    ip: str = ""
    age_s: float = 0.0
    reason: Optional[str] = None

    @property
    def status(self) -> str:
        if self.phase == "Terminating":
            return "Terminating"
        if self.reason:
            return self.reason
        if self.phase == "Running" and not self.ready:
            return "NotReady"
        return self.phase

    def to_dict(self):
        d = asdict(self)
        d["status"] = self.status
        return d
