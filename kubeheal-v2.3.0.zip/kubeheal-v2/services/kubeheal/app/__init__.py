"""KubeHeal: Kubernetes application health monitoring and auto-recovery."""
__version__ = "2.3.0"
