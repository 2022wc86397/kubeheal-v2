"""Monitor loop: collects state, computes health, detects incidents, scales back down."""
import logging
import threading
import time

from .health import score_app
from .models import BAD_POD_REASONS, INCIDENT_TYPES
from .recovery import snapshot

log = logging.getLogger("kubeheal.monitor")
EMPTY = {"cpu_pct": None, "mem_pct": None, "resp_ms": None, "err_pct": None,
         "req_rate": None, "cpu_cores": None, "mem_mib": None}


class Monitor:
    def __init__(self, cluster, metrics, store, recovery, interval=10.0, clock=time.time):
        self.cluster, self.metrics, self.store, self.recovery = cluster, metrics, store, recovery
        self.interval, self.clock = interval, clock
        self.snapshot = {"ts": 0, "cluster_connected": False, "prometheus_ok": False, "error": None,
                         "apps": [], "pods": [], "cluster": {}}
        self.ticks = 0
        self._since, self._last, self._idle = {}, {}, {}
        self._latched = set()      # (app, type) already handled; re-armed only after the breach clears

    def run_forever(self):
        while True:
            try:
                self.tick()
            except Exception:
                log.exception("monitor tick failed")
            time.sleep(self.interval)

    def start(self):
        threading.Thread(target=self.run_forever, daemon=True, name="monitor").start()

    def app_state(self, name):
        return next((a for a in self.snapshot["apps"] if a["name"] == name), None)

    # ---- one cycle ------------------------------------------------------
    def tick(self):
        st, now = self.store.get_settings(), self.clock()
        self.ticks += 1
        try:
            apps = self.cluster.list_apps()
            all_pods = self.cluster.list_pods()
        except Exception as exc:
            log.error("cluster unreachable: %s", exc)
            self.snapshot = {**self.snapshot, "ts": now, "cluster_connected": False, "error": str(exc)}
            return

        names = {a.name for a in apps}
        pod_m = self._safe(self.metrics.pod_metrics, {})
        cluster_m = self._safe(self.metrics.cluster_metrics, {"cpu_pct": None, "mem_pct": None})
        quota = self._safe(self.cluster.quota_pods, None)
        active = {i["application"]: i["id"] for i in self.store.list_incidents("ACTIVE")}

        pods_out, apps_out = [], []
        for a in apps:
            pods = [p for p in all_pods if p.app == a.name]
            m = {**EMPTY, **self._safe(lambda: self.metrics.app_metrics(a), {})}
            # A planned scale-out (desired > baseline) is not lost availability while its new pods start:
            # require at least min(desired, max(ready, baseline)) replicas, so genuine pod loss still scores badly.
            expected = min(a.desired, max(a.ready, a.baseline)) if a.baseline and a.desired > 0 else a.desired
            score, status, reasons = score_app(expected, a.ready, m, st)
            self._ensure_baseline(a)
            self._detect(a, pods, m, st, now)
            self._maybe_scale_down(a, m, st, now)
            apps_out.append({
                "name": a.name, "desired": a.desired, "ready": a.ready, "baseline": a.baseline,
                "score": score, "status": status, "reasons": reasons, **m,
                "restarts": sum(p.restarts for p in pods), "has_app_metrics": a.has_app_metrics,
                "cpu_limit": a.cpu_limit, "mem_limit": a.mem_limit, "ui": a.ui, "public_port": a.public_port,
                "active_incident": active.get(a.name)})
            for p in pods:
                pm = pod_m.get(p.name, {})
                d = p.to_dict()
                d["cpu_cores"] = pm.get("cpu_cores")
                d["mem_mib"] = pm["mem_bytes"] / 1048576 if pm.get("mem_bytes") is not None else None
                d["cpu_pct"] = 100 * d["cpu_cores"] / a.cpu_limit if d["cpu_cores"] is not None and a.cpu_limit else None
                d["mem_pct"] = 100 * pm["mem_bytes"] / a.mem_limit if pm.get("mem_bytes") is not None and a.mem_limit else None
                pods_out.append(d)

        self.snapshot = {
            "ts": now, "cluster_connected": True, "error": None,
            "prometheus_ok": bool(getattr(self.metrics, "ok", True)),
            "apps": apps_out, "pods": pods_out,
            "cluster": {"cpu_pct": cluster_m.get("cpu_pct"), "mem_pct": cluster_m.get("mem_pct"),
                        "pods_used": quota[0] if quota else len([p for p in all_pods]),
                        "pods_max": quota[1] if quota else None}}
        # forget state for apps that are no longer monitored
        for key in [k for k in self._since if k[0] not in names]:
            self._since.pop(key, None)
        self._latched = {k for k in self._latched if k[0] in names}

    @staticmethod
    def _safe(fn, default):
        try:
            v = fn()
            return default if v is None else v
        except Exception as exc:
            log.warning("metrics call failed: %s", exc)
            return default

    # ---- detection ------------------------------------------------------
    def _breaches(self, a, pods, m, st):
        found = {}
        bad = [p for p in pods if p.reason in BAD_POD_REASONS]
        if a.desired > 0 and a.ready < a.desired:
            found["POD_FAILURE"] = (f"Only {a.ready} of {a.desired} replicas are ready", "High")
        elif bad:
            found["POD_FAILURE"] = (f"Pod {bad[0].name} is {bad[0].reason}", "High")
        cpu = m.get("cpu_pct")
        if cpu is not None and cpu >= st["cpu_critical"]:
            found["CPU_OVERLOAD"] = (
                f"High CPU usage detected (>{st['cpu_critical']:.0f}% for {st['sustain_seconds']:.0f}s). "
                f"Measured {cpu:.0f}% of the CPU limit", "High")
        mem = m.get("mem_pct")
        if mem is not None and mem >= st["memory_critical"]:
            found["MEMORY_PRESSURE"] = (
                f"High memory usage detected (>{st['memory_critical']:.0f}% for {st['sustain_seconds']:.0f}s). "
                f"Measured {mem:.0f}% of the memory limit", "High")
        err = m.get("err_pct")
        if err is not None and err >= st["error_rate_critical"]:
            found["HIGH_ERROR_RATE"] = (
                f"Error rate above {st['error_rate_critical']:.1f}% for {st['sustain_seconds']:.0f}s. "
                f"Measured {err:.1f}% 5xx responses", "High" if err >= 20 else "Medium")
        return found

    def _detect(self, a, pods, m, st, now):
        found = self._breaches(a, pods, m, st)
        before = snapshot(a, m)
        for typ in INCIDENT_TYPES:
            key = (a.name, typ)
            if typ not in found:
                self._since.pop(key, None)
                self._latched.discard(key)
                continue
            if key in self._latched:        # same breach is still ongoing: never loop restarts/incidents
                continue
            desc, sev = found[typ]
            since = self._since.setdefault(key, now)
            sustain = min(st["sustain_seconds"], 10) if typ == "POD_FAILURE" else st["sustain_seconds"]
            if now - since < sustain or self.recovery.is_busy(a.name):
                continue
            if now - self._last.get(key, 0) < st["cooldown_seconds"]:
                continue
            if self.recovery.start(a.name, typ, sev, desc, before, source="auto"):
                self._last[key] = now
                self._latched.add(key)
                self._since.pop(key, None)

    # ---- housekeeping ---------------------------------------------------
    def _ensure_baseline(self, a):
        if a.baseline is None and a.desired > 0 and not self.recovery.is_busy(a.name):
            try:
                self.cluster.set_baseline(a.name, a.desired)
                a.baseline = a.desired
            except Exception as exc:
                log.warning("cannot record baseline for %s: %s", a.name, exc)

    def _maybe_scale_down(self, a, m, st, now):
        """Return to the baseline replica count once load has stayed comfortably low."""
        cpu = m.get("cpu_pct")
        if (not st["auto_recovery"] or a.baseline is None or a.desired <= a.baseline or cpu is None
                or self.recovery.is_busy(a.name) or not a.rollout_complete):
            self._idle.pop(a.name, None)
            return
        projected = cpu * a.desired / (a.desired - 1)            # load per pod after removing one
        if projected >= 0.7 * st["cpu_critical"]:
            self._idle.pop(a.name, None)
            return
        since = self._idle.setdefault(a.name, now)
        if now - since >= st["scale_down_idle_seconds"]:
            self.cluster.scale(a.name, a.desired - 1)
            self.store.log_event(a.name, f"Load is low: scaled {a.desired} to {a.desired - 1} "
                                         f"(baseline {a.baseline})", "info")
            self._idle.pop(a.name, None)
