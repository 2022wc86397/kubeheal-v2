"""Real Kubernetes backend (talks to the API server using the pod's service account)."""
import logging
import time
from datetime import datetime, timezone

from kubernetes import client, config as kconfig

from .models import AppInfo, PodInfo

log = logging.getLogger("kubeheal.k8s")

MONITOR_LABEL = "kubeheal.io/monitor"
BASELINE_ANN = "kubeheal.io/baseline-replicas"
SELF_NAME = "kubeheal"

_MEM = {"Ki": 2**10, "Mi": 2**20, "Gi": 2**30, "Ti": 2**40,
        "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9, "T": 1e12}


def parse_cpu(q):
    if q is None:
        return None
    q = str(q)
    if q.endswith("m"):
        return float(q[:-1]) / 1000
    if q.endswith("u"):
        return float(q[:-1]) / 1e6
    return float(q)


def parse_mem(q):
    if q is None:
        return None
    q = str(q)
    for suffix, mult in _MEM.items():
        if q.endswith(suffix):
            return float(q[: -len(suffix)]) * mult
    return float(q)


def _limit_sum(containers, resource, parser):
    """Sum a limit across containers; None if any container lacks one (percentages would lie)."""
    total = 0.0
    for c in containers:
        lim = (c.resources.limits or {}).get(resource) if c.resources else None
        if lim is None:
            return None
        total += parser(lim)
    return total or None


class KubeCluster:
    def __init__(self, namespace):
        try:
            kconfig.load_incluster_config()
        except kconfig.ConfigException:
            kconfig.load_kube_config()
        self.ns = namespace
        self.core = client.CoreV1Api()
        self.apps = client.AppsV1Api()

    # ---- reads ----------------------------------------------------------
    def _node_ports(self):
        """Service name -> NodePort. Missing RBAC or an API error just means no 'Open app' links."""
        try:
            items = self.core.list_namespaced_service(self.ns).items
        except client.ApiException as exc:
            log.warning("cannot list services (public app links disabled): %s", exc.reason)
            return {}
        out = {}
        for svc in items:
            if svc.spec.type in ("NodePort", "LoadBalancer"):
                port = next((p.node_port for p in (svc.spec.ports or []) if p.node_port), None)
                if port:
                    out[svc.metadata.name] = port
        return out

    def _app(self, d, ports=None):
        spec_c = d.spec.template.spec.containers
        ann = d.metadata.annotations or {}
        tpl_ann = d.spec.template.metadata.annotations or {}
        st = d.status
        base = ann.get(BASELINE_ANN)
        return AppInfo(
            name=d.metadata.name,
            desired=d.spec.replicas or 0,
            ready=st.ready_replicas or 0,
            updated=st.updated_replicas or 0,
            replicas=st.replicas or 0,
            baseline=int(base) if base and base.isdigit() else None,
            cpu_limit=_limit_sum(spec_c, "cpu", parse_cpu),
            mem_limit=_limit_sum(spec_c, "memory", parse_mem),
            has_app_metrics=tpl_ann.get("prometheus.io/scrape") == "true",
            ui=ann.get("kubeheal.io/ui", ""),
            public_port=(ports or {}).get(d.metadata.name),
        )

    def list_apps(self):
        items = self.apps.list_namespaced_deployment(
            self.ns, label_selector=f"{MONITOR_LABEL}=true").items
        ports = self._node_ports()
        return sorted((self._app(d, ports) for d in items), key=lambda a: a.name)

    def get_app(self, name):
        return self._app(self.apps.read_namespaced_deployment(name, self.ns))

    def list_pods(self, app=None):
        now = datetime.now(timezone.utc)
        out = []
        for p in self.core.list_namespaced_pod(self.ns).items:
            owner = next((o for o in (p.metadata.owner_references or []) if o.kind == "ReplicaSet"), None)
            name = owner.name.rsplit("-", 1)[0] if owner else (p.metadata.labels or {}).get("app", "-")
            if app and name != app:
                continue
            statuses = p.status.container_statuses or []
            reason = None
            for cs in statuses:
                if cs.state and cs.state.waiting and cs.state.waiting.reason:
                    reason = cs.state.waiting.reason
                term = cs.last_state.terminated if cs.last_state else None
                if (not reason and term and term.reason == "OOMKilled" and term.finished_at
                        and (now - term.finished_at).total_seconds() < 300):
                    reason = "OOMKilled"
            ready = any(c.type == "Ready" and c.status == "True" for c in (p.status.conditions or []))
            out.append(PodInfo(
                name=p.metadata.name, app=name,
                phase="Terminating" if p.metadata.deletion_timestamp else (p.status.phase or "Unknown"),
                ready=ready, restarts=sum(cs.restart_count for cs in statuses),
                node=p.spec.node_name or "", ip=p.status.pod_ip or "",
                age_s=(now - p.metadata.creation_timestamp).total_seconds(), reason=reason))
        return sorted(out, key=lambda x: x.name)

    def quota_pods(self):
        """(used, hard) pod count from a ResourceQuota, or None if no pod quota exists."""
        try:
            for q in self.core.list_namespaced_resource_quota(self.ns).items:
                hard = (q.status.hard or {}).get("pods")
                if hard is not None:
                    return int((q.status.used or {}).get("pods", 0)), int(hard)
        except client.ApiException as exc:
            log.warning("cannot read resource quota: %s", exc.reason)
        return None

    def candidates(self):
        items = self.apps.list_namespaced_deployment(self.ns).items
        return sorted(d.metadata.name for d in items
                      if (d.metadata.labels or {}).get(MONITOR_LABEL) != "true"
                      and d.metadata.name != SELF_NAME)

    # ---- actions --------------------------------------------------------
    def scale(self, name, replicas):
        self.apps.patch_namespaced_deployment_scale(name, self.ns, {"spec": {"replicas": int(replicas)}})

    def rolling_restart(self, name):
        stamp = datetime.now(timezone.utc).isoformat()
        self.apps.patch_namespaced_deployment(name, self.ns, {"spec": {"template": {"metadata": {
            "annotations": {"kubectl.kubernetes.io/restartedAt": stamp}}}}})

    def delete_pod(self, name, grace=0):
        self.core.delete_namespaced_pod(name, self.ns, grace_period_seconds=grace)

    def set_baseline(self, name, replicas):
        self.apps.patch_namespaced_deployment(name, self.ns, {"metadata": {
            "annotations": {BASELINE_ANN: str(int(replicas))}}})

    def set_monitor(self, name, enabled):
        value = "true" if enabled else None            # null removes the label in a merge patch
        self.apps.patch_namespaced_deployment(name, self.ns, {"metadata": {"labels": {MONITOR_LABEL: value}}})
