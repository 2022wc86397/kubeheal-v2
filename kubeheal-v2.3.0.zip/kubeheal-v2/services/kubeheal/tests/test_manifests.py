"""Guards that read the real Kubernetes manifests, so config drift is caught before it reaches a cluster.

The 2.1.0 outage (pod Running but never Ready) was exactly this: the manifest probed /api/ready while the
password guard only exempted /api/health. These tests would have failed.
"""
import glob
import os

import pytest
import yaml

from app import __version__
from app.config import Config
from app.main import create_app

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
K8S = os.path.join(ROOT, "deploy", "k8s")


def docs():
    out = []
    for f in sorted(glob.glob(os.path.join(K8S, "*.yaml"))):
        out += [d for d in yaml.safe_load_all(open(f)) if d]
    return out


def deployments():
    return [d for d in docs() if d["kind"] == "Deployment"]


def containers(dep):
    return dep["spec"]["template"]["spec"]["containers"]


@pytest.fixture
def secured_app(rt):
    rt.monitor.tick()
    cfg = Config()
    cfg.auth_password = "s3cret"                       # what install.sh always configures
    return create_app(cfg, runtime=rt, start_threads=False).test_client()


def test_every_probe_in_the_kubeheal_manifest_works_without_credentials(secured_app):
    dep = next(d for d in deployments() if d["metadata"]["name"] == "kubeheal")
    probes = [(kind, c[kind]["httpGet"]["path"]) for c in containers(dep) for kind in ("readinessProbe", "livenessProbe", "startupProbe") if kind in c]
    assert {k for k, _ in probes} >= {"readinessProbe", "livenessProbe"}
    for kind, path in probes:
        r = secured_app.get(path)                      # no Authorization header: that is how kubelet probes
        assert r.status_code == 200, f"{kind} {path} answers {r.status_code} with auth enabled; the pod would never become Ready"


def test_readiness_is_503_until_the_first_monitor_cycle_and_never_401(rt):
    cfg = Config()
    cfg.auth_password = "s3cret"
    c = create_app(cfg, runtime=rt, start_threads=False).test_client()
    assert c.get("/api/ready").status_code == 503      # not ready yet, but reachable (not 401)
    rt.monitor.tick()
    assert c.get("/api/ready").status_code == 200


def test_only_the_probe_endpoints_are_open(secured_app):
    for path in ("/api/overview", "/api/settings", "/api/incidents", "/api/config", "/", "/demo/backend/"):
        assert secured_app.get(path).status_code == 401, path


def test_probe_ports_match_container_ports():
    for dep in deployments():
        for c in containers(dep):
            ports = {p["containerPort"] for p in c.get("ports", [])}
            for kind in ("readinessProbe", "livenessProbe"):
                if kind in c and "httpGet" in c[kind]:
                    assert c[kind]["httpGet"]["port"] in ports, f"{dep['metadata']['name']} {kind}"


def test_every_workload_container_has_resource_limits_and_a_pinned_image():
    for dep in deployments():
        for c in containers(dep):
            assert c["resources"]["limits"]["cpu"] and c["resources"]["limits"]["memory"], dep["metadata"]["name"]
            assert not c["image"].endswith(":latest") and ":" in c["image"], c["image"]


def test_version_is_single_sourced_everywhere():
    """One VERSION file drives images, installer, app and demo app. A mismatch means ImagePullBackOff on install,
    or (same tag, new code) a stale image silently reused because imagePullPolicy is IfNotPresent."""
    import re
    version = open(os.path.join(ROOT, "VERSION")).read().strip()
    assert version == __version__
    ours = {c["image"] for d in deployments() for c in containers(d) if c["image"].startswith("kubeheal/")}
    assert ours and all(i.endswith(":" + version) for i in ours), (ours, version)
    assert re.search(r'^VERSION="%s"$' % re.escape(version), open(os.path.join(ROOT, "install.sh")).read(), re.M)
    for f in ("uninstall.sh", "Makefile"):
        tags = set(re.findall(r"kubeheal/(?:kubeheal|demo-app|kubeshop-web|kubeshop-api|kubeshop-db|kubeshop-loadgen):([0-9.]+)", open(os.path.join(ROOT, f)).read()))
        assert tags <= {version}, (f, tags)
    assert f'"APP_VERSION", "{version}"' in open(os.path.join(ROOT, "services", "demo-app", "app.py")).read()


def test_demo_namespace_quota_fits_worst_case_scale_out():
    """Max scale-out plus a rolling-update surge pod must still fit the quota, or recovery itself would fail."""
    quota = next(d for d in docs() if d["kind"] == "ResourceQuota")["spec"]["hard"]
    demo = [d for d in deployments() if d["metadata"]["namespace"] == "kubeheal-demo"]
    max_replicas = int(__import__("app.db", fromlist=["x"]).DEFAULT_SETTINGS["max_replicas"])
    pods, cpu = 0, 0.0
    for d in demo:
        n = d["spec"]["replicas"]
        if d["metadata"]["labels"].get("kubeheal.io/monitor") == "true":
            n = max(n, max_replicas)
        lim = sum(int(c["resources"]["limits"]["cpu"].rstrip("m")) / 1000 for c in containers(d))
        pods += n
        cpu += n * lim
    surge_cpu = 0.2
    assert pods + 1 <= int(quota["pods"]), (pods, quota)
    assert cpu + surge_cpu <= float(quota["limits.cpu"]), (cpu, quota)


def test_rbac_covers_every_api_call_the_controller_makes():
    role = next(d for d in docs() if d["kind"] == "Role" and d["metadata"]["name"] == "kubeheal-controller")
    allowed = {(g, r): set(rule["verbs"]) for rule in role["rules"] for g in rule["apiGroups"] for r in rule["resources"]}
    need = {("", "pods"): {"get", "list", "delete"}, ("apps", "deployments"): {"get", "list", "patch"},
            ("apps", "deployments/scale"): {"patch"}, ("", "resourcequotas"): {"list"}, ("", "services"): {"list"}}
    for key, verbs in need.items():
        assert verbs <= allowed.get(key, set()), f"missing {verbs - allowed.get(key, set())} on {key}"
