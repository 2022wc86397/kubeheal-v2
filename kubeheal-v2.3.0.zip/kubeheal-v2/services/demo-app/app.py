"""Demo workload with real, controllable faults and Prometheus metrics (no extra dependencies).

Endpoints
  GET  /              browsers (Accept: text/html) get the web UI; everything else gets a simulated JSON
                      request (latency ~ BASE_LATENCY_MS) that is counted in metrics
  GET  /api/stats     live self-reported stats for the UI (cpu, memory, throughput, latency, faults)
  GET  /healthz       liveness/readiness (never affected by chaos)
  GET  /metrics       Prometheus exposition
  POST /chaos/cpu?seconds=N              burn CPU (limited by the pod's CPU limit)
  POST /chaos/memory?seconds=N&percent=P allocate memory up to P% of the container limit
  POST /chaos/errors?seconds=N&rate=R    answer fraction R of requests with HTTP 500
  POST /chaos/stop                       end all faults
  POST /chaos/crash                      stop the container (restart policy brings it back); needs ALLOW_CRASH=1
  GET  /chaos/status
"""
import collections
import gc
import html
import os
import random
import signal
import socket
import threading
import time

from flask import Flask, jsonify, request

APP_NAME = os.getenv("APP_NAME", "demo")
APP_VERSION = os.getenv("APP_VERSION", "2.3.0")
BASE_LATENCY_MS = float(os.getenv("BASE_LATENCY_MS", "40"))
POD = socket.gethostname()
STARTED = time.time()
ROLES = {"frontend": ("Web tier", "#1769e0"), "backend": ("API tier", "#7a3de0"), "database": ("Data tier", "#12a05c")}
ROLE, ACCENT = ROLES.get(APP_NAME, ("Demo service", os.getenv("APP_ACCENT", "#0e8f9a")))
INFRA = ("/healthz", "/metrics", "/chaos", "/api/")
_UI = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui.html"), encoding="utf-8").read()
BUCKETS = (0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0)

app = Flask(__name__)
_lock = threading.Lock()
_requests = {}                                   # status code -> count
_hist = [0] * len(BUCKETS)
_hist_sum, _hist_count = 0.0, 0
_chaos = {"cpu_until": 0.0, "mem_until": 0.0, "err_until": 0.0, "err_rate": 0.0}
_ballast = []
_events = collections.deque(maxlen=6000)         # (timestamp, seconds, status) of real requests
_cpu_state = {"t": 0.0, "usage": 0.0, "cores": 0.0}


# ------------------------------------------------------------------ chaos
def _cgroup_read(*paths):
    for p in paths:
        try:
            with open(p) as f:
                v = f.read().strip()
            if v and v != "max":
                return int(v)
        except (OSError, ValueError):
            continue
    return None


UNLIMITED = 2 ** 50


def _mem_state():
    """(used_bytes, limit_bytes). Prefers the container cgroup; falls back to process RSS (local runs)."""
    lim = _cgroup_read("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes")
    cur = _cgroup_read("/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory/memory.usage_in_bytes")
    if lim and cur and lim < UNLIMITED:
        return cur, lim
    rss = 0
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    rss = int(line.split()[1]) * 1024
    except OSError:
        pass
    return rss, int(os.getenv("MEM_LIMIT_MB", "192")) * 1048576


def _cgroup_cpu_quota():
    """CPU quota in cores if this container's cgroup has one (i.e. we run in a limited pod), else None."""
    try:
        with open("/sys/fs/cgroup/cpu.max") as f:
            quota, period = f.read().split()
        if quota != "max":
            return int(quota) / int(period)
    except (OSError, ValueError):
        pass
    q = _cgroup_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")
    p = _cgroup_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
    if q and p and q > 0:
        return q / p
    return None


def _cpu_limit_cores():
    return _cgroup_cpu_quota() or float(os.getenv("CPU_LIMIT_CORES", "0.2"))


def _cpu_usage_seconds():
    # Without a quota the cgroup counters describe the whole host/container group, not this app: measure the process.
    if _cgroup_cpu_quota() is not None:
        try:
            with open("/sys/fs/cgroup/cpu.stat") as f:
                for line in f:
                    if line.startswith("usage_usec"):
                        return int(line.split()[1]) / 1e6
        except (OSError, ValueError):
            pass
        for p in ("/sys/fs/cgroup/cpuacct/cpuacct.usage", "/sys/fs/cgroup/cpu/cpuacct.usage"):
            v = _cgroup_read(p)
            if v:
                return v / 1e9
    return time.process_time()


def _cpu_cores():
    """Cores used since the previous sample (refreshed at most once per second)."""
    now = time.time()
    st = _cpu_state
    if now - st["t"] >= 1.0:
        usage = _cpu_usage_seconds()
        if st["t"]:
            st["cores"] = max(0.0, (usage - st["usage"]) / (now - st["t"]))
        st["t"], st["usage"] = now, usage
    return st["cores"]


def _burn_cpu():
    while time.time() < _chaos["cpu_until"]:
        sum(i * i for i in range(20000))         # busy work; the cgroup limit throttles it


def _hold_memory(percent):
    chunk = 4 * 1048576
    while time.time() < _chaos["mem_until"] and _mem_state()[0] < _mem_state()[1] * percent / 100.0:
        _ballast.append(bytearray(b"\x01") * chunk)     # writing touches every page
        time.sleep(0.02)
    while time.time() < _chaos["mem_until"]:
        time.sleep(0.5)
    _ballast.clear()
    gc.collect()


def _seconds():
    return min(max(float(request.args.get("seconds", 60)), 1), 900)


@app.post("/chaos/cpu")
def chaos_cpu():
    _chaos["cpu_until"] = time.time() + _seconds()
    threading.Thread(target=_burn_cpu, daemon=True).start()
    return jsonify(ok=True, fault="cpu", pod=socket.gethostname())


@app.post("/chaos/memory")
def chaos_memory():
    _chaos["mem_until"] = time.time() + _seconds()
    pct = min(max(float(request.args.get("percent", 93)), 10), 96)   # never reach 100%: avoid OOM kill
    threading.Thread(target=_hold_memory, args=(pct,), daemon=True).start()
    return jsonify(ok=True, fault="memory", percent=pct, pod=socket.gethostname())


@app.post("/chaos/errors")
def chaos_errors():
    _chaos["err_until"] = time.time() + _seconds()
    _chaos["err_rate"] = min(max(float(request.args.get("rate", 0.6)), 0.0), 1.0)
    return jsonify(ok=True, fault="errors", rate=_chaos["err_rate"], pod=socket.gethostname())


@app.post("/chaos/crash")
def chaos_crash():
    if os.getenv("ALLOW_CRASH") != "1":
        return jsonify(ok=False, error="crash endpoint disabled (set ALLOW_CRASH=1)"), 403
    # gunicorn's master is our parent: SIGTERM makes the container exit and kubelet restart it
    threading.Timer(0.5, lambda: os.kill(os.getppid(), signal.SIGTERM)).start()
    return jsonify(ok=True, fault="crash", pod=POD)


@app.post("/chaos/stop")
def chaos_stop():
    for k in ("cpu_until", "mem_until", "err_until"):
        _chaos[k] = 0.0
    return jsonify(ok=True)


@app.get("/chaos/status")
def chaos_status():
    now = time.time()
    return jsonify({k: max(0, round(_chaos[k] - now)) for k in ("cpu_until", "mem_until", "err_until")})


# ---------------------------------------------------------------- traffic
def _wants_html():
    return request.path == "/" and "text/html" in request.headers.get("Accept", "")


@app.before_request
def _maybe_fail():
    request._t0 = time.perf_counter()
    if request.path.startswith(INFRA) or _wants_html():
        return None
    if time.time() < _chaos["err_until"] and random.random() < _chaos["err_rate"]:
        return jsonify(error="injected failure", app=APP_NAME), 500
    return None


@app.after_request
def _record(resp):
    global _hist_sum, _hist_count
    resp.headers["X-Served-By"] = POD
    if request.path.startswith(INFRA) or _wants_html():
        return resp
    dt = time.perf_counter() - getattr(request, "_t0", time.perf_counter())
    with _lock:
        _events.append((time.time(), dt, resp.status_code))
        _requests[resp.status_code] = _requests.get(resp.status_code, 0) + 1
        _hist_sum += dt
        _hist_count += 1
        for i, b in enumerate(BUCKETS):
            if dt <= b:
                _hist[i] += 1
    return resp


@app.get("/")
def index():
    if _wants_html():
        page = _UI
        for k, v in {"__APP__": APP_NAME, "__ROLE__": ROLE, "__ACCENT__": ACCENT, "__POD__": POD, "__VERSION__": APP_VERSION}.items():
            page = page.replace(k, html.escape(v, quote=True))
        return page, 200, {"Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store"}
    time.sleep(max(0.0, random.gauss(BASE_LATENCY_MS, BASE_LATENCY_MS * 0.25)) / 1000)
    return jsonify(app=APP_NAME, pod=POD, ok=True)


@app.get("/api/stats")
def stats():
    now = time.time()
    with _lock:
        recent = [e for e in _events if now - e[0] <= 60]
        codes = dict(_requests)
    last10 = [e for e in recent if now - e[0] <= 10]
    errs = sum(1 for e in recent if e[2] >= 500)
    used, limit = _mem_state()
    cores, cpu_limit = _cpu_cores(), _cpu_limit_cores()
    active = {k: max(0, round(_chaos[k] - now)) for k in ("cpu_until", "mem_until", "err_until")}
    return jsonify(
        app=APP_NAME, role=ROLE, pod=POD, version=APP_VERSION, uptime_s=round(now - STARTED),
        cpu_pct=round(100 * cores / cpu_limit, 1) if cpu_limit else None, cpu_limit_cores=round(cpu_limit, 3),
        mem_pct=round(100 * used / limit, 1), mem_mib=round(used / 1048576, 1), mem_limit_mib=round(limit / 1048576),
        rps=round(len(last10) / 10, 2),
        avg_ms=round(1000 * sum(e[1] for e in recent) / len(recent), 1) if recent else None,
        err_pct=round(100 * errs / len(recent), 1) if recent else 0.0,
        total=sum(codes.values()), codes={str(k): v for k, v in sorted(codes.items())},
        faults={"cpu": active["cpu_until"], "memory": active["mem_until"], "errors": active["err_until"],
                "error_rate": _chaos["err_rate"] if active["err_until"] else 0},
        crash_enabled=os.getenv("ALLOW_CRASH") == "1")


@app.get("/healthz")
def healthz():
    return "ok"


@app.get("/metrics")
def metrics():
    lines = ["# TYPE http_requests_total counter"]
    with _lock:
        for code, n in sorted(_requests.items()):
            lines.append(f'http_requests_total{{code="{code}"}} {n}')
        lines.append("# TYPE http_request_duration_seconds histogram")
        cum = 0
        for b, n in zip(BUCKETS, _hist):
            cum += n
            lines.append(f'http_request_duration_seconds_bucket{{le="{b}"}} {cum}')
        lines.append(f'http_request_duration_seconds_bucket{{le="+Inf"}} {_hist_count}')
        lines.append(f"http_request_duration_seconds_sum {_hist_sum}")
        lines.append(f"http_request_duration_seconds_count {_hist_count}")
    return "\n".join(lines) + "\n", 200, {"Content-Type": "text/plain; version=0.0.4"}
