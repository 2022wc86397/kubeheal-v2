/* KubeShop storefront. Dependency-free; all prices come from the API (cents), the UI never computes totals itself. */
'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const money = c => new Intl.NumberFormat(undefined, {style: 'currency', currency: 'USD'}).format(c / 100);

const S = {products: [], categories: [], cat: '', q: '', cart: {}, quote: null, busy: false};
try { S.cart = JSON.parse(localStorage.getItem('ks-cart') || '{}'); } catch (_) { S.cart = {}; }
const saveCart = () => { try { localStorage.setItem('ks-cart', JSON.stringify(S.cart)); } catch (_) { /* private mode */ } };
const cartItems = () => Object.entries(S.cart).map(([id, qty]) => ({product_id: +id, qty}));
const cartCount = () => Object.values(S.cart).reduce((a, b) => a + b, 0);

/* ------------------------------------------------------------------ network */
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 3500); }

function health(ok, ms, headers) {
  $('#dot').className = 'dot ' + (ok ? 'ok' : 'bad');
  $('#health').textContent = ok ? `All systems normal · ${Math.round(ms)} ms` : 'We are having trouble reaching the shop';
  if (headers) {
    const f = headers.get('X-Frontend-Pod'), b = headers.get('X-Backend-Pod'), d = headers.get('X-DB-Pod');
    if (f) $('#chain').textContent = `web ${f.slice(-8)} → api ${(b || '–').slice(-8)} → db ${d ? d.slice(-8) : 'cache'}`;
  }
}

/* GET/POST JSON with up to 2 retries on 5xx / network errors (what a real storefront does during a blip). */
async function api(path, body, retries = 2) {
  for (let attempt = 0; ; attempt++) {
    const t0 = performance.now();
    try {
      const r = await fetch(path, body ? {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)} : {});
      const data = await r.json().catch(() => ({}));
      const ok = r.status < 500;
      health(ok, performance.now() - t0, r.headers);
      if (!ok && attempt < retries) { await new Promise(res => setTimeout(res, 400 * (attempt + 1))); continue; }
      return {status: r.status, ok: r.ok, data};
    } catch (_) {
      health(false, 0);
      if (attempt >= retries) return {status: 0, ok: false, data: {error: 'network', message: 'Network error'}};
      await new Promise(res => setTimeout(res, 400 * (attempt + 1)));
    }
  }
}

function banner(msg) { const b = $('#banner'); b.hidden = !msg; b.textContent = msg || ''; }

/* ------------------------------------------------------------------ catalogue */
async function loadProducts() {
  const qs = new URLSearchParams(); if (S.q) qs.set('q', S.q); if (S.cat) qs.set('category', S.cat);
  const r = await api('/api/products' + (qs.toString() ? '?' + qs : ''));
  if (!r.ok) { banner('Our catalogue is temporarily unavailable. We are working on it; this page retries automatically.'); if (!S.products.length) $('#grid').innerHTML = '<div class="empty">Products are unavailable right now.</div>'; return; }
  banner('');
  S.products = r.data.products; S.categories = r.data.categories || S.categories;
  renderChips(); renderGrid();
}

function renderChips() {
  $('#chips').innerHTML = ['All', ...S.categories].map(c => `<button class="chip" aria-pressed="${(c === 'All' ? '' : c) === S.cat}" data-c="${c === 'All' ? '' : esc(c)}">${esc(c)}</button>`).join('');
}

function renderGrid() {
  $('#grid').innerHTML = S.products.length ? S.products.map(p => `<article class="card prod" style="--c:${esc(p.color)}">
      <div class="thumb" aria-hidden="true">${esc(p.emoji)}</div>
      <div class="pbody"><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p>
        <div class="pfoot"><span class="price">${money(p.price_cents)}</span>${p.stock < 25 ? `<span class="stock">Only ${p.stock} left</span>` : ''}</div>
        <button class="btn" data-add="${p.id}" ${p.stock < 1 ? 'disabled' : ''}>${p.stock < 1 ? 'Sold out' : 'Add to cart'}</button></div></article>`).join('')
    : '<div class="empty">No products match your search.</div>';
}

/* ------------------------------------------------------------------ cart */
function openCart(open) { $('#drawer').classList.toggle('open', open); $('#drawer').setAttribute('aria-hidden', !open); $('#scrim').hidden = !open; if (open) refreshQuote(); }
function renderCartCount() { $('#cartCount').textContent = cartCount(); }
function add(id, d = 1) {
  S.cart[id] = Math.max(0, Math.min(20, (S.cart[id] || 0) + d)); if (!S.cart[id]) delete S.cart[id];
  saveCart(); renderCartCount(); if ($('#drawer').classList.contains('open')) refreshQuote();
}

let quoteT;
function refreshQuote() { clearTimeout(quoteT); quoteT = setTimeout(doQuote, 120); }
async function doQuote() {
  if (!cartCount()) { S.quote = null; renderCart(); return; }
  const r = await api('/api/quote', {items: cartItems()});
  if (r.ok) { S.quote = r.data; renderCart(); }
  else if (r.status === 404 || r.status === 400) { S.cart = {}; saveCart(); renderCartCount(); S.quote = null; renderCart(); toast('Your cart was updated.'); }
  else { $('#totals').innerHTML = '<div class="msg">We could not price your cart right now. Please retry in a moment.</div>'; $('#checkoutBtn').disabled = true; }
}
function renderCart() {
  const q = S.quote, empty = !q || !q.lines.length;
  $('#lines').innerHTML = empty ? '<p class="empty">Your cart is empty.</p>' : q.lines.map(l => `<div class="line"><div class="em">${esc(l.emoji)}</div>
      <div><strong>${esc(l.name)}</strong><div class="qty"><button data-dec="${l.product_id}" aria-label="Fewer ${esc(l.name)}">−</button>${l.qty}<button data-inc="${l.product_id}" aria-label="More ${esc(l.name)}">+</button></div></div>
      <div>${money(l.line_cents)}</div></div>`).join('');
  $('#totals').innerHTML = empty ? '' : `${q.free_shipping_remaining_cents ? `<div class="hint">Add ${money(q.free_shipping_remaining_cents)} more for free shipping</div>` : '<div class="hint ok-badge">You have free shipping 🎉</div>'}
    <div class="meter"><i style="width:${Math.min(100, 100 * q.subtotal_cents / 5000)}%"></i></div>
    <div><span>Subtotal</span><span>${money(q.subtotal_cents)}</span></div><div><span>Shipping</span><span>${q.shipping_cents ? money(q.shipping_cents) : 'Free'}</span></div>
    <div><span>Tax</span><span>${money(q.tax_cents)}</span></div><div class="grand"><span>Total</span><span>${money(q.total_cents)}</span></div>`;
  $('#checkoutBtn').disabled = empty;
}

/* ------------------------------------------------------------------ checkout */
function payMessage(m) { const e = $('#payMsg'); e.hidden = !m; e.textContent = m || ''; }
async function pay(ev) {
  ev.preventDefault();
  if (S.busy) return;
  S.busy = true; $('#payBtn').disabled = true; payMessage('');
  const f = new FormData($('#payForm'));
  const r = await api('/api/checkout', {name: f.get('name'), email: f.get('email'), card: f.get('card'), items: cartItems()}, 1);
  S.busy = false; $('#payBtn').disabled = false;
  if (r.status === 201) {
    S.cart = {}; saveCart(); renderCartCount(); S.quote = null; renderCart(); $('#checkout').close(); openCart(false);
    $('#doneBody').innerHTML = `<h2>Thank you! 🎉</h2><p><span class="ok-badge">Order confirmed</span></p>
      <p style="margin-top:10px">Your order number is <strong id="oid">${esc(r.data.order_id)}</strong>. We charged ${money(r.data.total_cents)} to the card ending ${esc(r.data.card_last4)}.</p>
      <table class="ordertbl">${r.data.lines.map(l => `<tr><td>${esc(l.emoji)} ${esc(l.name)} × ${l.qty}</td><td align="right">${money(l.line_cents)}</td></tr>`).join('')}</table>`;
    $('#done').showModal(); loadProducts(); return;
  }
  const d = r.data || {};
  payMessage(r.status === 402 ? 'Your bank declined this payment. Try a different card.'
    : r.status === 409 ? `Sorry, an item just sold out${d.available != null ? ` (only ${d.available} left)` : ''}. Please adjust your cart.`
    : r.status >= 500 || r.status === 0 ? 'Our systems are very busy right now, and your card was not charged. Please try again in a moment.'
    : (d.message || 'Please check your details and try again.'));
}

/* ------------------------------------------------------------------ order tracking */
async function track(ev) {
  ev.preventDefault();
  const id = $('#trackId').value.trim(), out = $('#trackOut');
  if (!id) return;
  const r = await api('/api/orders/' + encodeURIComponent(id));
  out.innerHTML = r.ok ? `<p style="margin-top:10px"><span class="ok-badge">${esc(r.data.status)}</span> Order <strong>${esc(r.data.id)}</strong> · ${money(r.data.total_cents)}</p>
      <table class="ordertbl">${r.data.items.map(i => `<tr><td>${esc(i.emoji)} ${esc(i.name)} × ${i.qty}</td><td align="right">${money(i.qty * i.unit_cents)}</td></tr>`).join('')}</table>`
    : `<div class="msg">${esc(r.data.message || (r.status === 404 ? 'We could not find that order.' : 'Order lookup is unavailable right now.'))}</div>`;
}

/* ------------------------------------------------------------------ wiring */
document.addEventListener('click', e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.add) { add(+t.dataset.add); toast('Added to cart'); }
  else if (t.dataset.inc) add(+t.dataset.inc, 1);
  else if (t.dataset.dec) add(+t.dataset.dec, -1);
  else if (t.dataset.c !== undefined && t.classList.contains('chip')) { S.cat = t.dataset.c; loadProducts(); }
});
$('#cartBtn').onclick = () => openCart(true);
$('#closeCart').onclick = $('#scrim').onclick = () => openCart(false);
$('#checkoutBtn').onclick = () => { payMessage(''); $('#payTotal').textContent = S.quote ? money(S.quote.total_cents) : ''; $('#checkout').showModal(); };
$('#payCancel').onclick = () => $('#checkout').close();
$('#payForm').addEventListener('submit', pay);
$('#doneClose').onclick = () => $('#done').close();
$('#trackForm').addEventListener('submit', track);
let searchT;
$('#q').addEventListener('input', e => { clearTimeout(searchT); searchT = setTimeout(() => { S.q = e.target.value.trim(); loadProducts(); }, 250); });
$('#searchForm').addEventListener('submit', e => e.preventDefault());
document.addEventListener('keydown', e => { if (e.key === 'Escape') openCart(false); });

renderCartCount();
loadProducts();
setInterval(() => { if (document.visibilityState === 'visible' && !S.q) loadProducts(); }, 15000);   // picks up stock changes and recovers by itself after an outage
