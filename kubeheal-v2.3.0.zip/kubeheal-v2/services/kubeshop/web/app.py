"""KubeShop storefront: the customer-facing web app. Serves the single-page shop and proxies /api to the shop API."""
import os
import re

import requests
from flask import Flask, Response, jsonify, request, send_from_directory

from common.obs import POD, Obs

BACKEND_URL = os.getenv("BACKEND_URL", "http://backend").rstrip("/")
SAFE_PATH = re.compile(r"^[A-Za-z0-9_\-/]{0,64}$")

app = Flask(__name__, static_folder="static", static_url_path="/static")
# Fault injection hits API calls (the page shell keeps loading, like a real partial outage)
Obs(app, "frontend", error_prefixes=("/api/",))
http = requests.Session()


@app.get("/")
def index():
    resp = send_from_directory(app.static_folder, "index.html")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.route("/api/<path:path>", methods=["GET", "POST"])
def api(path):
    if not SAFE_PATH.match(path):                       # never let a request choose where we connect
        return jsonify(error="not_found"), 404
    try:
        r = http.request(request.method, f"{BACKEND_URL}/api/{path}", params=request.args,
                         data=request.get_data() if request.method == "POST" else None,
                         headers={"Content-Type": request.headers.get("Content-Type", "application/json")},
                         timeout=(1.5, 8), allow_redirects=False)
    except requests.RequestException:
        return jsonify(error="backend_unavailable", message="The shop is having trouble. Please retry."), 502
    resp = Response(r.content, r.status_code, mimetype=r.headers.get("Content-Type", "application/json").split(";")[0])
    resp.headers["X-Frontend-Pod"] = POD
    resp.headers["X-Backend-Pod"] = r.headers.get("X-Served-By", "")
    resp.headers["X-DB-Pod"] = r.headers.get("X-DB-Pod", "")
    resp.headers["Cache-Control"] = "no-store"
    return resp
