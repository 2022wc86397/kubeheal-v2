"""KubeShop database service: the system of record for products, stock and orders.

SQLite (WAL mode) on a volume behind a small HTTP API. Stock is decremented inside one IMMEDIATE transaction, so
concurrent checkouts can never oversell. Only the shop API talks to this service.
"""
import os
import secrets
import sqlite3
import threading
import time

from flask import Flask, jsonify, request

from common.obs import Obs

DB_PATH = os.getenv("DB_PATH", "/data/shop.db")
RESTOCK_SECONDS = float(os.getenv("RESTOCK_SECONDS", "60"))
RESTOCK_TO = int(os.getenv("RESTOCK_TO", "120"))

app = Flask(__name__)
Obs(app, "database")

SEED = [  # sku, name, category, description, price_cents, stock, emoji, colour
    ("HP-100", "Wireless Headphones", "Electronics", "Noise-cancelling over-ear headphones, 30 h battery.", 7999, 200, "🎧", "#6d5dfc"),
    ("SW-200", "Smart Watch", "Electronics", "Heart-rate, GPS and a week of battery life.", 12900, 150, "⌚", "#1f9d8b"),
    ("KB-300", "Mechanical Keyboard", "Electronics", "Hot-swappable switches, aluminium frame.", 8950, 180, "⌨️", "#3b82f6"),
    ("EM-400", "Espresso Maker", "Home", "15-bar pump with a milk frother.", 14900, 120, "☕", "#b45309"),
    ("DL-500", "Desk Lamp", "Home", "Dimmable LED lamp with wireless charging base.", 3490, 220, "💡", "#eab308"),
    ("MG-600", "Ceramic Mug Set", "Home", "Set of four hand-glazed mugs.", 2400, 260, "🍵", "#10b981"),
    ("RS-700", "Running Shoes", "Fashion", "Lightweight, breathable trainers.", 9900, 160, "👟", "#ef4444"),
    ("DJ-800", "Denim Jacket", "Fashion", "Classic fit, washed indigo denim.", 7400, 140, "🧥", "#2563eb"),
    ("BP-900", "Canvas Backpack", "Fashion", "20 L water-resistant daypack.", 5900, 200, "🎒", "#92400e"),
    ("YM-110", "Yoga Mat", "Sports", "6 mm non-slip eco foam mat.", 2999, 240, "🧘", "#8b5cf6"),
    ("WB-120", "Water Bottle", "Sports", "Insulated steel bottle, keeps cold 24 h.", 1850, 300, "🍶", "#0ea5e9"),
    ("BK-130", "Paperback Bundle", "Books", "Five bestselling paperbacks.", 2100, 170, "📚", "#db2777"),
]


def conn():
    c = sqlite3.connect(DB_PATH, timeout=5, isolation_level=None)   # autocommit: we manage transactions explicitly
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout=5000")
    return c


def init():
    os.makedirs(os.path.dirname(os.path.abspath(DB_PATH)), exist_ok=True)
    c = conn()
    c.execute("PRAGMA journal_mode=WAL")
    c.executescript("""
      CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, sku TEXT UNIQUE, name TEXT, category TEXT,
        description TEXT, price_cents INTEGER, stock INTEGER, emoji TEXT, color TEXT);
      CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY, name TEXT, email TEXT, total_cents INTEGER,
        status TEXT, created_at REAL);
      CREATE TABLE IF NOT EXISTS order_items(order_id TEXT, product_id INTEGER, qty INTEGER, unit_cents INTEGER);
    """)
    if c.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        c.executemany("INSERT INTO products(sku,name,category,description,price_cents,stock,emoji,color) "
                      "VALUES(?,?,?,?,?,?,?,?)", SEED)
    c.close()


def _restock_loop():
    """The 'warehouse': keeps a long demo from selling the shop empty."""
    while True:
        time.sleep(RESTOCK_SECONDS)
        try:
            c = conn()
            c.execute("UPDATE products SET stock=? WHERE stock<?", (RESTOCK_TO, RESTOCK_TO // 3))
            c.close()
        except sqlite3.Error:
            pass


init()
if os.getenv("AUTO_RESTOCK", "1") == "1":
    threading.Thread(target=_restock_loop, daemon=True, name="restock").start()


def product_out(r):
    return {k: r[k] for k in ("id", "sku", "name", "category", "description", "price_cents", "stock", "emoji", "color")}


@app.get("/")
def info():
    c = conn()
    n = c.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    o = c.execute("SELECT COUNT(*), COALESCE(SUM(total_cents),0) FROM orders").fetchone()
    c.close()
    return jsonify(service="database", engine="sqlite", products=n, orders=o[0], revenue_cents=o[1])


@app.get("/products")
def products():
    q, cat = request.args.get("q", "").strip(), request.args.get("category", "").strip()
    sql, args = "SELECT * FROM products WHERE 1=1", []
    if q:
        sql += " AND (name LIKE ? OR description LIKE ?)"
        args += [f"%{q}%", f"%{q}%"]
    if cat:
        sql += " AND category=?"
        args.append(cat)
    c = conn()
    rows = c.execute(sql + " ORDER BY id", args).fetchall()
    c.close()
    return jsonify([product_out(r) for r in rows])


@app.get("/products/<int:pid>")
def product(pid):
    c = conn()
    r = c.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    c.close()
    return (jsonify(product_out(r)) if r else (jsonify(error="not_found"), 404))


@app.post("/orders")
def create_order():
    d = request.get_json(silent=True) or {}
    items = d.get("items")
    if not isinstance(items, list) or not 0 < len(items) <= 20:
        return jsonify(error="invalid_items"), 400
    merged = {}
    for it in items:
        try:
            pid, qty = int(it["product_id"]), int(it["qty"])
        except (KeyError, TypeError, ValueError):
            return jsonify(error="invalid_items"), 400
        if not 0 < qty <= 20:
            return jsonify(error="invalid_quantity"), 400
        merged[pid] = merged.get(pid, 0) + qty
    c = conn()
    try:
        c.execute("BEGIN IMMEDIATE")                     # take the write lock first: checks and decrements are atomic
        total, lines = 0, []
        for pid, qty in merged.items():
            r = c.execute("SELECT id, price_cents, stock FROM products WHERE id=?", (pid,)).fetchone()
            if not r:
                c.execute("ROLLBACK")
                return jsonify(error="unknown_product", product_id=pid), 404
            if r["stock"] < qty:
                c.execute("ROLLBACK")
                return jsonify(error="out_of_stock", product_id=pid, available=r["stock"]), 409
            c.execute("UPDATE products SET stock=stock-? WHERE id=?", (qty, pid))
            lines.append((pid, qty, r["price_cents"]))
            total += qty * r["price_cents"]
        total += int(d.get("extra_cents", 0))            # shipping + tax computed by the API
        oid = "ORD-" + secrets.token_hex(4).upper()
        c.execute("INSERT INTO orders VALUES(?,?,?,?,?,?)",
                  (oid, str(d.get("name", ""))[:80], str(d.get("email", ""))[:120], total, "confirmed", time.time()))
        c.executemany("INSERT INTO order_items VALUES(?,?,?,?)", [(oid, p, q, u) for p, q, u in lines])
        c.execute("COMMIT")
    except sqlite3.Error as exc:
        try:
            c.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        return jsonify(error="database_error", detail=str(exc)), 503
    finally:
        c.close()
    return jsonify(order_id=oid, total_cents=total, status="confirmed"), 201


@app.get("/orders/<oid>")
def order(oid):
    c = conn()
    o = c.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
    if not o:
        c.close()
        return jsonify(error="not_found"), 404
    items = c.execute("SELECT p.name, p.emoji, i.qty, i.unit_cents FROM order_items i JOIN products p ON p.id=i.product_id "
                      "WHERE i.order_id=?", (oid,)).fetchall()
    c.close()
    return jsonify(id=o["id"], name=o["name"], status=o["status"], total_cents=o["total_cents"], created_at=o["created_at"],
                   items=[dict(i) for i in items])
