"""Shared observability and fault injection for the KubeShop services.

Every service gets, from one call to Obs(app, name):
  GET  /healthz                 liveness/readiness (never affected by faults)
  GET  /metrics                 Prometheus text: http_requests_total{code}, http_request_duration_seconds
  POST /chaos/cpu|memory|errors|stop|crash, GET /chaos/status
                                fault injection used by KubeGuard's Experiments. The endpoints are PUBLIC-FACING on
                                the storefront, so they require the X-Chaos-Token header (env CHAOS_TOKEN) and are
                                disabled (403) when no token is configured.
"""
import gc
import hmac
import os
import random
import signal
import socket
import threading
import time

from flask import jsonify, request

POD = socket.gethostname()
BUCKETS = (0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0)
INFRA = ("/healthz", "/metrics", "/chaos")
UNLIMITED = 2 ** 50


def _cgroup_read(*paths):
    for p in paths:
        try:
            with open(p) as f:
                v = f.read().strip()
            if v and v != "max":
                return int(v)
        except (OSError, ValueError):
            continue
    return None


def mem_state():
    """(used_bytes, limit_bytes): container cgroup when it has a limit, else process RSS (local runs)."""
    lim = _cgroup_read("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes")
    cur = _cgroup_read("/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory/memory.usage_in_bytes")
    if lim and cur and lim < UNLIMITED:
        return cur, lim
    rss = 0
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    rss = int(line.split()[1]) * 1024
    except OSError:
        pass
    return rss, int(os.getenv("MEM_LIMIT_MB", "192")) * 1048576


class Obs:
    def __init__(self, app, name, error_prefixes=("/",)):
        self.app, self.name, self.error_prefixes = app, name, tuple(error_prefixes)
        self._lock = threading.Lock()
        self._codes, self._hist, self._sum, self._count = {}, [0] * len(BUCKETS), 0.0, 0
        self.chaos = {"cpu": 0.0, "mem": 0.0, "err": 0.0, "rate": 0.0}
        self._ballast = []
        app.before_request(self._before)
        app.after_request(self._after)
        app.add_url_rule("/healthz", "healthz", lambda: "ok")
        app.add_url_rule("/metrics", "metrics", self._metrics)
        for kind in ("cpu", "memory", "errors", "stop", "crash"):
            app.add_url_rule(f"/chaos/{kind}", f"chaos_{kind}", getattr(self, f"_chaos_{kind}"), methods=["POST"])
        app.add_url_rule("/chaos/status", "chaos_status", self._chaos_status)

    # ------------------------------------------------------------- request hooks
    def _before(self):
        request._t0 = time.perf_counter()
        if request.path.startswith("/chaos"):
            token = os.getenv("CHAOS_TOKEN", "")
            if not token or not hmac.compare_digest(request.headers.get("X-Chaos-Token", ""), token):
                return jsonify(error="chaos endpoints need a valid X-Chaos-Token"), 403
            return None
        if request.path.startswith(INFRA):
            return None
        if (time.time() < self.chaos["err"] and random.random() < self.chaos["rate"]
                and any(request.path.startswith(p) for p in self.error_prefixes)):
            return jsonify(error="injected failure", service=self.name), 500
        return None

    def _after(self, resp):
        resp.headers["X-Served-By"] = POD
        if request.path.startswith(INFRA):
            return resp
        dt = time.perf_counter() - getattr(request, "_t0", time.perf_counter())
        with self._lock:
            self._codes[resp.status_code] = self._codes.get(resp.status_code, 0) + 1
            self._sum += dt
            self._count += 1
            for i, b in enumerate(BUCKETS):
                if dt <= b:
                    self._hist[i] += 1
        return resp

    def _metrics(self):
        lines = ["# TYPE http_requests_total counter"]
        with self._lock:
            for code, n in sorted(self._codes.items()):
                lines.append(f'http_requests_total{{code="{code}"}} {n}')
            lines.append("# TYPE http_request_duration_seconds histogram")
            cum = 0
            for b, n in zip(BUCKETS, self._hist):
                cum += n
                lines.append(f'http_request_duration_seconds_bucket{{le="{b}"}} {cum}')
            lines.append(f'http_request_duration_seconds_bucket{{le="+Inf"}} {self._count}')
            lines.append(f"http_request_duration_seconds_sum {self._sum}")
            lines.append(f"http_request_duration_seconds_count {self._count}")
        return "\n".join(lines) + "\n", 200, {"Content-Type": "text/plain; version=0.0.4"}

    # ------------------------------------------------------------------- faults
    @staticmethod
    def _seconds():
        return min(max(float(request.args.get("seconds", 60)), 1), 900)

    def _chaos_cpu(self):
        self.chaos["cpu"] = time.time() + self._seconds()
        threading.Thread(target=self._burn, daemon=True).start()
        return jsonify(ok=True, fault="cpu", pod=POD, service=self.name)

    def _burn(self):
        while time.time() < self.chaos["cpu"]:
            sum(i * i for i in range(20000))          # the cgroup CPU limit throttles this

    def _chaos_memory(self):
        self.chaos["mem"] = time.time() + self._seconds()
        pct = min(max(float(request.args.get("percent", 93)), 10), 96)     # never reach 100%: avoid an OOM kill
        threading.Thread(target=self._hold, args=(pct,), daemon=True).start()
        return jsonify(ok=True, fault="memory", percent=pct, pod=POD, service=self.name)

    def _hold(self, pct):
        chunk = 4 * 1048576
        while time.time() < self.chaos["mem"] and mem_state()[0] < mem_state()[1] * pct / 100.0:
            self._ballast.append(bytearray(b"\x01") * chunk)               # writing touches every page
            time.sleep(0.02)
        while time.time() < self.chaos["mem"]:
            time.sleep(0.5)
        self._ballast.clear()
        gc.collect()

    def _chaos_errors(self):
        self.chaos["err"] = time.time() + self._seconds()
        self.chaos["rate"] = min(max(float(request.args.get("rate", 0.6)), 0.0), 1.0)
        return jsonify(ok=True, fault="errors", rate=self.chaos["rate"], pod=POD, service=self.name)

    def _chaos_stop(self):
        for k in ("cpu", "mem", "err"):
            self.chaos[k] = 0.0
        return jsonify(ok=True)

    def _chaos_crash(self):
        if os.getenv("ALLOW_CRASH") != "1":
            return jsonify(ok=False, error="crash endpoint disabled (set ALLOW_CRASH=1)"), 403
        # gunicorn's master is our parent: SIGTERM makes the container exit and kubelet restart it
        threading.Timer(0.5, lambda: os.kill(os.getppid(), signal.SIGTERM)).start()
        return jsonify(ok=True, fault="crash", pod=POD)

    def _chaos_status(self):
        now = time.time()
        return jsonify({k: max(0, round(v - now)) for k, v in self.chaos.items() if k != "rate"})
