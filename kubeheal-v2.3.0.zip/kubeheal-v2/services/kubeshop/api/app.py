"""KubeShop API: catalogue, price quotes, checkout and order lookup. Persists everything via the database service."""
import os
import random
import re
import threading
import time

import requests
from flask import Flask, g, jsonify, request

from common.obs import Obs

DB_URL = os.getenv("DB_URL", "http://database").rstrip("/")
CACHE_TTL = float(os.getenv("CACHE_TTL", "10"))
FREE_SHIPPING_CENTS, SHIPPING_CENTS, TAX_RATE = 5000, 499, 0.08
DECLINED_CARDS = {"4000000000000002"}                      # the usual "card declined" test number
EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

app = Flask(__name__)
Obs(app, "backend")
http = requests.Session()
_cache = {"t": 0.0, "items": None}
_cache_lock = threading.Lock()


class DbDown(Exception):
    pass


def db(method, path, **kw):
    try:
        r = http.request(method, DB_URL + path, timeout=(1.5, 4), **kw)
    except requests.RequestException as exc:
        raise DbDown(str(exc))
    if r.status_code >= 500:
        raise DbDown(f"database answered {r.status_code}")
    g.db_pod = r.headers.get("X-Served-By", "")
    return r


@app.errorhandler(DbDown)
def db_down(_):
    return jsonify(error="database_unavailable", message="We could not reach our database. Please retry."), 503


@app.after_request
def trace(resp):
    if getattr(g, "db_pod", ""):
        resp.headers["X-DB-Pod"] = g.db_pod
    return resp


def catalogue():
    """Whole catalogue, cached for CACHE_TTL seconds (keeps browse traffic off the database)."""
    with _cache_lock:
        if _cache["items"] is not None and time.time() - _cache["t"] < CACHE_TTL:
            return _cache["items"]
    items = db("GET", "/products").json()
    with _cache_lock:
        _cache.update(t=time.time(), items=items)
    return items


def luhn_ok(number):
    total = 0
    for i, ch in enumerate(reversed(number)):
        d = int(ch)
        if i % 2:
            d = d * 2 - 9 if d * 2 > 9 else d * 2
        total += d
    return total % 10 == 0


def price(raw_items):
    """Validate a cart and price it. Returns (quote, error_response)."""
    if not isinstance(raw_items, list) or not 0 < len(raw_items) <= 20:
        return None, (jsonify(error="invalid_items", message="Your cart is empty or too large."), 400)
    by_id = {p["id"]: p for p in catalogue()}
    merged = {}
    for it in raw_items:
        try:
            pid, qty = int(it["product_id"]), int(it["qty"])
        except (KeyError, TypeError, ValueError):
            return None, (jsonify(error="invalid_items", message="Malformed cart line."), 400)
        if not 0 < qty <= 20:
            return None, (jsonify(error="invalid_quantity", message="Quantity must be between 1 and 20."), 400)
        if pid not in by_id:
            return None, (jsonify(error="unknown_product", product_id=pid), 404)
        merged[pid] = merged.get(pid, 0) + qty
    lines = [{"product_id": pid, "name": by_id[pid]["name"], "emoji": by_id[pid]["emoji"], "qty": q,
              "unit_cents": by_id[pid]["price_cents"], "line_cents": q * by_id[pid]["price_cents"]} for pid, q in merged.items()]
    subtotal = sum(l["line_cents"] for l in lines)
    shipping = 0 if subtotal >= FREE_SHIPPING_CENTS else SHIPPING_CENTS
    tax = round(subtotal * TAX_RATE)
    return {"lines": lines, "subtotal_cents": subtotal, "shipping_cents": shipping, "tax_cents": tax,
            "total_cents": subtotal + shipping + tax,
            "free_shipping_remaining_cents": max(0, FREE_SHIPPING_CENTS - subtotal)}, None


@app.get("/")
def info():
    return jsonify(service="backend", api="/api", database=DB_URL)


@app.get("/api/products")
def products():
    q, cat = request.args.get("q", "").strip().lower(), request.args.get("category", "").strip()
    items = [p for p in catalogue()
             if (not cat or p["category"] == cat) and (not q or q in p["name"].lower() or q in p["description"].lower())]
    return jsonify(products=items, categories=sorted({p["category"] for p in catalogue()}))


@app.get("/api/products/<int:pid>")
def product(pid):
    p = next((p for p in catalogue() if p["id"] == pid), None)
    return jsonify(p) if p else (jsonify(error="not_found"), 404)


@app.post("/api/quote")
def quote():
    q, err = price((request.get_json(silent=True) or {}).get("items"))
    return err if err else jsonify(q)


@app.post("/api/checkout")
def checkout():
    d = request.get_json(silent=True) or {}
    name, email = str(d.get("name", "")).strip(), str(d.get("email", "")).strip()
    card = re.sub(r"[ -]", "", str(d.get("card", "")))
    if not 2 <= len(name) <= 80:
        return jsonify(error="invalid_name", message="Please enter your name."), 400
    if not EMAIL.match(email):
        return jsonify(error="invalid_email", message="Please enter a valid email address."), 400
    if not (card.isdigit() and 13 <= len(card) <= 19 and luhn_ok(card)):
        return jsonify(error="invalid_card", message="That card number is not valid."), 400
    q, err = price(d.get("items"))
    if err:
        return err
    time.sleep(random.uniform(0.03, 0.08))                               # payment provider round-trip
    if card in DECLINED_CARDS:
        return jsonify(error="payment_declined", message="Your bank declined the payment."), 402
    r = db("POST", "/orders", json={"name": name, "email": email, "items": [
        {"product_id": l["product_id"], "qty": l["qty"]} for l in q["lines"]],
        "extra_cents": q["shipping_cents"] + q["tax_cents"]})
    if r.status_code != 201:
        return (jsonify(r.json()), r.status_code)                        # e.g. 409 out_of_stock
    with _cache_lock:
        _cache["t"] = 0.0                                                # stock changed: refresh the catalogue
    order = r.json()
    return jsonify(order_id=order["order_id"], status=order["status"], total_cents=order["total_cents"],
                   card_last4=card[-4:], lines=q["lines"]), 201


@app.get("/api/orders/<oid>")
def order(oid):
    if not re.fullmatch(r"ORD-[0-9A-F]{8}", oid.upper()):
        return jsonify(error="invalid_order_id", message="Order numbers look like ORD-1A2B3C4D."), 400
    r = db("GET", f"/orders/{oid.upper()}")
    return (jsonify(r.json()), r.status_code)
