"""Fixtures that start the three KubeShop services as real HTTP servers (threads) wired together."""
import importlib.util
import os
import sys
import threading

import pytest
import requests
from werkzeug.serving import make_server

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
TOKEN = "test-chaos-token"


def load(name, rel):
    """Import a service module fresh (all three are called app.py) so env vars are read at import time."""
    spec = importlib.util.spec_from_file_location(name, os.path.join(ROOT, rel))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


class Server:
    def __init__(self, app):
        self.srv = make_server("127.0.0.1", 0, app, threaded=True)
        self.url = f"http://127.0.0.1:{self.srv.server_port}"
        self.thread = threading.Thread(target=self.srv.serve_forever, daemon=True)
        self.thread.start()

    def stop(self):
        self.srv.shutdown()


class Stack:
    def __init__(self, tmp_path, monkeypatch, cache_ttl="10"):
        monkeypatch.setenv("DB_PATH", str(tmp_path / "shop.db"))
        monkeypatch.setenv("AUTO_RESTOCK", "0")
        monkeypatch.setenv("CHAOS_TOKEN", TOKEN)
        monkeypatch.setenv("CACHE_TTL", cache_ttl)
        self.db_mod = load("shop_db", "db/app.py")
        self.db = Server(self.db_mod.app)
        monkeypatch.setenv("DB_URL", self.db.url)
        self.api_mod = load("shop_api", "api/app.py")
        self.api = Server(self.api_mod.app)
        monkeypatch.setenv("BACKEND_URL", self.api.url)
        self.web_mod = load("shop_web", "web/app.py")
        self.web = Server(self.web_mod.app)

    def chaos(self, svc, kind, **params):
        return requests.post(f"{getattr(self, svc).url}/chaos/{kind}", params=params, headers={"X-Chaos-Token": TOKEN}, timeout=5)

    def stop(self):
        for s in (self.web, self.api, self.db):
            try:
                s.stop()
            except Exception:
                pass


@pytest.fixture
def stack(tmp_path, monkeypatch):
    s = Stack(tmp_path, monkeypatch)
    yield s
    s.stop()


@pytest.fixture
def stack_nocache(tmp_path, monkeypatch):
    s = Stack(tmp_path, monkeypatch, cache_ttl="0")
    yield s
    s.stop()


GOOD = {"name": "Alex Morgan", "email": "alex@example.com", "card": "4242 4242 4242 4242"}
