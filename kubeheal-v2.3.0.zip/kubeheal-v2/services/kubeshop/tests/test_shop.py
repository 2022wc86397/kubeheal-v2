import os
import random
import re
import sys
import shutil
import subprocess
import threading

import pytest
import requests

from conftest import GOOD, ROOT, TOKEN, load

H = {"X-Chaos-Token": TOKEN}


def get(s, path, **kw):
    return requests.get(s.web.url + path, timeout=8, **kw)


def post(s, path, body):
    return requests.post(s.web.url + path, json=body, timeout=8)


def stock(s, pid):
    return requests.get(f"{s.db.url}/products/{pid}", timeout=5).json()["stock"]


# ----------------------------------------------------------------- the shop works end to end
def test_storefront_serves_the_shop_and_catalogue(stack):
    page = get(stack, "/")
    assert page.status_code == 200 and "KubeShop" in page.text and "/static/app.js" in page.text
    assert get(stack, "/static/app.js").status_code == 200 and get(stack, "/static/style.css").status_code == 200
    d = get(stack, "/api/products").json()
    assert len(d["products"]) == 12 and d["categories"] == ["Books", "Electronics", "Fashion", "Home", "Sports"]
    assert get(stack, "/api/products?category=Home").json()["products"][0]["category"] == "Home"
    assert {p["name"] for p in get(stack, "/api/products?q=watch").json()["products"]} == {"Smart Watch"}
    assert get(stack, "/api/products/1").json()["name"] == "Wireless Headphones"
    assert get(stack, "/api/products/999").status_code == 404


def test_quote_shipping_and_tax(stack):
    q = post(stack, "/api/quote", {"items": [{"product_id": 11, "qty": 1}]}).json()      # water bottle $18.50
    assert (q["subtotal_cents"], q["shipping_cents"], q["tax_cents"], q["total_cents"]) == (1850, 499, 148, 2497)
    assert q["free_shipping_remaining_cents"] == 3150
    q = post(stack, "/api/quote", {"items": [{"product_id": 4, "qty": 1}, {"product_id": 4, "qty": 1}]}).json()  # merged qty 2
    assert q["lines"][0]["qty"] == 2 and q["shipping_cents"] == 0 and q["total_cents"] == 29800 + 2384


def test_checkout_places_order_decrements_stock_and_can_be_tracked(stack):
    before = stock(stack, 1)
    r = post(stack, "/api/checkout", {**GOOD, "items": [{"product_id": 1, "qty": 2}]})
    assert r.status_code == 201, r.text
    o = r.json()
    assert re.fullmatch(r"ORD-[0-9A-F]{8}", o["order_id"]) and o["card_last4"] == "4242" and o["status"] == "confirmed"
    assert "4242 4242" not in r.text                                           # never echo the card number
    assert o["total_cents"] == 2 * 7999 + 0 + round(2 * 7999 * 0.08)
    assert stock(stack, 1) == before - 2
    t = get(stack, f"/api/orders/{o['order_id']}").json()
    assert t["total_cents"] == o["total_cents"] and t["items"][0]["name"] == "Wireless Headphones"
    assert get(stack, "/api/orders/ORD-00000000").status_code == 404
    assert get(stack, "/api/orders/not-an-order").status_code == 400


def test_checkout_validation(stack):
    item = [{"product_id": 1, "qty": 1}]
    bad = {"name": ("A", "invalid_name"), "email": ("nope", "invalid_email"), "card": ("4242 4242 4242 4241", "invalid_card")}
    for field, (val, err) in bad.items():
        r = post(stack, "/api/checkout", {**GOOD, field: val, "items": item})
        assert r.status_code == 400 and r.json()["error"] == err, field
    assert post(stack, "/api/checkout", {**GOOD, "items": []}).status_code == 400
    assert post(stack, "/api/checkout", {**GOOD, "items": [{"product_id": 1, "qty": 21}]}).status_code == 400
    assert post(stack, "/api/checkout", {**GOOD, "items": [{"product_id": 999, "qty": 1}]}).status_code == 404
    assert post(stack, "/api/quote", {"items": "x"}).status_code == 400


def test_declined_card_charges_nothing_and_keeps_stock(stack):
    before = stock(stack, 2)
    r = post(stack, "/api/checkout", {**GOOD, "card": "4000 0000 0000 0002", "items": [{"product_id": 2, "qty": 1}]})
    assert r.status_code == 402 and r.json()["error"] == "payment_declined"
    assert stock(stack, 2) == before


def test_out_of_stock_is_a_clean_409_with_no_partial_decrement(stack):
    stack.db_mod.conn().execute("UPDATE products SET stock=1 WHERE id=3")
    before = stock(stack, 1)
    r = post(stack, "/api/checkout", {**GOOD, "items": [{"product_id": 1, "qty": 1}, {"product_id": 3, "qty": 2}]})
    assert r.status_code == 409 and r.json()["error"] == "out_of_stock" and r.json()["available"] == 1
    assert stock(stack, 1) == before and stock(stack, 3) == 1                  # transaction rolled back as a whole


def test_concurrent_orders_never_oversell(stack):
    stack.db_mod.conn().execute("UPDATE products SET stock=3 WHERE id=5")
    codes = []

    def buy():
        codes.append(requests.post(stack.db.url + "/orders", json={"name": "x", "email": "x@y.z",
                                   "items": [{"product_id": 5, "qty": 1}]}, timeout=10).status_code)

    ts = [threading.Thread(target=buy) for _ in range(10)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert sorted(codes) == [201] * 3 + [409] * 7 and stock(stack, 5) == 0


def test_database_survives_restart_with_data(tmp_path, monkeypatch):
    monkeypatch.setenv("DB_PATH", str(tmp_path / "persist.db"))
    monkeypatch.setenv("AUTO_RESTOCK", "0")
    m = load("shop_db_a", "db/app.py")
    c = m.app.test_client()
    oid = c.post("/orders", json={"name": "n", "email": "e@e.e", "items": [{"product_id": 1, "qty": 1}]}).json["order_id"]
    m2 = load("shop_db_b", "db/app.py")                                         # a new process on the same volume
    assert m2.app.test_client().get(f"/orders/{oid}").status_code == 200
    assert m2.app.test_client().get("/").json["products"] == 12                 # seeded once, not duplicated


# ----------------------------------------------------------------- tracing + metrics
def test_requests_are_traced_through_all_three_tiers(stack):
    h = get(stack, "/api/products").headers
    assert h["X-Frontend-Pod"] and h["X-Backend-Pod"] and h["X-DB-Pod"]


def test_metrics_have_the_series_kubeguard_queries(stack):
    for _ in range(3):
        get(stack, "/api/products/1")
    get(stack, "/api/products/999")
    m = requests.get(stack.web.url + "/metrics").text
    assert 'http_requests_total{code="200"} 3' in m and 'http_requests_total{code="404"} 1' in m
    assert "http_request_duration_seconds_count 4" in m and "http_request_duration_seconds_sum" in m
    get(stack, "/healthz")
    assert "http_request_duration_seconds_count 4" in requests.get(stack.web.url + "/metrics").text   # probes aren't counted


# ----------------------------------------------------------------- fault injection (what KubeGuard experiments call)
@pytest.mark.parametrize("svc", ["web", "api", "db"])
def test_chaos_endpoints_are_locked_without_the_token(stack, svc):
    base = getattr(stack, svc).url
    assert requests.post(base + "/chaos/errors", timeout=5).status_code == 403
    assert requests.post(base + "/chaos/errors", headers={"X-Chaos-Token": "wrong"}, timeout=5).status_code == 403
    assert requests.get(base + "/chaos/status", timeout=5).status_code == 403
    assert requests.post(base + "/chaos/errors?seconds=5&rate=1", headers=H, timeout=5).status_code == 200


def test_chaos_is_disabled_entirely_when_no_token_is_configured(tmp_path, monkeypatch):
    monkeypatch.setenv("DB_PATH", str(tmp_path / "x.db"))
    monkeypatch.delenv("CHAOS_TOKEN", raising=False)
    c = load("shop_db_nt", "db/app.py").app.test_client()
    assert c.post("/chaos/cpu", headers=H).status_code == 403                  # an empty token must never match


def test_error_fault_on_the_storefront_breaks_api_calls_but_not_the_page_or_probes(stack):
    assert stack.chaos("web", "errors", seconds=30, rate=1).ok
    assert get(stack, "/api/products").status_code == 500
    assert get(stack, "/").status_code == 200 and get(stack, "/healthz").status_code == 200
    stack.chaos("web", "stop")
    assert get(stack, "/api/products").status_code == 200


def test_database_fault_cascades_to_the_customer_as_a_503_then_recovers(stack_nocache):
    s = stack_nocache
    assert get(s, "/api/products").status_code == 200
    s.chaos("db", "errors", seconds=30, rate=1)
    r = get(s, "/api/products")
    assert r.status_code == 503 and r.json()["error"] == "database_unavailable"
    assert post(s, "/api/checkout", {**GOOD, "items": [{"product_id": 1, "qty": 1}]}).status_code == 503
    m = requests.get(s.web.url + "/metrics").text
    assert 'http_requests_total{code="503"} 2' in m                              # visible to Prometheus at the edge
    s.chaos("db", "stop")
    assert get(s, "/api/products").status_code == 200


def test_backend_down_is_a_502_not_a_crash(stack):
    stack.api.stop()
    r = get(stack, "/api/products")
    assert r.status_code == 502 and r.json()["error"] == "backend_unavailable"
    assert get(stack, "/").status_code == 200                                    # the page shell still loads


def test_database_down_is_a_503_not_a_500(stack_nocache):
    stack_nocache.db.stop()
    r = get(stack_nocache, "/api/products")
    assert r.status_code == 503 and r.json()["error"] == "database_unavailable"


def test_memory_and_cpu_faults_run_with_a_valid_token(stack):
    r = stack.chaos("db", "memory", seconds=3, percent=40)
    assert r.ok and r.json()["percent"] == 40
    assert stack.chaos("db", "cpu", seconds=2).json()["fault"] == "cpu"
    assert requests.get(stack.db.url + "/healthz").text == "ok"                  # health checks survive the burn
    assert stack.chaos("db", "stop").ok


def test_crash_is_refused_unless_enabled(stack):
    r = requests.post(stack.db.url + "/chaos/crash", headers=H, timeout=5)
    assert r.status_code == 403 and "ALLOW_CRASH" in r.json()["error"]


def test_api_proxy_cannot_be_steered_elsewhere(stack):
    """The storefront must never let a request choose the upstream path. Uses Flask's client so nothing is normalised first."""
    c = stack.web_mod.app.test_client()
    seen = []
    real = stack.web_mod.http.request
    stack.web_mod.http.request = lambda *a, **k: seen.append(a[1]) or real(*a, **k)
    try:
        for p in ("/api/a.b", "/api/%2e%2e/healthz", "/api/products/..%2f..%2fmetrics", "/api/x%00y", "/api/" + "a" * 80):
            assert c.get(p).status_code == 404, p
        assert c.get("/api/products").status_code == 200                       # sanity: normal calls still go through
    finally:
        stack.web_mod.http.request = real
    assert seen == [f"{stack.web_mod.BACKEND_URL}/api/products"]               # only the legitimate call reached the backend


# ----------------------------------------------------------------- load generator + packaging
def test_loadgen_shoppers_create_real_orders_through_all_tiers(stack, monkeypatch):
    monkeypatch.setenv("FRONTEND_URL", stack.web.url)
    monkeypatch.setenv("BUY_RATE", "0.5")
    lg = load("shop_loadgen", "loadgen/loadgen.py")
    random.seed(7)
    placed = sum(lg.session() for _ in range(25))
    info = requests.get(stack.db.url + "/").json()
    assert placed > 3 and info["orders"] == placed and info["revenue_cents"] > 0


def test_storefront_javascript_parses():
    if not shutil.which("node"):
        pytest.skip("node not installed")
    assert subprocess.run(["node", "--check", os.path.join(ROOT, "web/static/app.js")]).returncode == 0


def test_every_service_has_a_pinned_non_root_dockerfile():
    for svc in ("web", "api", "db", "loadgen"):
        text = open(os.path.join(ROOT, svc, "Dockerfile")).read()
        assert re.search(r"^FROM python:3\.12-slim$", text, re.M), svc
        assert "USER 10001" in text and "EXPOSE" in text or svc == "loadgen", svc
        assert not re.search(r":latest", text)


# ----------------------------------------------------------------- KubeGuard (the monitoring tool) drives the shop
def test_kubeguards_experiment_code_can_drive_every_shop_service_only_with_the_token(stack):
    sys.path.insert(0, os.path.join(ROOT, "..", "kubeheal"))
    from app.experiments import http_chaos          # the real transport KubeGuard uses on a cluster
    from app.models import PodInfo
    for svc in ("db", "api", "web"):
        server = getattr(stack, svc)
        port = int(server.url.rsplit(":", 1)[1])
        pod = PodInfo(name=f"{svc}-x", app=svc, phase="Running", ready=True, ip="127.0.0.1")
        assert http_chaos(port, TOKEN)(pod, "errors", {"seconds": 5, "rate": 1}) is True, svc
        assert http_chaos(port, "")(pod, "errors", {"seconds": 5, "rate": 1}) is False, svc       # no token -> refused
        assert http_chaos(port, "wrong")(pod, "stop", {}) is False, svc
        assert http_chaos(port, TOKEN)(pod, "stop", {}) is True, svc
    assert get(stack, "/api/products").status_code == 200                           # every fault was cleared again
