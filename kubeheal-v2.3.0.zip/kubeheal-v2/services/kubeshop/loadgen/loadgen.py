"""KubeShop load generator: simulated shoppers (browse, search, price a cart, sometimes buy). Standard library only.

Traffic goes through the real storefront, so it flows storefront -> API -> database and every tier has live metrics.
"""
import json
import os
import random
import threading
import time
import urllib.error
import urllib.request

BASE = os.getenv("FRONTEND_URL", "http://frontend").rstrip("/")
SHOPPERS = int(os.getenv("SHOPPERS", "2"))
THINK = float(os.getenv("THINK_SECONDS", "1.5"))
BUY_RATE = float(os.getenv("BUY_RATE", "0.30"))
DECLINE_RATE = float(os.getenv("DECLINE_RATE", "0.01"))
GOOD_CARD, DECLINED_CARD = "4242424242424242", "4000000000000002"


def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw[:1] in (b"{", b"[") else raw)
    except urllib.error.HTTPError as e:                  # 4xx/5xx are part of the experiment, not a crash
        return e.code, {}
    except Exception:
        return 0, {}


def session():
    """One shopper visit. Returns the number of orders placed (0 or 1)."""
    if random.random() < 0.05:
        call("GET", "/")
    status, data = call("GET", "/api/products")
    if status != 200 or not isinstance(data, dict) or not data.get("products"):
        return 0
    prods = data["products"]
    for _ in range(random.randint(1, 3)):
        call("GET", f"/api/products/{random.choice(prods)['id']}")
    if random.random() < 0.25:
        call("GET", "/api/products?q=" + random.choice(["watch", "mug", "lamp", "shoes", "yoga"]))
    items = [{"product_id": random.choice(prods)["id"], "qty": random.randint(1, 2)} for _ in range(random.randint(1, 3))]
    call("POST", "/api/quote", {"items": items})
    roll = random.random()
    if roll < BUY_RATE + DECLINE_RATE:
        card = DECLINED_CARD if roll >= BUY_RATE else GOOD_CARD
        status, _ = call("POST", "/api/checkout", {"name": "Load Shopper", "email": "shopper@example.com", "card": card, "items": items})
        return 1 if status == 201 else 0
    return 0


def shopper():
    while True:
        try:
            session()
        except Exception:
            pass
        time.sleep(random.uniform(0.5, 1.5) * THINK)


if __name__ == "__main__":
    for _ in range(SHOPPERS):
        threading.Thread(target=shopper, daemon=True).start()
    while True:
        time.sleep(3600)
